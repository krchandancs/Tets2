// src/pages/SynopticReportPage/components/MegablockDiagram.tsx
// ─────────────────────────────────────────────────────────────────────────────
// Real feature, per direct confirmation: "I wanted to be able to assign each
// core to a specific section of a single block... so the Pathologist can
// always identify what section of the block the core tissue was embedded
// into." "I like the Physical block diagram, but only if it doesn't impact
// performance."
//
// Deliberately plain, static SVG — a handful of <rect>/<text> elements
// computed once per render from real block data, no canvas, no animation, no
// charting library, nothing that recomputes per-frame. At realistic
// megablock sizes (2-12 positions — a full prostate mapping biopsy is the
// upper end of what any real lab does) this is trivially cheap; the same
// order of cost as the existing BlockIcon/SlideChip components already
// rendered throughout MaterialTreePanel.tsx.
// ─────────────────────────────────────────────────────────────────────────────
import React, { useMemo } from 'react';

export interface MegablockPosition {
  position: number;
  specimenLabel: string;
  specimenDescription?: string;
  blockId: string;
  blockLabel: string;
}

interface MegablockDiagramProps {
  cassetteLabel: string;
  positions: MegablockPosition[];
  onOpenBlockEditor: (blockId: string) => void;
}

// Real, fixed layout constants — not computed per-render, not configurable.
// Grid columns scale gently with count so the block reads as roughly
// square regardless of how many positions it holds (a 3-core megablock
// isn't a single long strip; a 12-core one isn't a single tall column).
function columnsFor(count: number): number {
  if (count <= 2) return 2;
  if (count <= 4) return 2;
  if (count <= 6) return 3;
  if (count <= 9) return 3;
  return 4;
}

const CELL = 46;
const GAP = 4;
const PAD = 10;

const MegablockDiagram: React.FC<MegablockDiagramProps> = ({ cassetteLabel, positions, onOpenBlockEditor }) => {
  const sorted = useMemo(
    () => [...positions].sort((a, b) => a.position - b.position),
    [positions]
  );
  const cols = columnsFor(sorted.length);
  const rows = Math.ceil(sorted.length / cols);
  const width  = PAD * 2 + cols * CELL + (cols - 1) * GAP;
  const height = PAD * 2 + rows * CELL + (rows - 1) * GAP + 20; // +20 for the cassette-label strip

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginLeft: 40, marginBottom: 12 }}>
      <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} style={{ flexShrink: 0 }}>
        {/* Cassette outline — same amber/brown language as BlockIcon, so a
            megablock still visually reads as "a block" at a glance. */}
        <rect
          x={1} y={1} width={width - 2} height={height - 2} rx={4}
          fill="rgba(186,117,23,0.10)" stroke="rgba(148,163,184,0.3)" strokeWidth={0.5}
        />
        <text x={width / 2} y={14} textAnchor="middle" fontSize={9} fontWeight={700} fill="#cbd5e1">
          {cassetteLabel}
        </text>
        {sorted.map((p, i) => {
          const col = i % cols;
          const row = Math.floor(i / cols);
          const x = PAD + col * (CELL + GAP);
          const y = 20 + PAD + row * (CELL + GAP);
          return (
            <g
              key={p.blockId}
              onClick={() => onOpenBlockEditor(p.blockId)}
              style={{ cursor: 'pointer' }}
            >
              <title>{`Position ${p.position}: Specimen ${p.specimenLabel}${p.specimenDescription ? ` — ${p.specimenDescription}` : ''}`}</title>
              <rect
                x={x} y={y} width={CELL} height={CELL} rx={3}
                fill="rgba(8,145,178,0.12)" stroke="rgba(148,163,184,0.35)" strokeWidth={0.5}
              />
              <text x={x + CELL / 2} y={y + CELL / 2 - 3} textAnchor="middle" fontSize={13} fontWeight={700} fill="#e2e8f0">
                {p.specimenLabel}
              </text>
              <text x={x + CELL / 2} y={y + CELL / 2 + 11} textAnchor="middle" fontSize={8} fill="#94a3b8">
                pos {p.position}
              </text>
            </g>
          );
        })}
      </svg>
      <div style={{ fontSize: 11, color: '#94a3b8', lineHeight: 1.6 }}>
        {sorted.map(p => (
          <div key={p.blockId}>
            <span style={{ fontWeight: 700, color: '#cbd5e1' }}>Position {p.position}</span>
            {' — Specimen '}{p.specimenLabel}
            {p.specimenDescription ? `: ${p.specimenDescription}` : ''}
          </div>
        ))}
      </div>
    </div>
  );
};

export default MegablockDiagram;
