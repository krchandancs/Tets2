import React, { useState, useEffect, useRef, useCallback, useImperativeHandle, forwardRef, createContext, useContext } from 'react';
import { createPortal } from 'react-dom';
import '../../pathscribe.css';
import { X } from "../Icons";
import type { PathScribeEditorHandle } from './PathScribeEditorRef';
import {
  Bold, Italic, Underline as UnderlineIcon, Strikethrough,
  Subscript as SubscriptIcon, Superscript as SuperscriptIcon,
  AlignLeft, AlignCenter, AlignRight, AlignJustify,
  List, ListOrdered,
  IndentIncrease, IndentDecrease,
  Heading1, Heading2, Heading3,
  Highlighter, Baseline,
  Table as TableIcon,
  Search,
  Undo2, Redo2,
  Sun, Moon,
  PilcrowSquare,
  Zap, PenLine,
  ArrowUpDown, PaintBucket, SquareDashedBottom,
  SplitSquareHorizontal,
  Rows3, Columns3, Combine,
} from 'lucide-react';
import { useEditor, EditorContent, Extension } from '@tiptap/react';
import Paragraph from '@tiptap/extension-paragraph';
import StarterKit from '@tiptap/starter-kit';
import { TextStyle } from '@tiptap/extension-text-style';
import { FontFamily } from '@tiptap/extension-font-family';
import { Color } from '@tiptap/extension-color';
import Underline from '@tiptap/extension-underline';
import Highlight from '@tiptap/extension-highlight';
import Subscript from '@tiptap/extension-subscript';
import Superscript from '@tiptap/extension-superscript';
import TextAlign from '@tiptap/extension-text-align';
import { Table } from '@tiptap/extension-table';
import { TableRow } from '@tiptap/extension-table-row';
import { TableCell } from '@tiptap/extension-table-cell';
import { TableHeader } from '@tiptap/extension-table-header';
import { Plugin, PluginKey } from '@tiptap/pm/state';
import { Decoration, DecorationSet } from '@tiptap/pm/view';

// ─── TYPES ────────────────────────────────────────────────────────────────────

export interface Macro {
  id: string;
  trigger: string;
  name: string;
  content: string;
}

export interface PathScribeEditorProps {
  content?: string;
  onChange?: (html: string) => void;
  approvedFonts?: string[];
  macros?: Macro[];
  placeholder?: string;
  showRulerDefault?: boolean;
  minHeight?: string;
  readOnly?: boolean;
  // ── Multi-instance toolbar sharing ──────────────────────────────────────────
  // suppressToolbar=true + toolbarPortalId → portal toolbar to that DOM node
  // suppressToolbar=true + no toolbarPortalId → render NO toolbar (unfocused)
  // suppressToolbar omitted/false → render toolbar inline (default, backward compat)
  suppressToolbar?: boolean;
  toolbarPortalId?: string;
  theme?: 'light' | 'dark';
  /** Shows a real toggle button in the toolbar letting the user switch
   *  themes themselves. `theme` above becomes only the STARTING point --
   *  once the user has ever clicked the toggle anywhere it appears, that
   *  becomes their real preference (persisted to localStorage), shared
   *  across every editor instance that opts into this, overriding
   *  whatever `theme` any individual screen was built with. Off by
   *  default so contexts that shouldn't show it (e.g. a small font
   *  preview box) don't get one uninvited. */
  allowThemeToggle?: boolean;
  // ── Tab width — industry-standard user preference ────────────────────────────
  // Number of spaces a Tab keypress inserts. Word/Docs/Notion all expose this as
  // a user setting rather than hardcoding it. Defaults to 4, persisted by the
  // parent (e.g. via localStorage or user profile) and passed back in on mount.
  tabWidthChars?: number;
  onTabWidthChange?: (chars: number) => void;
}

// ─── THEME CONTEXT ────────────────────────────────────────────────────────────
// Set once at the PathScribeEditor root; consumed by TBtn, Divider, Ruler,
// MacroModal, FindReplacePanel, InsertTableModal, and any other sub-component
// without prop drilling. This is what prevents the "forgot to pass theme"
// class of bugs we hit repeatedly when theme was a plain prop on every
// sub-component — a sub-component rendered without a Provider simply falls
// back to LIGHT_THEME instead of crashing.

export interface EditorThemeTokens {
  toolbarBg: string; toolbarBorder: string;
  btnBg: string; btnBgActive: string; btnBorder: string; btnBorderActive: string;
  btnHoverBg: string;
  btnText: string; btnTextActive: string; btnTextDisabled: string;
  dividerColor: string;
  panelBg: string; panelBorder: string; panelShadow: string; panelText: string; panelHoverBg: string;
  inputBg: string; inputBorder: string; inputText: string;
  contentBg: string; contentText: string; contentBorder: string;
  rulerBg: string; rulerBorder: string; rulerMarkColor: string;
  accent: string; accentText: string;
}

const LIGHT_THEME: EditorThemeTokens = {
  toolbarBg: 'white', toolbarBorder: '#e2e8f0',
  btnBg: 'white', btnBgActive: '#0891B2', btnBorder: '#e2e8f0', btnBorderActive: '#0891B2',
  btnHoverBg: '#f1f5f9',
  btnText: '#1e293b', btnTextActive: 'white', btnTextDisabled: '#cbd5e1',
  dividerColor: '#e2e8f0',
  panelBg: 'white', panelBorder: '#e2e8f0', panelShadow: '0 8px 24px rgba(0,0,0,0.12)', panelText: '#1e293b', panelHoverBg: '#f1f5f9',
  inputBg: 'white', inputBorder: '#e2e8f0', inputText: '#1e293b',
  contentBg: 'white', contentText: '#1e293b', contentBorder: '#e2e8f0',
  rulerBg: '#f8fafc', rulerBorder: '#e2e8f0', rulerMarkColor: '#64748b',
  accent: '#0891B2', accentText: 'white',
};

const DARK_THEME: EditorThemeTokens = {
  toolbarBg: 'transparent', toolbarBorder: 'transparent',
  btnBg: 'transparent', btnBgActive: 'transparent', btnBorder: 'transparent', btnBorderActive: 'transparent',
  btnHoverBg: 'rgba(148,163,184,0.14)',
  btnText: '#cbd5e1', btnTextActive: 'white', btnTextDisabled: '#5b6573',
  dividerColor: 'rgba(148,163,184,0.18)',
  panelBg: '#252d3a', panelBorder: 'rgba(148,163,184,0.18)', panelShadow: '0 8px 24px rgba(0,0,0,0.5)', panelText: '#e9edf2', panelHoverBg: 'rgba(148,163,184,0.12)',
  inputBg: 'rgba(148,163,184,0.08)', inputBorder: 'rgba(148,163,184,0.18)', inputText: '#e2e8f0',
  contentBg: '#0f172a', contentText: '#e2e8f0', contentBorder: 'rgba(148,163,184,0.15)',
  rulerBg: '#1a212c', rulerBorder: 'rgba(148,163,184,0.15)', rulerMarkColor: '#94a3b8',
  accent: '#22b8d8', accentText: 'white',
};

// IMPORTANT: default context value is LIGHT_THEME, not undefined.
// Any sub-component rendered outside a ThemeProvider (or before one mounts)
// gets a safe, correct theme instead of crashing on `theme.whatever`.
const EditorThemeContext = createContext<EditorThemeTokens>(LIGHT_THEME);
const useEditorTheme = () => useContext(EditorThemeContext);

// ─── IMPERATIVE HANDLE ────────────────────────────────────────────────────────
// Exposed via forwardRef so the Orchestrator Engine and NarrativeEditor
// can drive the editor programmatically without going through React props.
//
// FIXED (July 2026): this used to re-declare its own separate
// PathScribeEditorHandle interface here, structurally identical to (but
// nominally distinct from) the one in PathScribeEditorRef.ts — which
// every external consumer (NarrativeEditor.tsx, OrchestratorReportPanel.tsx,
// OrchestratorSectionEditor.tsx) actually imports. Two independent
// declarations of the same shape, kept in sync only by manual discipline —
// exactly the class of drift bug found live elsewhere in this codebase
// this session (aiProviderService, protocolRegistry/protocolShared, the
// reportingMode mismatch — see services/cases/caseFilterUtils.ts's own
// comment). Consolidated to a single source of truth — now imported at
// the top of this file instead of re-declared here.

// ─── MACRO HOTKEY EXTENSION ───────────────────────────────────────────────────

const createMacroExtension = (
  macros: Macro[],
  onUnknownTrigger: (partial: string) => void
) =>
  Extension.create({
    name: 'macroHotkey',
    addProseMirrorPlugins() {
      return [
        new Plugin({
          key: new PluginKey('macroHotkey'),
          props: {
            handleKeyDown(view, event) {
              if (event.key !== ' ' && event.key !== 'Enter') return false;

              const { state } = view;
              const { $from } = state.selection;
              const textBefore = $from.nodeBefore?.text ?? '';

              const match = textBefore.match(/(;[a-zA-Z0-9]+)$/);
              if (!match) return false;

              const typed = match[1];
              const macro = macros.find(m => m.trigger === typed);

              if (macro) {
                const from = $from.pos - typed.length;
                const to = $from.pos;
                const { tr } = state;
                tr.delete(from, to);
                view.dispatch(tr);

                view.dom.dispatchEvent(
                  new CustomEvent('insertMacroContent', {
                    detail: { content: macro.content },
                    bubbles: true,
                  })
                );

                if (event.key === ' ') event.preventDefault();
                return true;
              }

              if (typed.length > 1) {
                onUnknownTrigger(typed);
              }

              return false;
            },
          },
        }),
      ];
    },
  });

// ─── TAB KEY EXTENSION ────────────────────────────────────────────────────────

// ─── TAB KEY EXTENSION ────────────────────────────────────────────────────────
// Industry-standard behaviour:
//   • In a list item → Tab/Shift-Tab sink/lift the item (indent level), same
//     as Word, Google Docs, Notion.
//   • In plain text → Tab inserts a fixed-width space run sized by the user's
//     tabWidthChars setting (default 4) — this is what "tab width" means in
//     every code editor and most word processors when no ruler/tab-stops
//     are in play. We use non-breaking spaces inside a styled span so the
//     run can't collapse or wrap, and so it copies/pastes as plain spaces.
//   • Shift-Tab in plain text removes one tab-width of leading whitespace
//     from the start of the current line, mirroring "Reduce Indent".

const DEFAULT_TAB_WIDTH_CHARS = 4;

const createTabExtension = (tabWidthChars: number) =>
  Extension.create({
    name: 'tabKey',
    addKeyboardShortcuts() {
      const spaces = '\u00A0'.repeat(Math.max(1, tabWidthChars));
      return {
        Tab: ({ editor }) => {
          if (editor.can().sinkListItem('listItem')) {
            editor.chain().focus().sinkListItem('listItem').run();
            return true;
          }
          editor.chain().focus().insertContent(spaces).run();
          return true;
        },
        'Shift-Tab': ({ editor }) => {
          if (editor.can().liftListItem('listItem')) {
            editor.chain().focus().liftListItem('listItem').run();
            return true;
          }
          // Remove up to one tab-width of leading nbsp/space immediately
          // before the cursor, if present — best-effort "reduce indent".
          const { state } = editor;
          const { $from } = state.selection;
          const lineStart = $from.start();
          const textBefore = state.doc.textBetween(lineStart, $from.pos, '\n', '\n');
          const trailingSpaces = textBefore.match(/[\u00A0 ]+$/)?.[0] ?? '';
          if (trailingSpaces.length > 0) {
            const removeCount = Math.min(trailingSpaces.length, tabWidthChars);
            editor.chain().focus()
              .deleteRange({ from: $from.pos - removeCount, to: $from.pos })
              .run();
          }
          return true;
        },
      };
    },
  });

// ─── FONT SIZE EXTENSION ──────────────────────────────────────────────────────
// Tiptap has no built-in font-size command (unlike FontFamily, which ships as
// its own package). This extends TextStyle with a `fontSize` attribute and
// setFontSize/unsetFontSize commands, mirroring how FontFamily itself works
// internally. Without this, the font-size dropdown was purely cosmetic —
// it updated its own label but never touched the editor at all.

const FontSize = TextStyle.extend({
  name: 'textStyle', // intentionally reuse the same mark name as TextStyle so
                      // font-family and font-size attributes live on one mark
                      // instead of competing/nesting marks for the same text
  addAttributes() {
    return {
      ...this.parent?.(),
      fontSize: {
        default: null,
        parseHTML: (element: HTMLElement) => element.style.fontSize || null,
        renderHTML: (attributes: { fontSize?: string | null }) => {
          if (!attributes.fontSize) return {};
          return { style: `font-size: ${attributes.fontSize}` };
        },
      },
    };
  },
  addCommands() {
    return {
      ...this.parent?.(),
      setFontSize: (size: string) => ({ chain }: any) =>
        chain().setMark('textStyle', { fontSize: size }).run(),
      unsetFontSize: () => ({ chain }: any) =>
        chain().setMark('textStyle', { fontSize: null }).removeEmptyTextStyle().run(),
    } as any;
  },
});

// ─── PARAGRAPH SHADING & BORDERS ──────────────────────────────────────────────
// Extends Tiptap's default Paragraph node with `shading` (background colour)
// and `borderStyle` attributes, applied to the WHOLE paragraph block — not
// selected text. This is block-level formatting, like a callout box or table
// row shading in Word, distinct from the existing text-highlight mark (which
// stays as-is and colors only selected characters).
//
// Both attributes are no-selection-required: setParagraphShading/setBorder
// act on whichever paragraph the cursor currently sits in, the same way
// setTextAlign works on the current block regardless of selection.
//
// Border styles render via individual side properties so "Left Border" etc.
// can be combined or replaced cleanly without fighting a single shorthand.

type BorderStyle = 'none' | 'box' | 'left' | 'right' | 'top' | 'bottom';

const BORDER_CSS: Record<BorderStyle, string> = {
  none:   '',
  box:    'border: 1.5px solid #475569;',
  left:   'border-left: 3px solid #475569;',
  right:  'border-right: 3px solid #475569;',
  top:    'border-top: 3px solid #475569;',
  bottom: 'border-bottom: 3px solid #475569;',
};

const ShadedParagraph = Paragraph.extend({
  addAttributes() {
    return {
      ...this.parent?.(),
      shading: {
        default: null,
        parseHTML: (element: HTMLElement) => element.style.backgroundColor || null,
        renderHTML: (attributes: { shading?: string | null }) => {
          if (!attributes.shading) return {};
          return { style: `background-color: ${attributes.shading}; padding: 6px 10px; border-radius: 4px;` };
        },
      },
      borderStyle: {
        default: null,
        parseHTML: (element: HTMLElement) => (element.getAttribute('data-border') as BorderStyle) || null,
        renderHTML: (attributes: { borderStyle?: BorderStyle | null }) => {
          if (!attributes.borderStyle || attributes.borderStyle === 'none') return {};
          return {
            'data-border': attributes.borderStyle,
            style: BORDER_CSS[attributes.borderStyle] + ' padding: 6px 10px;',
          };
        },
      },
    };
  },
  addCommands() {
    return {
      ...this.parent?.(),
      setParagraphShading: (color: string | null) => ({ commands }: any) =>
        commands.updateAttributes('paragraph', { shading: color }),
      setParagraphBorder: (style: BorderStyle) => ({ commands }: any) =>
        commands.updateAttributes('paragraph', { borderStyle: style === 'none' ? null : style }),
    } as any;
  },
});

// ─── FORMATTING MARKS EXTENSION ───────────────────────────────────────────────
// Shows visible markers for whitespace characters that are otherwise
// invisible — regular spaces, non-breaking spaces (used by Tab), and
// paragraph ends. This is the "¶ Show Formatting Marks" feature found in
// Word/Google Docs, essential for debugging whitespace issues (e.g.
// confirming Tab actually inserted characters, or that trailing spaces
// weren't silently dropped).
//
// Implemented as a ProseMirror decoration plugin rather than pure CSS,
// because CSS pseudo-elements can't target individual characters inside a
// text run — only an inline decoration per character position can do that.

const formatMarksVisibleRef = { current: false };

const FormatMarksExtension = Extension.create({
  name: 'formatMarks',
  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey('formatMarks'),
        props: {
          decorations(state) {
            if (!formatMarksVisibleRef.current) return null;
            const decorations: Decoration[] = [];
            state.doc.descendants((node, pos) => {
              if (!node.isText || !node.text) return;
              for (let i = 0; i < node.text.length; i++) {
                const ch = node.text[i];
                if (ch === ' ' || ch === '\u00A0') {
                  const from = pos + i;
                  const isNbsp = ch === '\u00A0';
                  decorations.push(
                    Decoration.inline(from, from + 1, {
                      class: isNbsp ? 'ps-fm-nbsp' : 'ps-fm-space',
                    })
                  );
                }
              }
            });
            return DecorationSet.create(state.doc, decorations);
          },
        },
      }),
    ];
  },
});

// ─── TOOLBAR BUTTON ───────────────────────────────────────────────────────────
// Reads theme from context — no prop needed, no way to forget passing it.

const TBtn: React.FC<{
  onClick: () => void; isActive?: boolean; title?: string;
  disabled?: boolean; children: React.ReactNode; width?: string;
}> = ({ onClick, isActive, title, disabled, children, width }) => {
  const theme = useEditorTheme();
  return (
    <button onClick={onClick} title={title} disabled={disabled}
      style={{
        padding: '5px 7px',
        minWidth: width || '28px',
        height: '26px',
        background: isActive ? theme.btnHoverBg : 'transparent',
        color: disabled ? theme.btnTextDisabled : (isActive ? theme.accent : theme.btnText),
        border: 'none',
        borderRadius: '5px',
        cursor: disabled ? 'not-allowed' : 'pointer',
        fontSize: '12px',
        fontWeight: 500,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '3px',
        transition: 'background 0.12s, color 0.12s',
        flexShrink: 0,
        whiteSpace: 'nowrap',
      }}
      onMouseEnter={e => { if (!disabled) e.currentTarget.style.background = theme.btnHoverBg; }}
      onMouseLeave={e => { if (!disabled) e.currentTarget.style.background = isActive ? theme.btnHoverBg : 'transparent'; }}
    >
      {children}
    </button>
  );
};

const Divider = () => {
  const theme = useEditorTheme();
  return <div style={{ width: '1px', height: '18px', background: theme.dividerColor, margin: '0 5px', flexShrink: 0 }} />;
};

// ─── FIND/REPLACE PANEL ───────────────────────────────────────────────────────

const FindReplacePanel: React.FC<{ editor: any; onClose: () => void }> = ({ editor, onClose }) => {
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [mode, setMode] = useState<'find' | 'replace'>('find');
  const [matchCount, setMatchCount] = useState(0);

  const doFind = () => {
    if (!findText || !editor) return;
    const html = editor.getHTML();
    const count = (html.match(new RegExp(findText, 'gi')) || []).length;
    setMatchCount(count);
    window.find(findText);
  };

  const doReplaceAll = () => {
    if (!findText || !editor) return;
    const html = editor.getHTML();
    const newHtml = html.replace(new RegExp(findText, 'gi'), replaceText);
    editor.commands.setContent(newHtml);
    setMatchCount(0);
  };

  return (
    <div style={{ position: 'absolute', top: '100%', right: 0, zIndex: 100, background: 'white', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '16px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', width: '340px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button onClick={() => setMode('find')} style={{ fontSize: '13px', fontWeight: 600, color: mode === 'find' ? '#0891B2' : '#64748b', background: 'none', border: 'none', cursor: 'pointer', padding: '2px 8px', borderBottom: mode === 'find' ? '2px solid #0891B2' : '2px solid transparent' }}>Find</button>
          <button onClick={() => setMode('replace')} style={{ fontSize: '13px', fontWeight: 600, color: mode === 'replace' ? '#0891B2' : '#64748b', background: 'none', border: 'none', cursor: 'pointer', padding: '2px 8px', borderBottom: mode === 'replace' ? '2px solid #0891B2' : '2px solid transparent' }}>Replace</button>
        </div>
        <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#94a3b8', fontSize: '18px' }}>✕</button>
      </div>
      <input value={findText} onChange={e => setFindText(e.target.value)} onKeyDown={e => e.key === 'Enter' && doFind()} placeholder="Find..." autoFocus style={{ width: '100%', padding: '8px 10px', border: '1px solid #e2e8f0', borderRadius: '6px', fontSize: '13px', marginBottom: '8px', boxSizing: 'border-box' }} />
      {mode === 'replace' && <input value={replaceText} onChange={e => setReplaceText(e.target.value)} placeholder="Replace with..." style={{ width: '100%', padding: '8px 10px', border: '1px solid #e2e8f0', borderRadius: '6px', fontSize: '13px', marginBottom: '8px', boxSizing: 'border-box' }} />}
      {matchCount > 0 && <div style={{ fontSize: '12px', color: '#64748b', marginBottom: '8px' }}>{matchCount} match(es) found</div>}
      <div style={{ display: 'flex', gap: '8px' }}>
        <button onClick={doFind} style={{ flex: 1, padding: '8px', background: '#0891B2', color: 'white', border: 'none', borderRadius: '6px', fontSize: '13px', fontWeight: 600, cursor: 'pointer' }}>{mode === 'find' ? 'Find Next' : 'Find'}</button>
        {mode === 'replace' && <button onClick={doReplaceAll} style={{ flex: 1, padding: '8px', background: '#475569', color: 'white', border: 'none', borderRadius: '6px', fontSize: '13px', fontWeight: 600, cursor: 'pointer' }}>Replace All</button>}
      </div>
    </div>
  );
};

// ─── INSERT TABLE MODAL ───────────────────────────────────────────────────────

const InsertTableModal: React.FC<{ onInsert: (rows: number, cols: number) => void; onClose: () => void }> = ({ onInsert, onClose }) => {
  const [hovered, setHovered] = useState<{ rows: number; cols: number } | null>(null);
  const maxR = 8, maxC = 10;
  return (
    <div style={{ position: 'absolute', top: '100%', left: 0, zIndex: 100, background: 'white', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '16px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)' }}>
      <div style={{ fontSize: '12px', color: '#64748b', marginBottom: '10px', fontWeight: 600 }}>{hovered ? `${hovered.rows} × ${hovered.cols} table` : 'Select table size'}</div>
      <div style={{ display: 'grid', gridTemplateColumns: `repeat(${maxC}, 20px)`, gap: '2px' }}>
        {Array.from({ length: maxR }, (_, r) =>
          Array.from({ length: maxC }, (_, c) => (
            <div key={`${r}-${c}`} onMouseEnter={() => setHovered({ rows: r + 1, cols: c + 1 })} onMouseLeave={() => setHovered(null)} onClick={() => { onInsert(r + 1, c + 1); onClose(); }} style={{ width: 20, height: 20, background: hovered && r < hovered.rows && c < hovered.cols ? '#0891B2' : '#f1f5f9', border: `1px solid ${hovered && r < hovered.rows && c < hovered.cols ? '#0891B2' : '#e2e8f0'}`, borderRadius: '2px', cursor: 'pointer', transition: 'all 0.1s' }} />
          ))
        )}
      </div>
    </div>
  );
};

// ─── MACRO MODAL ─────────────────────────────────────────────────────────────

const MacroModal: React.FC<{ macros: Macro[]; initialSearch?: string; onSelect: (macro: Macro) => void; onClose: () => void }> = ({ macros, initialSearch = '', onSelect, onClose }) => {
  const [search, setSearch] = useState(initialSearch);
  const filtered = macros.filter(m => m.name.toLowerCase().includes(search.toLowerCase()) || m.trigger.toLowerCase().includes(search.toLowerCase()));
  return (
    <div className="ps-overlay" onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ width: '480px', maxHeight: '70vh', background: 'white', borderRadius: '16px', overflow: 'hidden', boxShadow: '0 24px 60px rgba(0,0,0,0.25)', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '20px 24px', borderBottom: '1px solid #e2e8f0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
            <h3 style={{ fontSize: '18px', fontWeight: 700, color: '#0f172a', margin: 0 }}>⚡ Insert Macro</h3>
            <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#94a3b8', fontSize: '20px' }}>✕</button>
          </div>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name or trigger (e.g. ;gs)..." autoFocus style={{ width: '100%', padding: '10px 14px', border: '1px solid #e2e8f0', borderRadius: '8px', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
        </div>
        <div style={{ overflowY: 'auto', flex: 1, padding: '12px' }}>
          {filtered.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px', color: '#94a3b8', fontSize: '14px' }}>No macros found</div>
          ) : filtered.map(macro => (
            <button key={macro.id} onClick={() => { onSelect(macro); onClose(); }} style={{ width: '100%', padding: '12px 16px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', marginBottom: '8px', textAlign: 'left', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '14px', transition: 'all 0.15s' }}
              onMouseEnter={e => { e.currentTarget.style.background = '#eff6ff'; e.currentTarget.style.borderColor = '#0891B2'; }}
              onMouseLeave={e => { e.currentTarget.style.background = '#f8fafc'; e.currentTarget.style.borderColor = '#e2e8f0'; }}
            >
              <div style={{ fontFamily: 'monospace', fontSize: '13px', fontWeight: 700, color: '#0891B2', background: 'rgba(8,145,178,0.1)', padding: '4px 8px', borderRadius: '4px', whiteSpace: 'nowrap' }}>{macro.trigger}</div>
              <div>
                <div style={{ fontSize: '14px', fontWeight: 600, color: '#0f172a' }}>{macro.name}</div>
                <div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '300px' }}>{macro.content.replace(/<[^>]+>/g, ' ').trim().slice(0, 80)}...</div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

// ─── SPACING DROPDOWN ─────────────────────────────────────────────────────────

const SpacingDropdown: React.FC<{ editor: any; onClose: () => void }> = ({ editor, onClose }) => {
  const lineSpacings = [{ label: 'Single (1.0)', value: '1' }, { label: '1.15', value: '1.15' }, { label: '1.5', value: '1.5' }, { label: 'Double (2.0)', value: '2' }];
  const setLineHeight = (_lh: string) => { if (!editor) return; editor.chain().focus().run(); onClose(); };
  return (
    <div style={{ position: 'absolute', top: '100%', left: 0, zIndex: 100, background: 'white', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '8px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', minWidth: '180px' }}>
      <div style={{ fontSize: '11px', fontWeight: 700, color: '#94a3b8', padding: '4px 8px 8px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Line Spacing</div>
      {lineSpacings.map(s => (
        <button key={s.value} onClick={() => setLineHeight(s.value)} style={{ width: '100%', padding: '8px 12px', textAlign: 'left', background: 'none', border: 'none', borderRadius: '6px', fontSize: '13px', color: '#1e293b', cursor: 'pointer', fontWeight: 500 }} onMouseEnter={e => e.currentTarget.style.background = '#f1f5f9'} onMouseLeave={e => e.currentTarget.style.background = 'none'}>{s.label}</button>
      ))}
      <div style={{ borderTop: '1px solid #e2e8f0', margin: '6px 0', paddingTop: '6px' }}>
        <div style={{ fontSize: '11px', fontWeight: 700, color: '#94a3b8', padding: '0 8px 6px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Paragraph Spacing</div>
        <button onClick={() => { editor?.chain().focus().run(); onClose(); }} style={{ width: '100%', padding: '8px 12px', textAlign: 'left', background: 'none', border: 'none', borderRadius: '6px', fontSize: '13px', color: '#1e293b', cursor: 'pointer', fontWeight: 500 }} onMouseEnter={e => e.currentTarget.style.background = '#f1f5f9'} onMouseLeave={e => e.currentTarget.style.background = 'none'}>Add Space Before</button>
        <button onClick={() => { editor?.chain().focus().run(); onClose(); }} style={{ width: '100%', padding: '8px 12px', textAlign: 'left', background: 'none', border: 'none', borderRadius: '6px', fontSize: '13px', color: '#1e293b', cursor: 'pointer', fontWeight: 500 }} onMouseEnter={e => e.currentTarget.style.background = '#f1f5f9'} onMouseLeave={e => e.currentTarget.style.background = 'none'}>Add Space After</button>
      </div>
    </div>
  );
};

// ─── COLOR PICKER ─────────────────────────────────────────────────────────────

const COLORS = [
  '#000000', '#1e293b', '#475569', '#94a3b8', '#e2e8f0', '#ffffff',
  '#dc2626', '#ea580c', '#d97706', '#65a30d', '#0891B2', '#7c3aed',
  '#fca5a5', '#fdba74', '#fde68a', '#bbf7d0', '#a5f3fc', '#ddd6fe',
  '#fee2e2', '#ffedd5', '#fef3c7', '#dcfce7', '#e0f2fe', '#ede9fe',
];

const ColorPicker: React.FC<{ onSelect: (color: string | null) => void; onClose: () => void; title: string }> = ({ onSelect, onClose, title }) => (
  <div style={{ position: 'absolute', top: '100%', left: 0, zIndex: 100, background: 'white', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '12px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', width: '176px' }}>
    <div style={{ fontSize: '11px', fontWeight: 700, color: '#94a3b8', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{title}</div>
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '4px' }}>
      {COLORS.map(color => (
        <div key={color} onClick={() => { onSelect(color); onClose(); }} style={{ width: '24px', height: '24px', background: color, borderRadius: '4px', cursor: 'pointer', border: color === '#ffffff' ? '1px solid #e2e8f0' : '1px solid transparent', transition: 'transform 0.1s' }} onMouseEnter={e => e.currentTarget.style.transform = 'scale(1.2)'} onMouseLeave={e => e.currentTarget.style.transform = 'scale(1)'} />
      ))}
    </div>
    <button onClick={() => { onSelect(null); onClose(); }} style={{ marginTop: '10px', width: '100%', padding: '6px', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '6px', fontSize: '12px', color: '#64748b', cursor: 'pointer', fontWeight: 600 }}>No Color</button>
  </div>
);

// ─── BORDER DROPDOWN ──────────────────────────────────────────────────────────

const BorderDropdown: React.FC<{ onSelect: (style: BorderStyle) => void; onClose: () => void }> = ({ onSelect, onClose }) => {
  const borders: { label: string; value: BorderStyle; svg: React.ReactNode }[] = [
    { label: 'Box Border',    value: 'box',    svg: <svg width="14" height="14" viewBox="0 0 14 14"><rect x="1" y="1" width="12" height="12" fill="none" stroke="#1e293b" strokeWidth="1.5"/></svg> },
    { label: 'Left Border',   value: 'left',   svg: <svg width="14" height="14" viewBox="0 0 14 14"><line x1="1" y1="1" x2="1" y2="13" stroke="#1e293b" strokeWidth="2"/><rect x="1" y="1" width="12" height="12" fill="none" stroke="#cbd5e1" strokeWidth="0.5"/></svg> },
    { label: 'Right Border',  value: 'right',  svg: <svg width="14" height="14" viewBox="0 0 14 14"><line x1="13" y1="1" x2="13" y2="13" stroke="#1e293b" strokeWidth="2"/><rect x="1" y="1" width="12" height="12" fill="none" stroke="#cbd5e1" strokeWidth="0.5"/></svg> },
    { label: 'Top Border',    value: 'top',    svg: <svg width="14" height="14" viewBox="0 0 14 14"><line x1="1" y1="1" x2="13" y2="1" stroke="#1e293b" strokeWidth="2"/><rect x="1" y="1" width="12" height="12" fill="none" stroke="#cbd5e1" strokeWidth="0.5"/></svg> },
    { label: 'Bottom Border', value: 'bottom', svg: <svg width="14" height="14" viewBox="0 0 14 14"><line x1="1" y1="13" x2="13" y2="13" stroke="#1e293b" strokeWidth="2"/><rect x="1" y="1" width="12" height="12" fill="none" stroke="#cbd5e1" strokeWidth="0.5"/></svg> },
    { label: 'No Border',     value: 'none',   svg: <svg width="14" height="14" viewBox="0 0 14 14"><rect x="1" y="1" width="12" height="12" fill="none" stroke="#cbd5e1" strokeWidth="1" strokeDasharray="2 2"/></svg> },
  ];
  return (
    <div style={{ position: 'absolute', top: '100%', left: 0, zIndex: 100, background: 'white', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '8px', boxShadow: '0 8px 24px rgba(0,0,0,0.12)', minWidth: '160px' }}>
      {borders.map(b => (
        <button key={b.label} onClick={() => { onSelect(b.value); onClose(); }} style={{ width: '100%', padding: '7px 12px', textAlign: 'left', background: 'none', border: 'none', borderRadius: '6px', fontSize: '13px', color: '#1e293b', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '10px', fontWeight: 500 }} onMouseEnter={e => e.currentTarget.style.background = '#f1f5f9'} onMouseLeave={e => e.currentTarget.style.background = 'none'}>
          {b.svg} {b.label}
        </button>
      ))}
    </div>
  );
};

// ─── MAIN EDITOR COMPONENT ───────────────────────────────────────────────────
// Wrapped with forwardRef so the Orchestrator Engine can acquire a ref
// and call imperative methods (insertAtPos, appendToken, setEditable, etc.)
// without going through React props/state.

const PathScribeEditor = forwardRef<PathScribeEditorHandle, PathScribeEditorProps>((
  {
    content = '',
    onChange,
    approvedFonts = ['Arial', 'Times New Roman', 'Courier New', 'Calibri'],
    macros = [],
    placeholder: _placeholder = 'Begin typing or use a macro trigger (e.g. ;gs)...',
    minHeight = '400px',
    readOnly = false,
    suppressToolbar = false,
    toolbarPortalId,
    theme: themeProp = 'light',
    allowThemeToggle = false,
    tabWidthChars = DEFAULT_TAB_WIDTH_CHARS,
    onTabWidthChange,
  },
  ref
) => {
  // themeProp is only the STARTING point -- see allowThemeToggle's doc
  // comment above. A real saved user preference, once one exists, always
  // wins over whatever theme an individual screen was built with.
  const THEME_PREF_KEY = 'ps-editor-theme-preference';
  const [activeThemeName, setActiveThemeName] = useState<'light' | 'dark'>(() => {
    if (!allowThemeToggle) return themeProp;
    try {
      const saved = localStorage.getItem(THEME_PREF_KEY);
      if (saved === 'light' || saved === 'dark') return saved;
    } catch { /* ignore */ }
    return themeProp;
  });
  const theme = activeThemeName === 'dark' ? DARK_THEME : LIGHT_THEME;
  const toggleTheme = () => {
    const next = activeThemeName === 'dark' ? 'light' : 'dark';
    setActiveThemeName(next);
    try { localStorage.setItem(THEME_PREF_KEY, next); } catch { /* ignore quota errors */ }
  };

  // ── UI State ──────────────────────────────────────────────────────────────
  const [showFormatMarks, setShowFormatMarks] = useState(false);
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [showTablePicker, setShowTablePicker] = useState(false);
  const [showMacroModal, setShowMacroModal]   = useState(false);
  const [macroModalSearch, setMacroModalSearch] = useState('');
  const [showFontColor, setShowFontColor]     = useState(false);
  const [showHighlight, setShowHighlight]     = useState(false);
  const [showShading, setShowShading]         = useState(false);
  const [showBorder, setShowBorder]           = useState(false);
  const [showSpacing, setShowSpacing]         = useState(false);
  const [showTabWidthMenu, setShowTabWidthMenu] = useState(false);
  const [selectedFont, setSelectedFont]       = useState(approvedFonts[0] || 'Arial');
  const [fontSize, setFontSize]               = useState('12');

  const editorWrapperRef = useRef<HTMLDivElement>(null);

  // ── Editor Setup ──────────────────────────────────────────────────────────
  const handleUnknownTrigger = useCallback((partial: string) => {
    setMacroModalSearch(partial);
    setShowMacroModal(true);
  }, []);

  const macroExtension = React.useMemo(
    () => createMacroExtension(macros, handleUnknownTrigger),
    [macros, handleUnknownTrigger]
  );

  const tabExtension = React.useMemo(
    () => createTabExtension(tabWidthChars),
    [tabWidthChars]
  );

  // Tracks whether the next content-prop change originated from this
  // editor's own typing (via onUpdate) vs. an external source (AI
  // generation, template switch). See the content-sync useEffect below.
  const isInternalChange = useRef(false);

  const editor = useEditor({
    extensions: [
      StarterKit.configure({ underline: false, paragraph: false }),
      ShadedParagraph,
      FontSize, FontFamily, Color, Underline, Subscript, Superscript,
      Highlight.configure({ multicolor: true }),
      TextAlign.configure({ types: ['heading', 'paragraph'] }),
      Table.configure({ resizable: true }),
      TableRow, TableHeader, TableCell,
      macroExtension, tabExtension, FormatMarksExtension,
    ],
    content,
    editable: !readOnly,
    onUpdate: ({ editor }) => {
      isInternalChange.current = true;
      onChange?.(editor.getHTML());
    },
    onSelectionUpdate: ({ editor }) => {
      // Keep the font/size dropdowns honest — show what's actually at the
      // cursor or selection, not just "whatever was last picked." Without
      // this, the dropdown looked unresponsive: picking a font for a
      // selection would apply correctly (as an inline mark) but the
      // dropdown itself wouldn't reflect it when you clicked elsewhere,
      // making it seem like font changes weren't taking effect at all.
      const attrs = editor.getAttributes('textStyle');
      const fontAttr = attrs.fontFamily as string | undefined;
      setSelectedFont(fontAttr || approvedFonts[0] || 'Arial');
      const sizeAttr = attrs.fontSize as string | undefined; // e.g. "14pt"
      setFontSize(sizeAttr ? sizeAttr.replace(/pt$/, '') : '12');
    },
    editorProps: {
      attributes: { class: 'ps-editor-content', spellcheck: 'true' },
    },
  });

  // Keep the module-level ref in sync with state, and force ProseMirror to
  // recompute decorations immediately (decorations() only re-runs when the
  // editor state changes, so a no-op transaction nudges it after toggling).
  useEffect(() => {
    formatMarksVisibleRef.current = showFormatMarks;
    if (editor) {
      editor.view.dispatch(editor.state.tr);
    }
  }, [showFormatMarks, editor]);

  // ── Imperative handle — exposes the editor to the Orchestrator ────────────
  useImperativeHandle(ref, () => ({
    getEditor: () => editor ?? null,

    insertAtPos: (pos: number, html: string) => {
      editor
        ?.chain()
        .insertContentAt(pos, html, {
          updateSelection: false,
          parseOptions: { preserveWhitespace: 'full' },
        })
        .run();
    },

    appendToken: (token: string) => {
      const end = editor?.state.doc.content.size ?? 0;
      editor
        ?.chain()
        .insertContentAt(end, token, {
          updateSelection: false,
          parseOptions: { preserveWhitespace: 'full' },
        })
        .run();
    },

    setContent: (html: string) => {
      editor?.commands.setContent(html);
    },

    clearContent: () => {
      editor?.commands.clearContent();
    },

    focus: () => {
      editor?.chain().focus().run();
    },

    isEditable: () => editor?.isEditable ?? false,

    setEditable: (editable: boolean) => {
      editor?.setEditable(editable);
    },
  }), [editor]);

  // ── Listen for macro insert events ────────────────────────────────────────
  useEffect(() => {
    const wrapper = editorWrapperRef.current;
    if (!wrapper || !editor) return;
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      if (detail?.content) {
        editor.chain().focus().insertContent(detail.content).run();
      }
    };
    wrapper.addEventListener('insertMacroContent', handler);
    return () => wrapper.removeEventListener('insertMacroContent', handler);
  }, [editor]);

  // ── Update content when prop changes ──────────────────────────────────────
  // IMPORTANT: only apply external content changes (AI generation, template
  // switch, etc.) — never re-apply content that originated from this editor's
  // own typing. Without this guard, every keystroke triggers React re-render
  // → new content prop → setContent() → which can silently drop or collapse
  // characters (notably trailing/plain spaces, which HTML serializers treat
  // as collapsible whitespace) and resets the cursor to the start.

  useEffect(() => {
    if (!editor) return;
    if (isInternalChange.current) {
      isInternalChange.current = false;
      return;
    }
    if (content !== editor.getHTML()) {
      editor.commands.setContent(content, { emitUpdate: false }); // don't emit another update event
    }
  }, [content, editor]);

  const insertMacro = (macro: Macro) => {
    editor?.chain().focus().insertContent(macro.content).run();
  };

  // ── Close dropdowns on outside click ─────────────────────────────────────
  useEffect(() => {
    const handler = () => {
      setShowFindReplace(false); setShowTablePicker(false);
      setShowFontColor(false);   setShowHighlight(false);
      setShowBorder(false);      setShowSpacing(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  if (!editor) return (
    <div style={{ border: '1px solid #e2e8f0', borderRadius: '12px', overflow: 'hidden', background: 'white', minHeight, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <span style={{ fontSize: '12px', color: '#94a3b8' }}>Loading editor…</span>
    </div>
  );

  const IC = 14;

  const renderToolbar = () => (
    <div onMouseDown={e => e.stopPropagation()} style={{ display: 'flex', flexWrap: 'wrap', gap: '1px', alignItems: 'center', padding: '6px 8px', background: theme.toolbarBg, borderBottom: `1px solid ${theme.toolbarBorder}`, borderRadius: '10px 10px 0 0' }}>
      <select value={selectedFont} onChange={e => { setSelectedFont(e.target.value); editor.chain().focus().setFontFamily(e.target.value).run(); }} style={{ padding: '3px 6px', height: '26px', border: `1px solid ${theme.inputBorder}`, borderRadius: '5px', fontSize: '12px', fontWeight: 500, color: theme.inputText, background: theme.inputBg, cursor: 'pointer', maxWidth: '140px' }}>
        {approvedFonts.map(f => <option key={f} value={f} style={{ color: theme.panelText, background: theme.panelBg }}>{f}</option>)}
      </select>
      <select value={fontSize} onChange={e => { setFontSize(e.target.value); (editor.chain().focus() as any).setFontSize(`${e.target.value}pt`).run(); }} style={{ padding: '3px 4px', height: '26px', border: `1px solid ${theme.inputBorder}`, borderRadius: '5px', fontSize: '12px', color: theme.inputText, background: theme.inputBg, cursor: 'pointer', width: '48px' }}>
        {['8','9','10','11','12','14','16','18','20','24','28','32','36','48','72'].map(s => <option key={s} value={s} style={{ color: theme.panelText, background: theme.panelBg }}>{s}</option>)}
      </select>
      <Divider />
      <TBtn onClick={() => editor.chain().focus().toggleBold().run()} isActive={editor.isActive('bold')} title="Bold (Ctrl+B)"><Bold size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().toggleItalic().run()} isActive={editor.isActive('italic')} title="Italic (Ctrl+I)"><Italic size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().toggleUnderline().run()} isActive={editor.isActive('underline')} title="Underline (Ctrl+U)"><UnderlineIcon size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().toggleStrike().run()} isActive={editor.isActive('strike')} title="Strikethrough"><Strikethrough size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().toggleSubscript().run()} isActive={editor.isActive('subscript')} title="Subscript"><SubscriptIcon size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().toggleSuperscript().run()} isActive={editor.isActive('superscript')} title="Superscript"><SuperscriptIcon size={IC} /></TBtn>
      <Divider />
      <div style={{ position: 'relative' }} onMouseDown={e => e.stopPropagation()}>
        <TBtn onClick={() => { setShowFontColor(v => !v); setShowHighlight(false); setShowShading(false); setShowBorder(false); setShowSpacing(false); }} title="Font Color">
          <span style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', lineHeight: 1 }}><Baseline size={IC} /><span style={{ width: '14px', height: '3px', background: '#dc2626', borderRadius: '1px', marginTop: '1px' }} /></span>
        </TBtn>
        {showFontColor && <ColorPicker title="Font Color" onSelect={color => color ? editor.chain().focus().setColor(color).run() : editor.chain().focus().unsetColor().run()} onClose={() => setShowFontColor(false)} />}
      </div>
      <div style={{ position: 'relative' }} onMouseDown={e => e.stopPropagation()}>
        <TBtn onClick={() => { setShowHighlight(v => !v); setShowFontColor(false); setShowShading(false); setShowBorder(false); setShowSpacing(false); }} title="Text Highlight Color">
          <span style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', lineHeight: 1 }}><Highlighter size={IC} /><span style={{ width: '14px', height: '3px', background: '#fde047', borderRadius: '1px', marginTop: '1px' }} /></span>
        </TBtn>
        {showHighlight && <ColorPicker title="Highlight" onSelect={color => color ? editor.chain().focus().setHighlight({ color }).run() : editor.chain().focus().unsetHighlight().run()} onClose={() => setShowHighlight(false)} />}
      </div>
      <Divider />
      <TBtn onClick={() => editor.chain().focus().setTextAlign('left').run()} isActive={editor.isActive({ textAlign: 'left' })} title="Align Left"><AlignLeft size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().setTextAlign('center').run()} isActive={editor.isActive({ textAlign: 'center' })} title="Align Center"><AlignCenter size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().setTextAlign('right').run()} isActive={editor.isActive({ textAlign: 'right' })} title="Align Right"><AlignRight size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().setTextAlign('justify').run()} isActive={editor.isActive({ textAlign: 'justify' })} title="Justify"><AlignJustify size={IC} /></TBtn>
      <Divider />
      <TBtn onClick={() => editor.chain().focus().toggleBulletList().run()} isActive={editor.isActive('bulletList')} title="Bullet List"><List size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().toggleOrderedList().run()} isActive={editor.isActive('orderedList')} title="Numbered List"><ListOrdered size={IC} /></TBtn>
      <Divider />
      <TBtn onClick={() => editor.chain().focus().sinkListItem('listItem').run()} title="Increase Indent" disabled={!editor.can().sinkListItem('listItem')}><IndentIncrease size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().liftListItem('listItem').run()} title="Decrease Indent" disabled={!editor.can().liftListItem('listItem')}><IndentDecrease size={IC} /></TBtn>
      <Divider />
      <TBtn onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()} isActive={editor.isActive('heading', { level: 1 })} title="Heading 1"><Heading1 size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()} isActive={editor.isActive('heading', { level: 2 })} title="Heading 2"><Heading2 size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()} isActive={editor.isActive('heading', { level: 3 })} title="Heading 3"><Heading3 size={IC} /></TBtn>
      <Divider />
      <div style={{ position: 'relative' }} onMouseDown={e => e.stopPropagation()}>
        <TBtn onClick={() => { setShowSpacing(v => !v); setShowFontColor(false); setShowHighlight(false); setShowShading(false); setShowBorder(false); }} title="Line & Paragraph Spacing"><ArrowUpDown size={IC} /></TBtn>
        {showSpacing && <SpacingDropdown editor={editor} onClose={() => setShowSpacing(false)} />}
      </div>
      <TBtn onClick={() => setShowFormatMarks(v => !v)} isActive={showFormatMarks} title="Show/Hide Formatting Marks (¶)"><PilcrowSquare size={IC} /></TBtn>
      <Divider />
      <div style={{ position: 'relative' }} onMouseDown={e => e.stopPropagation()}>
        <TBtn onClick={() => { setShowShading(v => !v); setShowFontColor(false); setShowHighlight(false); setShowBorder(false); setShowSpacing(false); }} title="Paragraph Shading — whole-paragraph background">
          <PaintBucket size={IC} />
        </TBtn>
        {showShading && (
          <ColorPicker
            title="Paragraph Shading"
            onSelect={color => (editor.chain().focus() as any).setParagraphShading(color).run()}
            onClose={() => setShowShading(false)}
          />
        )}
      </div>
      <div style={{ position: 'relative' }} onMouseDown={e => e.stopPropagation()}>
        <TBtn onClick={() => { setShowBorder(v => !v); setShowFontColor(false); setShowHighlight(false); setShowShading(false); setShowSpacing(false); }} title="Borders"><SquareDashedBottom size={IC} /></TBtn>
        {showBorder && (
          <BorderDropdown
            onSelect={style => (editor.chain().focus() as any).setParagraphBorder(style).run()}
            onClose={() => setShowBorder(false)}
          />
        )}
      </div>
      <Divider />
      <div style={{ position: 'relative' }} onMouseDown={e => e.stopPropagation()}>
        <TBtn onClick={() => { setShowTablePicker(v => !v); setShowFindReplace(false); }} isActive={showTablePicker} title="Insert Table"><TableIcon size={IC} /></TBtn>
        {showTablePicker && <InsertTableModal onInsert={(rows, cols) => { editor.chain().focus().insertTable({ rows, cols, withHeaderRow: true }).run(); }} onClose={() => setShowTablePicker(false)} />}
      </div>
      {editor.isActive('table') && (
        <>
          <Divider />
          <TBtn onClick={() => editor.chain().focus().addColumnAfter().run()} title="Add Column After"><Columns3 size={IC} /></TBtn>
          <TBtn onClick={() => editor.chain().focus().addRowAfter().run()} title="Add Row After"><Rows3 size={IC} /></TBtn>
          <TBtn onClick={() => editor.chain().focus().deleteColumn().run()} title="Delete Column"><span style={{ position: 'relative', display: 'inline-flex' }}><Columns3 size={IC} /><X size={8} style={{ position: 'absolute', top: -2, right: -3, color: '#ef4444' }} /></span></TBtn>
          <TBtn onClick={() => editor.chain().focus().deleteRow().run()} title="Delete Row"><span style={{ position: 'relative', display: 'inline-flex' }}><Rows3 size={IC} /><X size={8} style={{ position: 'absolute', top: -2, right: -3, color: '#ef4444' }} /></span></TBtn>
          <TBtn onClick={() => editor.chain().focus().mergeCells().run()} title="Merge Cells"><Combine size={IC} /></TBtn>
          <TBtn onClick={() => editor.chain().focus().splitCell().run()} title="Split Cell"><SplitSquareHorizontal size={IC} /></TBtn>
          <TBtn onClick={() => editor.chain().focus().deleteTable().run()} title="Delete Table"><span style={{ position: 'relative', display: 'inline-flex' }}><TableIcon size={IC} /><X size={8} style={{ position: 'absolute', top: -2, right: -3, color: '#ef4444' }} /></span></TBtn>
        </>
      )}
      <Divider />
      <TBtn onClick={() => { setMacroModalSearch(''); setShowMacroModal(true); }} title="Insert Macro (or type trigger + Space)" width="68px"><Zap size={IC} /><span style={{ fontSize: '11px', fontWeight: 700 }}>Macro</span></TBtn>
      <Divider />
      <TBtn onClick={() => { const sig = `<p><br/></p><p>_____________________________ &nbsp;&nbsp;&nbsp; Date: ___________</p><p><em>Pathologist Signature</em></p><p><br/></p>`; editor.chain().focus().insertContent(sig).run(); }} title="Insert Signature Line"><PenLine size={IC} /></TBtn>
      <Divider />
      <div style={{ position: 'relative' }} onMouseDown={e => e.stopPropagation()}>
        <TBtn onClick={() => { setShowFindReplace(v => !v); setShowTablePicker(false); }} isActive={showFindReplace} title="Find & Replace (Ctrl+F)"><Search size={IC} /></TBtn>
        {showFindReplace && <FindReplacePanel editor={editor} onClose={() => setShowFindReplace(false)} />}
      </div>
      <Divider />
      <TBtn onClick={() => editor.chain().focus().undo().run()} disabled={!editor.can().undo()} title="Undo (Ctrl+Z)"><Undo2 size={IC} /></TBtn>
      <TBtn onClick={() => editor.chain().focus().redo().run()} disabled={!editor.can().redo()} title="Redo (Ctrl+Shift+Z)"><Redo2 size={IC} /></TBtn>
      {allowThemeToggle && (
        <TBtn onClick={toggleTheme} title={activeThemeName === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}>
          {activeThemeName === 'dark' ? <Sun size={IC} /> : <Moon size={IC} />}
        </TBtn>
      )}
      <Divider />
      <div style={{ position: 'relative' }} onMouseDown={e => e.stopPropagation()}>
        <TBtn onClick={() => setShowTabWidthMenu(v => !v)} isActive={showTabWidthMenu} title={`Tab width: ${tabWidthChars} spaces`} width="auto">
          Tab: {tabWidthChars}
        </TBtn>
        {showTabWidthMenu && (
          <div style={{ position: 'absolute', top: '32px', left: 0, background: theme.panelBg, border: `1px solid ${theme.panelBorder}`, borderRadius: '8px', padding: '6px', boxShadow: theme.panelShadow, zIndex: 50, minWidth: '90px' }}>
            {[2, 4, 6, 8].map(n => (
              <button key={n} onClick={() => { onTabWidthChange?.(n); setShowTabWidthMenu(false); }}
                style={{ display: 'block', width: '100%', padding: '6px 10px', textAlign: 'left', background: n === tabWidthChars ? theme.btnBgActive : 'none', color: n === tabWidthChars ? theme.btnTextActive : theme.panelText, border: 'none', borderRadius: '5px', fontSize: '12px', cursor: 'pointer', fontWeight: 500 }}
              >
                {n} spaces
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <EditorThemeContext.Provider value={theme}>
    <div ref={editorWrapperRef} style={{ display: 'flex', flexDirection: 'column', border: `1px solid ${theme.contentBorder}`, borderRadius: '12px', background: theme.contentBg }}>

      {/* Toolbar — portal-aware:
          suppressToolbar=false (default) → inline (backward compat for every
          other usage of this component across the app)
          suppressToolbar=true + toolbarPortalId → portal to shared sticky header
          suppressToolbar=true + no portalId → render nothing (unfocused instance) */}
      {!suppressToolbar && renderToolbar()}
      {suppressToolbar && toolbarPortalId && (() => {
        const node = typeof document !== 'undefined' ? document.getElementById(toolbarPortalId) : null;
        return node ? createPortal(renderToolbar(), node) : null;
      })()}

      <div style={{ flex: 1, overflowY: 'auto', minHeight, borderRadius: '0 0 12px 12px' }}>
        <EditorContent editor={editor} />
      </div>

      {showMacroModal && (
        <MacroModal macros={macros} initialSearch={macroModalSearch} onSelect={insertMacro} onClose={() => { setShowMacroModal(false); setMacroModalSearch(''); }} />
      )}

      <style>{`
        .ps-editor-content { padding: 20px 24px; min-height: ${minHeight}; outline: none; font-size: 12pt; line-height: 1.8; color: #1e293b; font-family: ${approvedFonts[0] || 'Arial'}, sans-serif; }
        .ps-editor-content:focus { outline: none; }
        .ps-editor-content p { margin: 0 0 10px 0; }
        .ps-editor-content strong { font-weight: 700; }
        .ps-editor-content em { font-style: italic; }
        .ps-editor-content u { text-decoration: underline; }
        .ps-editor-content s { text-decoration: line-through; }
        .ps-editor-content ul, .ps-editor-content ol { padding-left: 28px; margin: 10px 0; }
        .ps-editor-content li { margin: 4px 0; }
        .ps-editor-content h1 { font-size: 24px; font-weight: 700; margin: 16px 0 10px; }
        .ps-editor-content h2 { font-size: 20px; font-weight: 700; margin: 14px 0 8px; }
        .ps-editor-content h3 { font-size: 16px; font-weight: 700; margin: 12px 0 6px; }
        .ps-editor-content table { border-collapse: collapse; width: 100%; margin: 12px 0; }
        .ps-editor-content th, .ps-editor-content td { border: 1px solid #cbd5e1; padding: 8px 12px; min-width: 60px; vertical-align: top; }
        .ps-editor-content th { background: #f1f5f9; font-weight: 700; text-align: left; }
        .ps-editor-content .selectedCell:after { background: rgba(8,145,178,0.12); content: ''; left: 0; right: 0; top: 0; bottom: 0; pointer-events: none; position: absolute; z-index: 2; }
        .ps-editor-content .tableWrapper { overflow-x: auto; }
        .ps-editor-content .ps-tab { display: inline-block; white-space: pre; }
        /* Show Formatting Marks — visible dots over space characters.
           Regular spaces (typed by hitting spacebar) get a light grey dot;
           non-breaking spaces (inserted by Tab) get a teal dot so the two
           are visually distinguishable when debugging whitespace. */
        .ps-fm-space, .ps-fm-nbsp { position: relative; }
        .ps-fm-space::after, .ps-fm-nbsp::after {
          content: '·';
          position: absolute;
          left: 0; right: 0; top: -2px;
          text-align: center;
          font-weight: 700;
          pointer-events: none;
        }
        .ps-fm-space::after { color: #94a3b8; }
        .ps-fm-nbsp::after  { color: #0891B2; }
        .ai-generated-content { background: rgba(8,145,178,0.04); border-left: 2px solid rgba(8,145,178,0.25); padding-left: 8px; transition: background 0.2s; }
        .user-edited-content  { background: rgba(251,191,36,0.04); border-left: 2px solid rgba(251,191,36,0.25); padding-left: 8px; }
        ${showFormatMarks ? `
          .ps-editor-content p::after { content: '¶'; color: #94a3b8; font-size: 10px; margin-left: 2px; }
          .ps-editor-content br::after { content: '↵'; color: #94a3b8; font-size: 10px; }
          .ps-editor-content .ps-tab { background: rgba(8,145,178,0.08); outline: 1px dashed #bae6fd; position: relative; }
          .ps-editor-content .ps-tab::before { content: '→'; color: #94a3b8; font-size: 9px; position: absolute; left: 2px; top: 50%; transform: translateY(-50%); }
        ` : ''}
      `}</style>
    </div>
    </EditorThemeContext.Provider>
  );
});

PathScribeEditor.displayName = 'PathScribeEditor';

export default PathScribeEditor;
