// src/components/Config/System/PatientMatchReviewSection.tsx
// ─────────────────────────────────────────────────────────────────────────────
// Real review queue for the MPI's 'ambiguous' outcomes — every record
// resolveOrCreatePatient() couldn't confidently match one way or the
// other, per services/patients/IPatientIndexService.ts's own reasoning:
// a deterministic matcher that only ever auto-matches or auto-creates,
// with nothing routed to a human, would either silently merge two
// different people's histories or silently fragment one person's
// history across duplicate records — either is a real patient-safety
// problem, not a cosmetic one. This is the screen that closes the loop:
// without it, an ambiguous match gets flagged and then never actually
// looked at by anyone.
//
// Scoped the same way as the QA tabs' cross-tenant access
// (services/auth/caseAccessControl.ts's canViewCrossTenantQaData) — a
// standard user reviews their own organisation's queue only; a
// cross-tenant-permitted admin can pick any organisation.
// ─────────────────────────────────────────────────────────────────────────────
import React, { useEffect, useState } from 'react';
import '../../../pathscribe.css';
import { mockPatientIndexService } from '@/services/patients/mockPatientIndexService';
import type { MasterPatientRecord } from '@/services/patients/IPatientIndexService';
import { listOrganisations } from '@/services/organisation/organisationService';
import type { Organisation } from '@/services/organisation/organisationService';
import { getSessionUser, canViewCrossTenantQaData } from '@/services/auth/caseAccessControl';
import ConfirmModal from '../../Common/ConfirmModal';

const PatientMatchReviewSection: React.FC = () => {
  const session = getSessionUser();
  const crossTenant = canViewCrossTenantQaData(session);

  const [organisations, setOrganisations] = useState<Organisation[]>([]);
  const [selectedOrgId, setSelectedOrgId] = useState<string>(session?.organisationId ?? '');
  const [pending, setPending] = useState<MasterPatientRecord[]>([]);
  const [candidateDetails, setCandidateDetails] = useState<Record<string, MasterPatientRecord>>({});
  const [loading, setLoading] = useState(true);
  const [mergeTarget, setMergeTarget] = useState<{ provisional: MasterPatientRecord; candidate: MasterPatientRecord } | null>(null);
  const [actionInFlight, setActionInFlight] = useState<string | null>(null);
  const [lastMergeCount, setLastMergeCount] = useState<number | null>(null);

  useEffect(() => {
    if (crossTenant) {
      listOrganisations().then(orgs => setOrganisations(orgs.filter(o => o.active)));
    }
  }, [crossTenant]);

  const loadQueue = React.useCallback(async () => {
    if (!selectedOrgId) { setPending([]); setLoading(false); return; }
    setLoading(true);
    const records = await mockPatientIndexService.listPendingReview(selectedOrgId);
    setPending(records);
    // Real candidate detail lookup — the queue needs to show WHO each
    // flagged record might actually be (name, MRN, DOB), not just an
    // opaque id, or a reviewer has nothing to actually compare against.
    const ids = Array.from(new Set(records.flatMap(r => r.reviewCandidateIds ?? [])));
    const details: Record<string, MasterPatientRecord> = {};
    await Promise.all(ids.map(async id => {
      const rec = await mockPatientIndexService.getById(id);
      if (rec) details[id] = rec;
    }));
    setCandidateDetails(details);
    setLoading(false);
  }, [selectedOrgId]);

  useEffect(() => { loadQueue(); }, [loadQueue]);

  const handleConfirmNew = async (record: MasterPatientRecord) => {
    setActionInFlight(record.id);
    await mockPatientIndexService.confirmAsNewPatient(record.id);
    setActionInFlight(null);
    loadQueue();
  };

  const handleMergeConfirmed = async () => {
    if (!mergeTarget) return;
    setActionInFlight(mergeTarget.provisional.id);
    const result = await mockPatientIndexService.mergeIntoExistingPatient(mergeTarget.provisional.id, mergeTarget.candidate.id);
    setActionInFlight(null);
    setLastMergeCount(result.casesRepointed);
    setMergeTarget(null);
    loadQueue();
  };

  return (
    <div style={{ width: '100%', maxWidth: 960 }}>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: '#fff', margin: 0 }}>Patient Match Review</h1>
        <p style={{ fontSize: 13, color: '#6b7280', marginTop: 4 }}>
          Cases where a new patient's MRN, name, or date of birth partially matched an
          existing record — never auto-resolved, since a wrong guess here means
          showing one patient's history against another's case. Each one needs a
          real decision: confirm this is genuinely a new patient, or merge it into
          the existing record it likely belongs to.
        </p>
      </div>

      {crossTenant && (
        <div style={{ marginBottom: 16 }}>
          <label className="ps-conf-label" style={{ display: 'block', marginBottom: 6 }}>Organisation</label>
          <select
            value={selectedOrgId}
            onChange={e => setSelectedOrgId(e.target.value)}
            className="ps-conf-select"
            style={{ width: 320 }}
          >
            <option value="">Select an organisation…</option>
            {organisations.map(o => (
              <option key={o.id} value={o.id}>{o.name}</option>
            ))}
          </select>
        </div>
      )}

      {lastMergeCount !== null && (
        <div style={{ marginBottom: 16, padding: '10px 14px', background: 'rgba(34,197,94,0.1)', border: '1px solid rgba(34,197,94,0.3)', borderRadius: 8, fontSize: 13, color: '#4ade80' }}>
          ✓ Merged — {lastMergeCount} case{lastMergeCount === 1 ? '' : 's'} repointed to the confirmed patient record.
        </div>
      )}

      {loading ? (
        <div style={{ color: '#6b7280', fontSize: 13, padding: '24px 0' }}>Loading review queue…</div>
      ) : !selectedOrgId ? (
        <div style={{ color: '#6b7280', fontSize: 13, padding: '24px 0' }}>Select an organisation to review its pending matches.</div>
      ) : pending.length === 0 ? (
        <div style={{ border: '1px solid #1f2937', borderRadius: 12, padding: 24, color: '#6b7280', fontSize: 13 }}>
          Nothing pending review for this organisation.
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {pending.map(record => (
            <div key={record.id} style={{ border: '1px solid #1f2937', borderRadius: 12, padding: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: '#e5e7eb' }}>
                    {record.lastName}, {record.firstName}
                  </div>
                  <div style={{ fontSize: 12, color: '#6b7280', marginTop: 2 }}>
                    MRN {record.mrn} · DOB {new Date(record.dateOfBirth).toLocaleDateString()}
                  </div>
                </div>
                <span style={{ fontSize: 11, fontWeight: 600, color: '#fbbf24', background: 'rgba(251,191,36,0.1)', border: '1px solid rgba(251,191,36,0.3)', borderRadius: 999, padding: '3px 10px' }}>
                  Needs Review
                </span>
              </div>

              <div style={{ fontSize: 12, color: '#94a3b8', marginBottom: 14 }}>
                {record.reviewReason}
              </div>

              {(record.reviewCandidateIds ?? []).length > 0 && (
                <div style={{ marginBottom: 14 }}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>
                    Possible existing match{(record.reviewCandidateIds ?? []).length === 1 ? '' : 'es'}
                  </div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {(record.reviewCandidateIds ?? []).map(candId => {
                      const cand = candidateDetails[candId];
                      if (!cand) return null;
                      return (
                        <div key={candId} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, padding: '10px 14px' }}>
                          <div>
                            <div style={{ fontSize: 13, color: '#e5e7eb' }}>{cand.lastName}, {cand.firstName}</div>
                            <div style={{ fontSize: 11, color: '#6b7280' }}>MRN {cand.mrn} · DOB {new Date(cand.dateOfBirth).toLocaleDateString()}</div>
                          </div>
                          <button
                            type="button"
                            className="ps-conf-btn-secondary"
                            disabled={actionInFlight === record.id}
                            onClick={() => setMergeTarget({ provisional: record, candidate: cand })}
                          >
                            Merge into this patient
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <button
                  type="button"
                  className="ps-conf-btn-secondary"
                  disabled={actionInFlight === record.id}
                  onClick={() => handleConfirmNew(record)}
                >
                  {actionInFlight === record.id ? 'Confirming…' : 'Confirm as new patient'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <ConfirmModal
        show={!!mergeTarget}
        title="Merge patient records"
        message={mergeTarget
          ? `This will merge ${mergeTarget.provisional.lastName}, ${mergeTarget.provisional.firstName} (MRN ${mergeTarget.provisional.mrn}) into the existing record for ${mergeTarget.candidate.lastName}, ${mergeTarget.candidate.firstName} (MRN ${mergeTarget.candidate.mrn}). Every case currently on the provisional record will be repointed to the confirmed one. This cannot be undone from this screen.`
          : ''}
        confirmLabel="Merge"
        cancelLabel="Cancel"
        onConfirm={handleMergeConfirmed}
        onCancel={() => setMergeTarget(null)}
      />
    </div>
  );
};

export default PatientMatchReviewSection;
