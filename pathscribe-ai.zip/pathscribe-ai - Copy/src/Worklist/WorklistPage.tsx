import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { useLogout } from '../useLogout';
import { SunIcon, MoonIcon, HelpIcon, MonitorIcon } from '../components/Icons';
import { PathologyCase } from './types';
import WorklistTable from './WorklistTable';
import CaseSearchBar from '../components/CaseSearchBar';

const WorklistPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const handleLogout = useLogout();
  const [activeFilter, setActiveFilter] = useState<'all' | 'review' | 'completed'>('all');
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isResourcesOpen, setIsResourcesOpen] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const [currentTheme, setCurrentTheme] = useState<'light' | 'dark' | 'auto'>('dark');
  
  const [showLogoutWarning, setShowLogoutWarning] = useState(false);

const handleNavigateHome = () => {
  navigate('/');
};



  // Quick Links Data
  const quickLinks = {
    protocols: [
      { title: 'CAP Cancer Protocols', url: 'https://www.cap.org/protocols-and-guidelines' },
      { title: 'WHO Classification', url: 'https://www.who.int/publications' }
    ],
    references: [
      { title: 'PathologyOutlines', url: 'https://www.pathologyoutlines.com' },
      { title: 'UpToDate', url: 'https://www.uptodate.com' }
    ],
    systems: [
      { title: 'Hospital LIS', url: '#' },
      { title: 'Lab Management', url: '#' }
    ]
  };

  // Mock data representing cases at different stages
  const allCases: PathologyCase[] = [
    { 
      id: 'S26-4401', 
      patient: 'Miller, Jane', 
      protocol: 'Breast Invasive Carcinoma', 
      specimen: 'Left Breast Mastectomy',
      status: 'Grossed', 
      aiStatus: 'Draft Ready', 
      confidence: 94,
      time: '2h ago', 
      priority: 'Routine' 
    },
    { 
      id: 'S26-4402', 
      patient: 'Smith, Alice', 
      protocol: 'Lung Resection', 
      specimen: 'Right Upper Lobe Wedge',
      status: 'Awaiting Micro', 
      aiStatus: 'Staged', 
      confidence: 0,
      time: '45m ago', 
      priority: 'STAT' 
    },
    { 
      id: 'S26-4405', 
      patient: 'Davis, Robert', 
      protocol: 'Colon Resection', 
      specimen: 'Right Hemicolectomy',
      status: 'Finalizing', 
      aiStatus: 'Syncing Micro...', 
      confidence: 89,
      time: '5m ago', 
      priority: 'Routine' 
    },
    { 
      id: 'S26-4410', 
      patient: 'Wilson, Karen', 
      protocol: 'Prostatectomy', 
      specimen: 'Radical Prostatectomy',
      status: 'Grossed', 
      aiStatus: 'Draft Ready', 
      confidence: 96,
      time: '1h ago', 
      priority: 'Routine' 
    },
    { 
      id: 'S26-4412', 
      patient: 'Johnson, Michael', 
      protocol: 'Breast Invasive Carcinoma', 
      specimen: 'Right Breast Lumpectomy',
      status: 'Completed', 
      aiStatus: 'Finalized', 
      confidence: 97,
      time: '3h ago', 
      priority: 'Routine' 
    }
  ];

  const filteredCases = allCases.filter(c => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'review') return c.aiStatus === 'Draft Ready';
    if (activeFilter === 'completed') return c.status === 'Completed';
    return true;
  });

  const stats = {
    grossedToday: allCases.filter(c => c.status === 'Grossed').length,
    pendingMicro: allCases.filter(c => c.status === 'Awaiting Micro').length,
    needsReview: allCases.filter(c => c.aiStatus === 'Draft Ready').length
  };

  return (
    <div style={{ 
      position: 'relative', 
      width: '100vw', 
      height: '100vh', 
      backgroundColor: '#000000', 
      color: '#ffffff', 
      fontFamily: "'Inter', sans-serif",
      transition: 'opacity 0.6s ease',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }}>
      {/* Background */}
      <div style={{ 
        position: 'absolute', 
        inset: 0, 
        backgroundImage: 'url(/main_background.jpg)', 
        backgroundSize: 'cover', 
        backgroundPosition: 'center', 
        zIndex: 0,
        filter: 'brightness(0.3) contrast(1.1)'
      }} />
      <div style={{ 
        position: 'absolute', 
        inset: 0, 
        background: 'linear-gradient(to bottom, rgba(0,0,0,0.4) 0%, #000000 100%)', 
        zIndex: 1 
      }} />

      {/* Content */}
      <div style={{ position: 'relative', zIndex: 10, display: 'flex', flexDirection: 'column', height: '100%' }}>
        
        {/* Top Navigation */}
        <nav style={{ 
          padding: '20px 40px', 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          background: 'rgba(0, 0, 0, 0.4)', 
          backdropFilter: 'blur(12px)', 
          borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
            <img 
              src="/pathscribe-logo-dark.svg" 
              alt="PathScribe AI" 
              style={{ height: '60px', width: 'auto', cursor: 'pointer' }} 
              onClick={handleNavigateHome} 
            />
            <div style={{ width: '1px', height: '30px', background: 'rgba(255,255,255,0.2)' }} />
            
            {/* Breadcrumbs */}
            <div style={{ 
              fontSize: '14px', 
              color: '#64748b', 
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontWeight: 500
            }}>
              <span 
                onClick={handleNavigateHome}
                style={{ cursor: 'pointer', transition: 'color 0.2s' }}
                onMouseEnter={(e) => e.currentTarget.style.color = '#0891B2'}
                onMouseLeave={(e) => e.currentTarget.style.color = '#64748b'}
              >
                Home
              </span>
              <span style={{ color: '#cbd5e1' }}>›</span>
              <span style={{ color: '#0891B2', fontWeight: 600 }}>Worklist</span>
            </div>
          </div>
          
          <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              gap: '8px',
              borderRight: '1px solid rgba(255, 255, 255, 0.2)', 
              paddingRight: '20px' 
            }}>
              <span style={{ fontSize: '17px', fontWeight: 600 }}>
                {user?.name || 'Dr. Johnson'}
              </span>
              <span style={{ fontSize: '12px', color: '#0891B2', fontWeight: 700 }}>
                MD, FCAP
              </span>
            </div>
            
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              {/* User Badge */}
              <div style={{ position: 'relative' }}>
                <button 
                  onClick={() => setIsProfileOpen(!isProfileOpen)}
                  style={{
                    width: '42px',
                    height: '42px',
                    borderRadius: '50%',
                    backgroundColor: 'transparent',
                    border: '2px solid #0891B2',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#0891B2',
                    fontWeight: 800,
                    cursor: 'pointer',
                    transition: 'all 0.2s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(8, 145, 178, 0.1)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}
                >
                  {user?.name ? user.name.split(' ').map((n:any)=>n[0]).join('') : 'DJ'}
                </button>
              </div>

              {/* Quick Links Button */}
              <div style={{ position: 'relative' }}>
                <button 
                  onClick={() => setIsResourcesOpen(!isResourcesOpen)}
                  style={{
                    width: '42px',
                    height: '42px',
                    borderRadius: '8px',
                    background: 'transparent',
                    border: '2px solid #0891B2',
                    color: '#0891B2',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease'
                  }}
                  title="Quick Links"
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'rgba(8, 145, 178, 0.1)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'transparent';
                  }}
                >
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
                  </svg>
                </button>
              </div>

              {/* Logout Button */}
              <button 
                onClick={() => setShowLogoutWarning(true)}
                style={{
                  width: '42px',
                  height: '42px',
                  borderRadius: '8px',
                  background: 'transparent',
                  border: '2px solid #0891B2',
                  color: '#0891B2',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
                title="Sign Out"
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(8, 145, 178, 0.1)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'transparent';
                }}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                  <polyline points="16 17 21 12 16 7"></polyline>
                  <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
              </button>
            </div>
          </div>
        </nav>

        {/* Case Search Bar */}
        <div style={{
          padding: '16px 40px',
          background: 'rgba(0,0,0,0.3)',
          backdropFilter: 'blur(12px)',
          borderBottom: '1px solid rgba(255,255,255,0.08)'
        }}>
          <CaseSearchBar />
        </div>

        {/* Main Content */}
        <main style={{ 
          flex: 1, 
          padding: '40px', 
          overflowY: 'auto',
          overflowX: 'hidden'
        }}>
          <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
            
            {/* Header Section */}
            <div style={{ marginBottom: '40px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: '16px' }}>
                <div>
                  <h1 style={{ fontSize: '42px', fontWeight: 900, margin: 0, letterSpacing: '-1px' }}>
                    Active Cases
                  </h1>
                  <p style={{ fontSize: '16px', color: '#94a3b8', marginTop: '8px' }}>
                    Managing {filteredCases.length} assignment{filteredCases.length !== 1 ? 's' : ''} in the current queue
                  </p>
                </div>
                
                {/* Stats Cards */}
                <div style={{ display: 'flex', gap: '16px' }}>
                  <div style={{ 
                    background: 'rgba(255,255,255,0.03)', 
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '12px', 
                    padding: '16px 24px',
                    backdropFilter: 'blur(10px)',
                    minWidth: '140px'
                  }}>
                    <div style={{ fontSize: '10px', fontWeight: 800, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px' }}>
                      Grossed Today
                    </div>
                    <div style={{ fontSize: '32px', fontWeight: 800, color: '#0891B2' }}>
                      {stats.grossedToday}
                    </div>
                  </div>
                  
                  <div style={{ 
                    background: 'rgba(255,255,255,0.03)', 
                    border: '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '12px', 
                    padding: '16px 24px',
                    backdropFilter: 'blur(10px)',
                    minWidth: '140px'
                  }}>
                    <div style={{ fontSize: '10px', fontWeight: 800, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', marginBottom: '4px' }}>
                      Needs Review
                    </div>
                    <div style={{ fontSize: '32px', fontWeight: 800, color: '#10B981' }}>
                      {stats.needsReview}
                    </div>
                  </div>
                </div>
              </div>

              {/* Filter Tabs */}
              <div style={{ display: 'flex', gap: '8px' }}>
                {[
                  { key: 'all', label: 'All Cases' },
                  { key: 'review', label: 'Needs Review' },
                  { key: 'completed', label: 'Completed' }
                ].map(filter => (
                  <button
                    key={filter.key}
                    onClick={() => setActiveFilter(filter.key as any)}
                    style={{
                      padding: '10px 20px',
                      background: activeFilter === filter.key ? '#0891B2' : 'rgba(255,255,255,0.03)',
                      border: activeFilter === filter.key ? '1px solid #0891B2' : '1px solid rgba(255,255,255,0.1)',
                      borderRadius: '8px',
                      color: activeFilter === filter.key ? '#000' : '#94a3b8',
                      fontWeight: 700,
                      fontSize: '14px',
                      cursor: 'pointer',
                      transition: 'all 0.2s'
                    }}
                    onMouseEnter={(e) => {
                      if (activeFilter !== filter.key) {
                        e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                        e.currentTarget.style.color = '#fff';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (activeFilter !== filter.key) {
                        e.currentTarget.style.background = 'rgba(255,255,255,0.03)';
                        e.currentTarget.style.color = '#94a3b8';
                      }
                    }}
                  >
                    {filter.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Worklist Table */}
                <WorklistTable
                  cases={filteredCases}
                  activeFilter={activeFilter}
                />
                            
          </div>
        </main>
      </div>

           {/* PROFILE MODAL */}
      {isProfileOpen && (
        <div 
          style={{ 
            position: 'fixed', 
            inset: 0, 
            backgroundColor: 'rgba(0,0,0,0.85)',
            backdropFilter: 'blur(10px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 10000
          }}
          onClick={() => setIsProfileOpen(false)}
        >
          <div 
            style={{ 
              width: '400px',
              backgroundColor: '#111', 
              borderRadius: '20px', 
              padding: '40px', 
              border: '1px solid rgba(8, 145, 178, 0.3)', 
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
              textAlign: 'center'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ 
              color: '#0891B2', 
              fontSize: '24px', 
              fontWeight: 700, 
              marginBottom: '24px'
            }}>
              User Preferences
            </div>

            <div style={{ marginBottom: '32px' }}>
              <div style={{ color: '#64748b', fontSize: '12px', fontWeight: 800, textTransform: 'uppercase', marginBottom: '12px', textAlign: 'left' }}>
                Appearance
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
                <button 
                  onClick={() => { /* setCurrentTheme('light'); */ }} 
                  style={{
                    background: currentTheme === 'light' ? 'rgba(8, 145, 178, 0.2)' : 'rgba(255,255,255,0.05)',
                    border: currentTheme === 'light' ? '2px solid #0891B2' : '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '12px',
                    color: '#fff',
                    padding: '16px',
                    cursor: 'pointer',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '8px',
                    transition: 'all 0.2s',
                    opacity: 0.5
                  }}
                  title="Coming soon"
                >
                  <SunIcon />
                  <span style={{ fontSize: '12px', fontWeight: 600 }}>Light</span>
                </button>
                <button 
                  onClick={() => { /* setCurrentTheme('dark'); */ }} 
                  style={{
                    background: currentTheme === 'dark' ? 'rgba(8, 145, 178, 0.2)' : 'rgba(255,255,255,0.05)',
                    border: currentTheme === 'dark' ? '2px solid #0891B2' : '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '12px',
                    color: '#fff',
                    padding: '16px',
                    cursor: 'pointer',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '8px',
                    transition: 'all 0.2s',
                    opacity: 0.5
                  }}
                  title="Coming soon"
                >
                  <MoonIcon />
                  <span style={{ fontSize: '12px', fontWeight: 600 }}>Dark</span>
                </button>
                <button 
                  onClick={() => { /* setCurrentTheme('auto'); */ }} 
                  style={{
                    background: currentTheme === 'auto' ? 'rgba(8, 145, 178, 0.2)' : 'rgba(255,255,255,0.05)',
                    border: currentTheme === 'auto' ? '2px solid #0891B2' : '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '12px',
                    color: '#fff',
                    padding: '16px',
                    cursor: 'pointer',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '8px',
                    transition: 'all 0.2s',
                    opacity: 0.5
                  }}
                  title="Coming soon"
                >
                  <MonitorIcon />
                  <span style={{ fontSize: '12px', fontWeight: 600 }}>Auto</span>
                </button>
              </div>
            </div>

            <div style={{ marginBottom: '24px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <button 
                onClick={() => { 
                  window.open('https://www.cap.org/', '_blank'); 
                  setIsProfileOpen(false); 
                }} 
                style={{
                  padding: '12px 16px',
                  borderRadius: '10px',
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  color: '#cbd5e1',
                  fontWeight: 600,
                  fontSize: '15px',
                  cursor: 'pointer',
                  width: '100%',
                  transition: 'all 0.2s',
                  textAlign: 'left',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(8, 145, 178, 0.1)';
                  e.currentTarget.style.color = '#0891B2';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                  e.currentTarget.style.color = '#cbd5e1';
                }}
              >
                <HelpIcon /> Support & Protocols
              </button>
              
              <button 
                onClick={() => { 
                  setShowAbout(true); 
                  setIsProfileOpen(false); 
                }} 
                style={{
                  padding: '12px 16px',
                  borderRadius: '10px',
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  color: '#cbd5e1',
                  fontWeight: 600,
                  fontSize: '15px',
                  cursor: 'pointer',
                  width: '100%',
                  transition: 'all 0.2s',
                  textAlign: 'left',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(8, 145, 178, 0.1)';
                  e.currentTarget.style.color = '#0891B2';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                  e.currentTarget.style.color = '#cbd5e1';
                }}
              >
                <HelpIcon /> About PathScribe<span style={{ color: '#0891B2', fontSize: '0.6em', verticalAlign: 'super', marginLeft: '0.2em' }}>AI</span>
              </button>
            </div>

            <button 
              onClick={() => setIsProfileOpen(false)} 
              autoFocus
              style={{
                padding: '12px 24px',
                borderRadius: '10px',
                background: 'rgba(8, 145, 178, 0.15)',
                border: '1px solid rgba(8, 145, 178, 0.3)',
                color: '#0891B2',
                fontWeight: 600,
                fontSize: '15px',
                cursor: 'pointer',
                width: '100%',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(8, 145, 178, 0.25)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'rgba(8, 145, 178, 0.15)';
              }}
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* ABOUT MODAL */}
      {showAbout && (
        <div 
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(0,0,0,0.85)',
            backdropFilter: 'blur(12px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 10000
          }}
          onClick={() => setShowAbout(false)}
        >
          <div 
            style={{
              width: '400px',
              backgroundColor: 'rgba(220, 220, 220, 0.75)',
              backdropFilter: 'blur(40px)',
              padding: '40px',
              borderRadius: '20px',
              textAlign: 'center',
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
              border: '1px solid rgba(255, 255, 255, 0.3)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
             <h2 style={{ 
               fontSize: '32px', 
               fontWeight: 700, 
               color: '#1a1a1a', 
               margin: '0 0 16px 0',
               letterSpacing: '-0.5px'
             }}>
               PathScribe<span style={{ color: '#0891B2', fontSize: '0.6em', verticalAlign: 'super', marginLeft: '0.1em' }}>AI</span>
             </h2>
             
             <p style={{ 
               color: '#3a3a3a', 
               marginBottom: '8px', 
               fontSize: '15px',
               lineHeight: '1.6'
             }}>
               Version 1.0.0 | Build: 2026-02-14
             </p>
             
             <p style={{ 
               color: '#3a3a3a', 
               marginBottom: '20px', 
               fontSize: '15px',
               lineHeight: '1.6'
             }}>
               Developed by the PathScribe AI Team
             </p>
             
             <p style={{ 
               color: '#5a5a5a', 
               marginBottom: '30px', 
               fontSize: '14px'
             }}>
               © 2026 PathScribe
             </p>
             
             <button 
               onClick={() => setShowAbout(false)} 
               autoFocus
               style={{
                 padding: '12px 32px',
                 borderRadius: '8px',
                 background: 'rgba(160, 160, 160, 0.5)',
                 border: 'none',
                 color: '#1a1a1a',
                 fontWeight: 600,
                 fontSize: '15px',
                 cursor: 'pointer',
                 width: '100%',
                 transition: 'all 0.2s ease'
               }}
               onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(140, 140, 140, 0.6)'}
               onMouseLeave={(e) => e.currentTarget.style.background = 'rgba(160, 160, 160, 0.5)'}
             >
               Close
             </button>
          </div>
        </div>
      )}

      {/* QUICK LINKS MODAL */}
      {isResourcesOpen && (
        <div 
          style={{ 
            position: 'fixed', 
            inset: 0, 
            backgroundColor: 'rgba(0,0,0,0.85)',
            backdropFilter: 'blur(10px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 10000
          }}
          onClick={() => setIsResourcesOpen(false)}
        >
          <div 
            style={{ 
              width: '500px',
              maxHeight: '80vh',
              overflowY: 'auto',
              backgroundColor: '#111', 
              borderRadius: '20px', 
              padding: '40px', 
              border: '1px solid rgba(8, 145, 178, 0.3)', 
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ 
              color: '#0891B2', 
              fontSize: '24px', 
              fontWeight: 700, 
              marginBottom: '24px',
              textAlign: 'center'
            }}>
              Quick Links
            </div>

            {/* Protocols Section */}
            <div style={{ marginBottom: '24px' }}>
              <div style={{ 
                color: '#94a3b8', 
                fontSize: '12px', 
                fontWeight: 700, 
                marginBottom: '12px',
                textTransform: 'uppercase'
              }}>
                Protocols
              </div>
              {quickLinks.protocols.map((link, i) => (
                <a            
                  key={i}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setIsResourcesOpen(false)}
                  style={{
                    display: 'block',
                    color: '#cbd5e1',
                    textDecoration: 'none',
                    padding: '12px 16px',
                    fontSize: '16px',
                    transition: 'all 0.2s',
                    borderRadius: '8px',
                    marginBottom: '8px'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = '#0891B2';
                    e.currentTarget.style.backgroundColor = 'rgba(8, 145, 178, 0.1)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = '#cbd5e1';
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  → {link.title}
                </a>
              ))}
            </div>

            {/* References Section */}
            <div style={{ marginBottom: '24px' }}>
              <div style={{ 
                color: '#94a3b8', 
                fontSize: '12px', 
                fontWeight: 700, 
                marginBottom: '12px',
                textTransform: 'uppercase'
              }}>
                References
              </div>
              {quickLinks.references.map((link, i) => (
                <a
                  key={i}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setIsResourcesOpen(false)}
                  style={{
                    display: 'block',
                    color: '#cbd5e1',
                    textDecoration: 'none',
                    padding: '12px 16px',
                    fontSize: '16px',
                    transition: 'all 0.2s',
                    borderRadius: '8px',
                    marginBottom: '8px'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = '#0891B2';
                    e.currentTarget.style.backgroundColor = 'rgba(8, 145, 178, 0.1)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = '#cbd5e1';
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  → {link.title}
                </a>
              ))}
            </div>

            {/* Systems Section */}
            <div style={{ marginBottom: '24px' }}>
              <div style={{ 
                color: '#94a3b8', 
                fontSize: '12px', 
                fontWeight: 700, 
                marginBottom: '12px',
                textTransform: 'uppercase'
              }}>
                Systems
              </div>
              {quickLinks.systems.map((link, i) => (
                <a
                  key={i}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setIsResourcesOpen(false)}
                  style={{
                    display: 'block',
                    color: '#cbd5e1',
                    textDecoration: 'none',
                    padding: '12px 16px',
                    fontSize: '16px',
                    transition: 'all 0.2s',
                    borderRadius: '8px',
                    marginBottom: '8px'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = '#0891B2';
                    e.currentTarget.style.backgroundColor = 'rgba(8, 145, 178, 0.1)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = '#cbd5e1';
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  → {link.title}
                </a>
              ))}
            </div>

            <button 
              onClick={() => setIsResourcesOpen(false)} 
              autoFocus
              style={{
                padding: '12px 24px',
                borderRadius: '10px',
                background: 'rgba(8, 145, 178, 0.15)',
                border: '1px solid rgba(8, 145, 178, 0.3)',
                color: '#0891B2',
                fontWeight: 600,
                fontSize: '15px',
                cursor: 'pointer',
                width: '100%',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = 'rgba(8, 145, 178, 0.25)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = 'rgba(8, 145, 178, 0.15)';
              }}
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* LOGOUT WARNING MODAL */}
      {showLogoutWarning && (
        <div
          style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10000 }}
          tabIndex={-1}
          onKeyDown={(e) => { if (e.key === 'Escape') setShowLogoutWarning(false); }}
        >
          <div style={{ width: '400px', backgroundColor: '#111', padding: '40px', borderRadius: '28px', textAlign: 'center', border: '1px solid rgba(255,255,255,0.1)', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)' }}>
            <div style={{ marginBottom: '20px', display: 'flex', justifyContent: 'center' }}>
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" strokeWidth="2">
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
              </svg>
            </div>
            <h2 style={{ fontSize: '24px', fontWeight: 800, color: '#fff', margin: '0 0 12px 0' }}>Unsaved Data</h2>
            <p style={{ color: '#94a3b8', marginBottom: '30px', lineHeight: '1.6', fontSize: '15px' }}>
              You have an active session with unsaved changes. Logging out now will discard your current progress.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <button
                onClick={() => setShowLogoutWarning(false)}
                autoFocus
                style={{ padding: '16px 24px', borderRadius: '12px', background: '#0891B2', border: 'none', color: '#fff', fontWeight: 700, fontSize: '16px', cursor: 'pointer', width: '100%', transition: 'all 0.2s ease' }}
                onMouseEnter={(e) => e.currentTarget.style.background = '#0E7490'}
                onMouseLeave={(e) => e.currentTarget.style.background = '#0891B2'}
              >
                ← Return to Page
              </button>
              <button
                onClick={handleLogout}
                style={{ padding: '16px 24px', borderRadius: '12px', background: 'transparent', border: '2px solid #F59E0B', color: '#F59E0B', fontWeight: 600, fontSize: '15px', cursor: 'pointer', width: '100%', transition: 'all 0.2s ease' }}
                onMouseEnter={(e) => { e.currentTarget.style.background = '#F59E0B'; e.currentTarget.style.color = '#000'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#F59E0B'; }}
              >
                Log Out & Discard Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WorklistPage;
