import React, { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PathologyCase } from './types';

interface WorklistTableProps {
  cases: PathologyCase[];
  activeFilter: 'all' | 'review' | 'completed';
}

const BATCH_SIZE = 15;

const WorklistTable: React.FC<WorklistTableProps> = ({ cases, activeFilter }) => {
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [visibleCount, setVisibleCount] = useState(BATCH_SIZE);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hoveredRow, setHoveredRow] = useState<string | null>(null);

  // Filter cases based on active filter
  const filteredCases = cases.filter(c => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'review') return c.status === 'Grossed' || c.status === 'Awaiting Micro' || c.status === 'Finalizing';
    if (activeFilter === 'completed') return c.status === 'Completed';
    return true;
  });

  const visibleCases = filteredCases.slice(0, visibleCount);
  const hasMore = visibleCount < filteredCases.length;

  // Reset on filter change
  useEffect(() => {
    setVisibleCount(BATCH_SIZE);
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  }, [activeFilter]);

  // Lazy load on scroll
  const handleScroll = useCallback(() => {
    if (!scrollRef.current || isLoadingMore || !hasMore) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
    if (scrollTop + clientHeight >= scrollHeight - 80) {
      setIsLoadingMore(true);
      setTimeout(() => {
        setVisibleCount(prev => Math.min(prev + BATCH_SIZE, filteredCases.length));
        setIsLoadingMore(false);
      }, 400);
    }
  }, [isLoadingMore, hasMore, filteredCases.length]);

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'Grossed':        return { bg: 'rgba(8,145,178,0.15)',   color: '#0891B2', border: 'rgba(8,145,178,0.3)'   };
      case 'Awaiting Micro': return { bg: 'rgba(245,158,11,0.15)',  color: '#F59E0B', border: 'rgba(245,158,11,0.3)'  };
      case 'Finalizing':     return { bg: 'rgba(16,185,129,0.15)',  color: '#10B981', border: 'rgba(16,185,129,0.3)'  };
      case 'Completed':      return { bg: 'rgba(100,116,139,0.15)', color: '#64748b', border: 'rgba(100,116,139,0.3)' };
      default:               return { bg: 'rgba(255,255,255,0.05)', color: '#94a3b8', border: 'rgba(255,255,255,0.1)' };
    }
  };

  const getConfidenceColor = (score: number) => {
    if (score >= 90) return '#10B981';
    if (score >= 75) return '#F59E0B';
    return '#EF4444';
  };

  const colGrid = '220px 1fr 150px 1fr 110px';

  return (
    <div style={{
      background: 'rgba(255,255,255,0.02)',
      border: '1px solid rgba(255,255,255,0.1)',
      borderRadius: '16px',
      overflow: 'hidden',
      backdropFilter: 'blur(10px)',
      display: 'flex',
      flexDirection: 'column',
      flex: 1,
      minHeight: 0
    }}>

      {/* Sticky Header with record count */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: colGrid,
        padding: '0 20px',
        height: '40px',
        alignItems: 'center',
        background: 'rgba(255,255,255,0.04)',
        borderBottom: '1px solid rgba(255,255,255,0.1)',
        flexShrink: 0
      }}>
        {['Case / Patient', 'Procedure / Specimen', 'Status', 'AI Diagnosis', 'Action'].map((col, i) => (
          <div key={col} style={{
            fontSize: '10px',
            fontWeight: 800,
            color: '#475569',
            textTransform: 'uppercase' as const,
            letterSpacing: '0.8px',
            textAlign: i === 4 ? 'right' as const : 'left' as const
          }}>
            {col}
          </div>
        ))}
      </div>

      {/* Scrollable Rows */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        style={{
          overflowY: 'auto',
          flex: 1,
          scrollbarWidth: 'thin' as const,
          scrollbarColor: 'rgba(255,255,255,0.1) transparent'
        }}
      >
        {visibleCases.length === 0 ? (
          <div style={{ padding: '60px', textAlign: 'center', color: '#475569' }}>
            <div style={{ fontSize: '40px', marginBottom: '12px' }}>📋</div>
            <div style={{ fontSize: '16px', fontWeight: 600, color: '#64748b' }}>No cases found</div>
            <div style={{ fontSize: '13px', color: '#475569', marginTop: '6px' }}>Try a different filter</div>
          </div>
        ) : (
          visibleCases.map((c, idx) => {
            const statusStyle = getStatusStyle(c.status);
            const isHovered = hoveredRow === c.id;
            const confColor = getConfidenceColor(c.confidence);

            return (
              <div
                key={c.id}
                onMouseEnter={() => setHoveredRow(c.id)}
                onMouseLeave={() => setHoveredRow(null)}
                style={{
                  display: 'grid',
                  gridTemplateColumns: colGrid,
                  padding: '0 20px',
                  height: '46px',
                  alignItems: 'center',
                  borderBottom: idx < visibleCases.length - 1
                    ? '1px solid rgba(255,255,255,0.05)'
                    : 'none',
                  // Only highlight the hovered row, not the whole table
                  backgroundColor: isHovered ? 'rgba(8,145,178,0.07)' : 'transparent',
                  transition: 'background-color 0.15s ease',
                  cursor: 'default'
                }}
              >
                {/* Col 1: Case ID | Patient Name */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', minWidth: 0 }}>
                  <span style={{
                    fontSize: '13px',
                    fontWeight: 800,
                    color: '#0891B2',
                    whiteSpace: 'nowrap',
                    letterSpacing: '0.3px',
                    flexShrink: 0
                  }}>
                    {c.id}
                  </span>
                  <span style={{
                    width: '1px', height: '14px',
                    background: 'rgba(255,255,255,0.15)',
                    flexShrink: 0
                  }} />
                  <span style={{
                    fontSize: '13px',
                    color: '#cbd5e1',
                    fontWeight: 500,
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap'
                  }}>
                    {c.patient}
                  </span>
                </div>

                {/* Col 2: Protocol · Specimen */}
                <div
                  title={`${c.protocol} · ${c.specimen}`}
                  style={{
                    fontSize: '12px',
                    color: '#94a3b8',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                    paddingRight: '16px'
                  }}
                >
                  {c.protocol}
                  <span style={{ color: '#334155', margin: '0 5px' }}>·</span>
                  {c.specimen}
                </div>

                {/* Col 3: Status Badge (timestamp in tooltip) */}
                <div>
                  <span
                    title={`Priority: ${c.priority} · ${c.time}`}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      padding: '3px 10px',
                      borderRadius: '20px',
                      fontSize: '11px',
                      fontWeight: 700,
                      background: statusStyle.bg,
                      color: statusStyle.color,
                      border: `1px solid ${statusStyle.border}`,
                      whiteSpace: 'nowrap',
                      cursor: 'default'
                    }}
                  >
                    {c.status}
                  </span>
                </div>

                {/* Col 4: AI Confidence % | AI Status */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  minWidth: 0,
                  paddingRight: '12px'
                }}>
                  {c.confidence > 0 ? (
                    <>
                      <span style={{
                        fontSize: '12px',
                        fontWeight: 800,
                        color: confColor,
                        whiteSpace: 'nowrap',
                        flexShrink: 0
                      }}>
                        {c.confidence}%
                      </span>
                      <span style={{
                        width: '1px', height: '12px',
                        background: 'rgba(255,255,255,0.15)',
                        flexShrink: 0
                      }} />
                      <span
                        title={c.aiStatus}
                        style={{
                          fontSize: '12px',
                          color: '#94a3b8',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap'
                        }}
                      >
                        {c.aiStatus}
                      </span>
                    </>
                  ) : (
                    <span style={{ fontSize: '12px', color: '#334155', fontStyle: 'italic' }}>
                      Pending
                    </span>
                  )}
                </div>

                {/* Col 5: Open Button */}
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <button
                    onClick={() => navigate(`/case/${c.id}/synoptic`)}
                    style={{
                      padding: '5px 14px',
                      background: isHovered ? '#0891B2' : 'transparent',
                      border: `1px solid ${isHovered ? '#0891B2' : 'rgba(255,255,255,0.15)'}`,
                      borderRadius: '6px',
                      color: isHovered ? '#ffffff' : '#64748b',
                      fontSize: '12px',
                      fontWeight: 600,
                      cursor: 'pointer',
                      transition: 'all 0.15s ease',
                      whiteSpace: 'nowrap',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '4px'
                    }}
                  >
                    Open
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                      <line x1="5" y1="12" x2="19" y2="12"></line>
                      <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                  </button>
                </div>
              </div>
            );
          })
        )}

        {/* Lazy Load Spinner */}
        {isLoadingMore && (
          <div style={{
            padding: '16px',
            textAlign: 'center',
            color: '#64748b',
            fontSize: '12px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px'
          }}>
            <div style={{
              width: '14px', height: '14px',
              border: '2px solid rgba(8,145,178,0.2)',
              borderTopColor: '#0891B2',
              borderRadius: '50%',
              animation: 'spin 0.7s linear infinite'
            }} />
            Loading more cases...
          </div>
        )}

        {/* All loaded indicator */}
        {!hasMore && filteredCases.length > BATCH_SIZE && (
          <div style={{
            padding: '10px',
            textAlign: 'center',
            color: '#1e293b',
            fontSize: '11px',
            fontWeight: 600,
            letterSpacing: '0.5px',
            textTransform: 'uppercase' as const
          }}>
            ✓ All {filteredCases.length} cases loaded
          </div>
        )}
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        div::-webkit-scrollbar { width: 4px; }
        div::-webkit-scrollbar-track { background: transparent; }
        div::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 4px; }
        div::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.2); }
      `}</style>
    </div>
  );
};

export default WorklistTable;
