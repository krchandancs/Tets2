export type CaseStatus = 'Grossed' | 'Awaiting Micro' | 'Finalizing' | 'Completed';
export type Priority = 'STAT' | 'Routine';

export interface PathologyCase {
  id: string;
  patient: string;
  protocol: string;
  specimen: string;
  status: CaseStatus;
  aiStatus: string;
  confidence: number; // AI confidence percentage (0-100)
  time: string;
  priority: Priority;
}
