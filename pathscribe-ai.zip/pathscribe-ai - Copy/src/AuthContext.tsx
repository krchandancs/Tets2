import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'pathologist' | 'admin';
  initials: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = async (email: string, password: string): Promise<boolean> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (email === 'demo@pathscribe.ai' && password === 'demo') {
          const mockUser: User = {
            id: '1',
            name: 'Dr. Sarah Johnson',
            email: 'demo@pathscribe.ai',
            role: 'pathologist',
            initials: 'SJ'
          };
          setUser(mockUser);
          localStorage.setItem('pathscribe-user', JSON.stringify(mockUser));
          resolve(true);
        } else if (email === 'admin@pathscribe.ai' && password === 'admin') {
          const mockAdmin: User = {
            id: '2',
            name: 'System Admin',
            email: 'admin@pathscribe.ai',
            role: 'admin',
            initials: 'SA'
          };
          setUser(mockAdmin);
          localStorage.setItem('pathscribe-user', JSON.stringify(mockAdmin));
          resolve(true);
        } else {
          resolve(false);
        }
      }, 500);
    });
  };

  // Simple logout — just clears state and storage.
  // Navigation to /login is handled by each page component.
  const logout = () => {
    setUser(null);
    localStorage.removeItem('pathscribe-user');
  };

  // ✅ Fixed: empty dependency array so this only runs once on mount
  useEffect(() => {
    const stored = localStorage.getItem('pathscribe-user');
    if (stored) {
      setUser(JSON.parse(stored));
    }
  }, []);

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
