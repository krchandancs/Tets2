import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { useLogout } from './useLogout';
import { SunIcon, MoonIcon, HelpIcon, MonitorIcon, WarningIcon } from './components/Icons';

interface SynopticField {
  id: string;
  label: string;
  value: string;
  confidence: number;
  source: string;
  required: boolean;
}

interface ProgressStep {
  id: string;
  label: string;
  status: 'completed' | 'current' | 'pending' | 'alert';
}

interface Specimen {
  id: number;
  name: string;
  status: 'complete' | 'alert' | 'pending';
  fieldsComplete: number;
  fieldsTotal: number;
}

const SynopticReportPage: React.FC = () => {
  const { caseId } = useParams<{ caseId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const handleLogout = useLogout();
  const [isLoaded, setIsLoaded] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isResourcesOpen, setIsResourcesOpen] = useState(false);
  const [showAbout, setShowAbout] = useState(false);
  const [currentTheme, setCurrentTheme] = useState<'light' | 'dark' | 'auto'>('dark');
  const [activeSpecimen, setActiveSpecimen] = useState(0);
  const [isFinalized, setIsFinalized] = useState(false);
  const [isAlertExpanded, setIsAlertExpanded] = useState(true);
  const [activeSynopticTab, setActiveSynopticTab] = useState<'tumor' | 'margins' | 'biomarkers'>('tumor');
  const [isExpandedView, setIsExpandedView] = useState(false);
  const [showAddSynopticModal, setShowAddSynopticModal] = useState(false);
  const [selectedSpecimens, setSelectedSpecimens] = useState<number[]>([]);
  const [selectedProtocol, setSelectedProtocol] = useState('');
  const [protocolSearch, setProtocolSearch] = useState('');
  const [showProtocolDropdown, setShowProtocolDropdown] = useState(false);
  const [learnPairing, setLearnPairing] = useState(true);
  const hasAlerts = true; // In real app, check if there are actual alerts
  const [hasUnsavedData, setHasUnsavedData] = useState(false);
  const [showWarning, setShowWarning] = useState(false);
  const [pendingNavigation, setPendingNavigation] = useState<string | null>(null);
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  // Navigation Handlers with Unsaved Data Check
  const handleNavigateHome = () => {
    if (hasUnsavedData) {
      setPendingNavigation('/');
      setShowWarning(true);
    } else {
      navigate('/');
    }
  };

  const handleNavigateWorklist = () => {
    if (hasUnsavedData) {
      setPendingNavigation('/worklist');
      setShowWarning(true);
    } else {
      navigate('/worklist');
    }
  };

  const confirmNavigation = () => {
    if (pendingNavigation) {
      setHasUnsavedData(false);
      navigate(pendingNavigation);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  // Quick Links Data
  const quickLinks = {
    protocols: [
      { title: 'CAP Cancer Protocols', url: 'https://www.cap.org/protocols-and-guidelines' },
      { title: 'WHO Classification', url: 'https://www.who.int/publications' }
    ],
    references: [
      { title: 'PathologyOutlines', url: 'https://www.pathologyoutlines.com' },
      { title: 'UpToDate', url: 'https://www.uptodate.com' }
    ],
    systems: [
      { title: 'Hospital LIS', url: '#' },
      { title: 'Lab Management', url: '#' }
    ]
  };

  // Mock case data
  const caseData = {
    accession: caseId || 'S25-12345',
    patient: 'Smith, John',
    dob: '03/15/1965',
    mrn: '123456789',
    protocol: 'CAP Breast Protocol 4.3.0.1',
    overallConfidence: 89,
    autoPopulated: '12/14'
  };

  // Multiple specimens
  const specimens: Specimen[] = [
    {
      id: 1,
      name: 'Left Breast Mastectomy',
      status: 'complete',
      fieldsComplete: 14,
      fieldsTotal: 14
    },
    {
      id: 2,
      name: 'Sentinel Lymph Nodes',
      status: 'alert',
      fieldsComplete: 3,
      fieldsTotal: 6
    },
    {
      id: 3,
      name: 'Additional Margins',
      status: 'pending',
      fieldsComplete: 0,
      fieldsTotal: 4
    }
  ];

  // Available synoptic protocols - expanded list
  const availableProtocols = [
    { id: 'breast_invasive', name: 'CAP Breast Invasive Carcinoma' },
    { id: 'breast_dcis', name: 'CAP Breast Ductal Carcinoma In Situ' },
    { id: 'breast_excision', name: 'CAP Breast Excision' },
    { id: 'colon_resection', name: 'CAP Colon Resection' },
    { id: 'colon_polyp', name: 'CAP Colon Polyp' },
    { id: 'prostate', name: 'CAP Prostatectomy' },
    { id: 'prostate_biopsy', name: 'CAP Prostate Biopsy' },
    { id: 'lung_resection', name: 'CAP Lung Resection' },
    { id: 'lung_biopsy', name: 'CAP Lung Biopsy' },
    { id: 'gastric_resection', name: 'CAP Gastric Resection' },
    { id: 'esophagus', name: 'CAP Esophagus Resection' },
    { id: 'pancreas', name: 'CAP Pancreatic Resection' },
    { id: 'liver', name: 'CAP Hepatocellular Carcinoma' },
    { id: 'kidney', name: 'CAP Kidney Resection' },
    { id: 'bladder', name: 'CAP Bladder Resection' },
    { id: 'thyroid', name: 'CAP Thyroid' },
    { id: 'melanoma', name: 'CAP Melanoma Excision' },
    { id: 'skin_bcc', name: 'CAP Skin Basal Cell Carcinoma' },
    { id: 'ovary', name: 'CAP Ovary' },
    { id: 'endometrium', name: 'CAP Endometrial Carcinoma' },
    { id: 'cervix', name: 'CAP Cervix' },
    { id: 'testis', name: 'CAP Testis' },
    { id: 'soft_tissue', name: 'CAP Soft Tissue' }
  ];

  // Filter protocols based on search
  const filteredProtocols = protocolSearch.trim() === '' 
    ? availableProtocols 
    : availableProtocols.filter(protocol => 
        protocol.name.toLowerCase().includes(protocolSearch.toLowerCase())
      ).slice(0, 8); // Show max 8 results

  const getSpecimenIcon = (status: string) => {
    switch (status) {
      case 'complete': return '✓';
      case 'alert': return '⚠';
      default: return '○';
    }
  };

  const getSpecimenColor = (status: string) => {
    switch (status) {
      case 'complete': return '#10B981';
      case 'alert': return '#F59E0B';
      default: return '#64748b';
    }
  };

  const progressSteps: ProgressStep[] = [
    { id: '1', label: 'Patient Info', status: 'completed' },
    { id: '2', label: 'Tumor\nCharacteristics', status: 'completed' },
    { id: '3', label: 'Margins &\nInvasion', status: 'current' },
    { id: '4', label: 'Biomarkers', status: 'alert' },
    { id: '5', label: 'Review &\nFinalize', status: 'pending' }
  ];

  const tumorFields: SynopticField[] = [
    {
      id: 'tumor_size',
      label: 'Tumor Size',
      value: '2.3 cm',
      confidence: 94,
      source: 'Gross: "2.3 x 1.8 x 1.5 cm"',
      required: true
    },
    {
      id: 'histologic_type',
      label: 'Histologic Type',
      value: 'Invasive Ductal Carcinoma',
      confidence: 98,
      source: 'Diagnosis: "invasive ductal carcinoma"',
      required: true
    },
    {
      id: 'histologic_grade',
      label: 'Histologic Grade',
      value: 'Grade 2',
      confidence: 92,
      source: 'Micro: "moderately differentiated (grade 2)"',
      required: true
    },
    {
      id: 'lvi',
      label: 'Lymphovascular Invasion',
      value: 'Present',
      confidence: 68,
      source: 'Micro: "Lymphovascular invasion is present"',
      required: true
    }
  ];

  const marginFields: SynopticField[] = [
    {
      id: 'margin_status',
      label: 'Margin Status',
      value: 'Negative',
      confidence: 91,
      source: 'Micro: "margins negative"',
      required: true
    },
    {
      id: 'closest_margin',
      label: 'Closest Margin Distance',
      value: '0.3 cm',
      confidence: 87,
      source: 'Micro: "closest margin...0.3 cm"',
      required: false
    }
  ];

  const biomarkerFields: SynopticField[] = [
    {
      id: 'er_status',
      label: 'ER Status',
      value: 'Positive (95%, strong)',
      confidence: 96,
      source: 'IHC: "ER Positive"',
      required: true
    },
    {
      id: 'pr_status',
      label: 'PR Status',
      value: 'Positive (80%, moderate)',
      confidence: 95,
      source: 'IHC: "PR Positive"',
      required: true
    },
    {
      id: 'her2_status',
      label: 'HER2 Status',
      value: 'Negative (1+ by IHC)',
      confidence: 97,
      source: 'IHC: "HER2 Negative"',
      required: true
    }
  ];

  const getStepIcon = (status: string) => {
    switch (status) {
      case 'completed': return '✓';
      case 'alert': return '⚠';
      default: return '';
    }
  };

  const getStepCircleStyle = (status: string) => {
    const base = {
      width: '20px',
      height: '20px',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontWeight: 600,
      fontSize: '11px',
      marginBottom: '6px',
      transition: 'all 0.3s ease',
      border: '2px solid'
    };

    switch (status) {
      case 'completed':
        return { ...base, background: '#0891B2', color: 'white', borderColor: '#0891B2' };
      case 'current':
        return { ...base, background: 'white', color: '#0891B2', borderColor: '#0891B2', boxShadow: '0 0 0 4px rgba(8, 145, 178, 0.1)' };
      case 'alert':
        return { ...base, background: 'white', color: '#F59E0B', borderColor: '#fde047', boxShadow: '0 0 0 4px rgba(253, 224, 71, 0.2)' };
      default:
        return { ...base, background: 'white', color: '#94a3b8', borderColor: '#e2e8f0' };
    }
  };

  const renderField = (field: SynopticField) => {
    const isHighConfidence = field.confidence >= 85;
    const bgColor = isHighConfidence ? '#f0fdf4' : '#fefce8';
    const borderColor = isHighConfidence ? '#86efac' : '#fde047';
    const badgeColor = isHighConfidence ? { bg: '#86efac', color: '#14532d' } : { bg: '#fde047', color: '#713f12' };

    return (
      <div
        key={field.id}
        style={{
          padding: '8px',
          borderRadius: '6px',
          background: bgColor,
          border: `2px solid ${borderColor}`,
          marginBottom: '8px'
        }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px' }}>
          <span style={{ fontSize: '13px', fontWeight: 600, color: '#1e293b' }}>
            {field.label} {field.required && <span style={{ color: '#ef4444' }}>*</span>}
          </span>
          <span style={{
            fontSize: '10px',
            padding: '2px 6px',
            borderRadius: '8px',
            fontWeight: 600,
            background: badgeColor.bg,
            color: badgeColor.color
          }}>
            {isHighConfidence ? '✓' : '⚠'} {field.confidence}%
          </span>
        </div>
        <input
          type="text"
          value={field.value}
          onChange={() => {}}
          style={{
            width: '100%',
            padding: '8px',
            border: `2px solid ${borderColor}`,
            borderRadius: '6px',
            fontSize: '13px',
            background: 'white'
          }}
        />
      </div>
    );
  };

  return (
    <div style={{
      position: 'relative',
      width: '100vw',
      height: '100vh',
      backgroundColor: '#000000',
      color: '#ffffff',
      fontFamily: "'Inter', sans-serif",
      opacity: isLoaded ? 1 : 0,
      transition: 'opacity 0.6s ease',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }}>
      {/* Background */}
      <div style={{ 
        position: 'absolute', 
        inset: 0, 
        backgroundImage: 'url(/main_background.jpg)', 
        backgroundSize: 'cover', 
        backgroundPosition: 'center', 
        zIndex: 0,
        filter: 'brightness(0.3) contrast(1.1)'
      }} />
      <div style={{ 
        position: 'absolute', 
        inset: 0, 
        background: 'linear-gradient(to bottom, rgba(0,0,0,0.4) 0%, #000000 100%)', 
        zIndex: 1 
      }} />

      {/* Content */}
      <div style={{ position: 'relative', zIndex: 10, display: 'flex', flexDirection: 'column', height: '100%' }}>

      {/* Top Navigation - Hidden in Expanded View */}
      {!isExpandedView && (
      <nav style={{
        padding: '20px 40px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        background: 'rgba(0, 0, 0, 0.4)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid rgba(255, 255, 255, 0.1)'
      }}>
        <img 
          src="/pathscribe-logo-dark.svg" 
          alt="PathScribe AI" 
          style={{ height: '60px', width: 'auto', cursor: 'pointer' }} 
          onClick={handleNavigateHome}
        />
        
        <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '8px',
            borderRight: '1px solid rgba(255, 255, 255, 0.2)', 
            paddingRight: '20px' 
          }}>
            <span style={{ fontSize: '17px', fontWeight: 600 }}>
              {user?.name || 'Dr. Johnson'}
            </span>
            <span style={{ fontSize: '12px', color: '#0891B2', fontWeight: 700 }}>
              MD, FCAP
            </span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <button 
              onClick={() => setIsProfileOpen(!isProfileOpen)}
              style={{
                width: '42px',
                height: '42px',
                borderRadius: '50%',
                backgroundColor: 'transparent',
                border: '2px solid #0891B2',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#0891B2',
                fontWeight: 800,
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(8, 145, 178, 0.1)'}
              onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
            >
              DJ
            </button>

            <button 
              onClick={() => setIsResourcesOpen(!isResourcesOpen)}
              style={{
                width: '42px',
                height: '42px',
                borderRadius: '8px',
                background: 'transparent',
                border: '2px solid #0891B2',
                color: '#0891B2',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
              title="Quick Links"
              onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(8, 145, 178, 0.1)'}
              onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
              </svg>
            </button>

            <button 
              onClick={() => setShowLogoutModal(true)}
              style={{
                width: '42px',
                height: '42px',
                borderRadius: '8px',
                background: 'transparent',
                border: '2px solid #0891B2',
                color: '#0891B2',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
              title="Sign Out"
              onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(8, 145, 178, 0.1)'}
              onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                <polyline points="16 17 21 12 16 7"></polyline>
                <line x1="21" y1="12" x2="9" y2="12"></line>
              </svg>
            </button>
          </div>
        </div>
      </nav>
      )}

      {/* Header Bar with Inline Progress - Hidden in Expanded View */}
      {!isExpandedView && (
      <div style={{
        background: 'white',
        padding: '12px 40px',
        borderBottom: '1px solid #e2e8f0'
      }}>
        {/* Breadcrumbs */}
        <div style={{ 
          fontSize: '14px', 
          color: '#64748b', 
          marginBottom: '8px',
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          fontWeight: 500
        }}>
          <span 
            onClick={handleNavigateHome}
            style={{ cursor: 'pointer', transition: 'color 0.2s' }}
            onMouseEnter={(e) => e.currentTarget.style.color = '#0891B2'}
            onMouseLeave={(e) => e.currentTarget.style.color = '#64748b'}
          >
            Home
          </span>
          <span style={{ color: '#cbd5e1' }}>›</span>
          <span 
            onClick={handleNavigateWorklist}
            style={{ cursor: 'pointer', transition: 'color 0.2s' }}
            onMouseEnter={(e) => e.currentTarget.style.color = '#0891B2'}
            onMouseLeave={(e) => e.currentTarget.style.color = '#64748b'}
          >
            Worklist
          </span>
          <span style={{ color: '#cbd5e1' }}>›</span>
          <span style={{ color: '#0891B2', fontWeight: 600 }}>Case {caseData.accession}</span>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '24px', fontWeight: 700, color: '#1e293b', marginBottom: '4px' }}>
              Synoptic Report
            </div>
            <div style={{ color: '#64748b', fontSize: '13px' }}>
              Case {caseData.accession} • {caseData.protocol}
            </div>
          </div>

          {/* Inline Compact Progress */}
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '8px',
            padding: '0 20px'
          }}>
            {progressSteps.map((step, idx) => (
              <React.Fragment key={step.id}>
                <div style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '2px'
                }}>
                  <div style={getStepCircleStyle(step.status)}>
                    {step.status === 'completed' || step.status === 'alert' ? getStepIcon(step.status) : step.id}
                  </div>
                  <div style={{
                    fontSize: '8px',
                    fontWeight: step.status === 'current' ? 600 : 500,
                    color: step.status === 'alert' ? '#F59E0B' : step.status === 'current' ? '#1e293b' : '#94a3b8',
                    textAlign: 'center',
                    whiteSpace: 'nowrap'
                  }}>
                    {step.label.replace('\n', ' ')}
                  </div>
                </div>
                {idx < progressSteps.length - 1 && (
                  <div style={{
                    width: '12px',
                    height: '2px',
                    background: idx < 2 ? '#0891B2' : '#e2e8f0',
                    marginBottom: '12px'
                  }} />
                )}
              </React.Fragment>
            ))}
          </div>

          <div style={{
            background: '#d1fae5',
            border: '1px solid #86efac',
            padding: '8px 16px',
            borderRadius: '8px'
          }}>
            <div style={{ fontWeight: 600, color: '#065f46', fontSize: '13px', marginBottom: '2px' }}>
              Confidence: {caseData.overallConfidence}%
            </div>
            <div style={{ fontSize: '11px', color: '#047857' }}>
              {caseData.autoPopulated} auto-filled
            </div>
          </div>
        </div>
      </div>
      )}

      {/* Collapsible Alert Box - Hidden in Expanded View */}
      {!isExpandedView && hasAlerts && (
        <div style={{
          background: '#fef3c7',
          border: '1px solid #fde047',
          borderTop: 'none',
          overflow: 'hidden'
        }}>
          <div 
            onClick={() => setIsAlertExpanded(!isAlertExpanded)}
            style={{ 
              display: 'flex', 
              justifyContent: 'space-between',
              alignItems: 'center', 
              padding: '8px 40px',
              cursor: 'pointer',
              userSelect: 'none'
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 600, color: '#92400e', fontSize: '13px' }}>
              <span style={{ fontSize: '16px' }}>⚠️</span>
              <span>1 Alert Found</span>
            </div>
            <span style={{ 
              fontSize: '14px', 
              color: '#92400e',
              transform: isAlertExpanded ? 'rotate(180deg)' : 'rotate(0deg)',
              transition: 'transform 0.2s'
            }}>
              ▼
            </span>
          </div>
          
          {isAlertExpanded && (
            <div style={{
              padding: '0 40px 8px 40px',
              color: '#78350f',
              fontSize: '12px',
              borderTop: '1px solid #fde047'
            }}>
              <div style={{ paddingTop: '8px' }}>
                <strong>Alert - Lymphovascular Invasion:</strong> Verify field correctness. AI confidence is 68% (medium). Review source in microscopic findings.
              </div>
            </div>
          )}
        </div>
      )}

      {/* Main Content with Sidebar - Conditional Expanded View */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* Specimen Sidebar - Hidden in Expanded View */}
        {!isExpandedView && (
          <div style={{
            width: '250px',
            background: 'white',
            borderRight: '2px solid #e2e8f0',
            overflowY: 'auto',
            padding: '20px'
          }}>
            <div style={{
              fontSize: '11px',
              fontWeight: 800,
              color: '#64748b',
              textTransform: 'uppercase',
              letterSpacing: '0.5px',
              marginBottom: '16px'
            }}>
              Specimens ({specimens.length})
            </div>

            {specimens.map((specimen, index) => (
              <div
                key={specimen.id}
                onClick={() => setActiveSpecimen(index)}
                style={{
                  padding: '12px',
                  borderRadius: '8px',
                  marginBottom: '8px',
                  background: activeSpecimen === index ? 'rgba(8, 145, 178, 0.1)' : 'transparent',
                  border: `2px solid ${activeSpecimen === index ? '#0891B2' : 'transparent'}`,
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => {
                  if (activeSpecimen !== index) {
                    e.currentTarget.style.background = 'rgba(0,0,0,0.02)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (activeSpecimen !== index) {
                    e.currentTarget.style.background = 'transparent';
                  }
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
                  <span style={{ 
                    fontSize: '16px',
                    color: getSpecimenColor(specimen.status)
                  }}>
                    {getSpecimenIcon(specimen.status)}
                  </span>
                  <span style={{ 
                    fontSize: '14px', 
                    fontWeight: 600, 
                    color: '#1e293b',
                    flex: 1
                  }}>
                    Specimen {specimen.id}
                  </span>
                </div>
                <div style={{ 
                  fontSize: '12px', 
                  color: '#64748b',
                  marginBottom: '6px',
                  paddingLeft: '24px'
                }}>
                  {specimen.name}
                </div>
                <div style={{ 
                  fontSize: '11px', 
                  color: '#64748b',
                  paddingLeft: '24px'
                }}>
                  {specimen.fieldsComplete}/{specimen.fieldsTotal} fields
                </div>
              </div>
            ))}

            <button
              onClick={() => setShowAddSynopticModal(true)}
              style={{
                width: '100%',
                padding: '10px',
                borderRadius: '8px',
                background: 'rgba(8, 145, 178, 0.1)',
                border: '2px dashed #0891B2',
                color: '#0891B2',
                fontWeight: 600,
                fontSize: '13px',
                cursor: 'pointer',
                marginTop: '8px',
                transition: 'all 0.2s'
              }}
              onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(8, 145, 178, 0.15)'}
              onMouseLeave={(e) => e.currentTarget.style.background = 'rgba(8, 145, 178, 0.1)'}
            >
              + Add Synoptic Report
            </button>
          </div>
        )}

        {/* Split Screen Container */}
        <div style={{ display: 'flex', flex: 1, overflow: 'hidden', position: 'relative' }}>
          {/* Left Panel - Full Report */}
          <div style={{
            width: '50%',
            background: 'white',
            borderRight: '3px solid #0891B2',
            overflowY: 'auto',
            padding: '12px 32px 32px 32px'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
              <h3 style={{
                fontSize: '16px',
                fontWeight: 600,
                color: '#1e293b',
                margin: 0,
                borderBottom: '2px solid #0891B2',
                paddingBottom: '6px',
                flex: 1
              }}>
                📋 Full Patient Report
              </h3>
            </div>

            <div style={{
              background: '#f0fdfa',
              borderRadius: '8px',
              padding: '16px',
              marginBottom: '20px',
              fontSize: '14px',
              border: '1px solid #0891B2'
            }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                <div><strong style={{ color: '#0E7490' }}>Accession:</strong> <span style={{ fontFamily: 'monospace' }}>{caseData.accession}</span></div>
                <div><strong style={{ color: '#0E7490' }}>Patient:</strong> {caseData.patient}</div>
                <div><strong style={{ color: '#0E7490' }}>DOB:</strong> {caseData.dob}</div>
                <div><strong style={{ color: '#0E7490' }}>MRN:</strong> {caseData.mrn}</div>
              </div>
            </div>

            <div style={{ marginBottom: '24px' }}>
              <h4 style={{
                fontSize: '16px',
                fontWeight: 600,
                color: '#1e293b',
                marginBottom: '8px',
                paddingBottom: '8px',
                borderBottom: '2px solid #e2e8f0'
              }}>
                CLINICAL HISTORY
              </h4>
              <p style={{ color: '#475569', fontSize: '14px', lineHeight: 1.6 }}>
                59-year-old female with palpable mass in left breast. Core biopsy showed invasive ductal carcinoma, ER+/PR+/HER2-. Now presents for definitive surgical management.
              </p>
            </div>

            <div style={{ marginBottom: '24px' }}>
              <h4 style={{
                fontSize: '16px',
                fontWeight: 600,
                color: '#1e293b',
                marginBottom: '8px',
                paddingBottom: '8px',
                borderBottom: '2px solid #e2e8f0'
              }}>
                GROSS DESCRIPTION
              </h4>
              <p style={{ color: '#475569', fontSize: '14px', lineHeight: 1.6 }}>
                Received fresh, labeled "left breast mastectomy" is a 450g specimen. The specimen is serially sectioned to reveal a{' '}
                <span style={{ background: '#fef3c7', padding: '2px 4px', borderRadius: '3px', fontWeight: 600 }}>
                  2.3 x 1.8 x 1.5 cm firm, white mass
                </span>
                {' '}in the upper outer quadrant, 3 cm from the nipple. The tumor is{' '}
                <span style={{ background: '#fef3c7', padding: '2px 4px', borderRadius: '3px', fontWeight: 600 }}>
                  0.3 cm from the closest (anterior) margin
                </span>
                . Representative sections submitted.
              </p>
            </div>

            <div style={{ marginBottom: '24px' }}>
              <h4 style={{
                fontSize: '16px',
                fontWeight: 600,
                color: '#1e293b',
                marginBottom: '8px',
                paddingBottom: '8px',
                borderBottom: '2px solid #e2e8f0'
              }}>
                MICROSCOPIC FINDINGS
              </h4>
              <p style={{ color: '#475569', fontSize: '14px', lineHeight: 1.6 }}>
                Sections show{' '}
                <span style={{ background: '#fef3c7', padding: '2px 4px', borderRadius: '3px', fontWeight: 600 }}>
                  invasive ductal carcinoma, moderately differentiated (Nottingham grade 2
                </span>
                : tubules 3, nuclei 2, mitoses 1). The invasive component measures 2.3 cm.{' '}
                <span style={{ background: '#fef3c7', padding: '2px 4px', borderRadius: '3px', fontWeight: 600 }}>
                  Lymphovascular invasion is present
                </span>
                . Perineural invasion is not identified. All margins are{' '}
                <span style={{ background: '#fef3c7', padding: '2px 4px', borderRadius: '3px', fontWeight: 600 }}>
                  negative for invasive carcinoma, with the closest margin (anterior) measuring 0.3 cm
                </span>
                . No lymph nodes identified.
              </p>
            </div>
          </div>

          {/* Expand Button on Divider */}
          <div style={{
            position: 'absolute',
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            zIndex: 100
          }}>
            <button
              onClick={() => setIsExpandedView(!isExpandedView)}
              style={{
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                background: '#0891B2',
                border: '3px solid white',
                color: 'white',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                transition: 'all 0.2s',
                fontSize: '18px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#0E7490';
                e.currentTarget.style.transform = 'scale(1.1)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = '#0891B2';
                e.currentTarget.style.transform = 'scale(1)';
              }}
              title={isExpandedView ? "Exit Full Screen" : "Full Screen Mode"}
            >
              {isExpandedView ? '✕' : '⛶'}
            </button>
          </div>

          {/* Right Panel - Synoptic Form with Tabs */}
          <div style={{
            width: '50%',
            background: '#f8fafc',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden'
          }}>
            <div style={{ padding: '12px 32px 0 32px' }}>
              <h3 style={{
                fontSize: '16px',
                fontWeight: 600,
                color: '#1e293b',
                marginBottom: '12px',
                borderBottom: '2px solid #0891B2',
                paddingBottom: '6px',
                margin: 0,
                marginBottom: '12px'
              }}>
                📝 Synoptic Checklist
              </h3>

              {/* Tabs */}
              <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
                <button
                  onClick={() => setActiveSynopticTab('tumor')}
                  style={{
                    padding: '8px 16px',
                    borderRadius: '6px',
                    background: activeSynopticTab === 'tumor' ? '#0891B2' : 'white',
                    border: `2px solid ${activeSynopticTab === 'tumor' ? '#0891B2' : '#e2e8f0'}`,
                    color: activeSynopticTab === 'tumor' ? 'white' : '#64748b',
                    fontWeight: 600,
                    fontSize: '13px',
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}
                >
                  Tumor ({tumorFields.length})
                </button>
                <button
                  onClick={() => setActiveSynopticTab('margins')}
                  style={{
                    padding: '8px 16px',
                    borderRadius: '6px',
                    background: activeSynopticTab === 'margins' ? '#0891B2' : 'white',
                    border: `2px solid ${activeSynopticTab === 'margins' ? '#0891B2' : '#e2e8f0'}`,
                    color: activeSynopticTab === 'margins' ? 'white' : '#64748b',
                    fontWeight: 600,
                    fontSize: '13px',
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}
                >
                  Margins ({marginFields.length})
                </button>
                <button
                  onClick={() => setActiveSynopticTab('biomarkers')}
                  style={{
                    padding: '8px 16px',
                    borderRadius: '6px',
                    background: activeSynopticTab === 'biomarkers' ? '#0891B2' : 'white',
                    border: `2px solid ${activeSynopticTab === 'biomarkers' ? '#0891B2' : '#e2e8f0'}`,
                    color: activeSynopticTab === 'biomarkers' ? 'white' : '#64748b',
                    fontWeight: 600,
                    fontSize: '13px',
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}
                >
                  Biomarkers ({biomarkerFields.length})
                </button>
              </div>
            </div>

            {/* Tab Content - Scrollable */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '0 32px 32px 32px' }}>
              {activeSynopticTab === 'tumor' && (
                <div style={{
                  background: 'white',
                  borderRadius: '8px',
                  padding: '16px',
                  border: '1px solid #e2e8f0'
                }}>
                  <h4 style={{ fontSize: '14px', fontWeight: 600, color: '#1e293b', marginBottom: '12px' }}>
                    Tumor Characteristics
                  </h4>
                  {tumorFields.map(renderField)}
                </div>
              )}

              {activeSynopticTab === 'margins' && (
                <div style={{
                  background: 'white',
                  borderRadius: '8px',
                  padding: '16px',
                  border: '1px solid #e2e8f0'
                }}>
                  <h4 style={{ fontSize: '14px', fontWeight: 600, color: '#1e293b', marginBottom: '12px' }}>
                    Margins
                  </h4>
                  {marginFields.map(renderField)}
                </div>
              )}

              {activeSynopticTab === 'biomarkers' && (
                <div style={{
                  background: 'white',
                  borderRadius: '8px',
                  padding: '16px',
                  border: '1px solid #e2e8f0'
                }}>
                  <h4 style={{ fontSize: '14px', fontWeight: 600, color: '#1e293b', marginBottom: '12px' }}>
                    Immunohistochemistry
                  </h4>
                  {biomarkerFields.map(renderField)}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Action Bar - Hidden in Expanded View */}
      {!isExpandedView && (
      <div style={{
        background: 'white',
        padding: '20px 40px',
        borderTop: '1px solid #e2e8f0',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        {!isFinalized ? (
          <>
            <div style={{ color: '#64748b', fontSize: '14px' }}>
              ⚠️ 1 field needs review (medium confidence)
            </div>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button
                onClick={handleNavigateWorklist}
                style={{
                  padding: '10px 20px',
                  border: '1px solid #cbd5e1',
                  borderRadius: '8px',
                  background: 'white',
                  fontWeight: 600,
                  fontSize: '14px',
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.background = '#f8fafc'}
                onMouseLeave={(e) => e.currentTarget.style.background = 'white'}
              >
                ← Back to Worklist
              </button>
              <button
                style={{
                  padding: '10px 20px',
                  border: '1px solid #cbd5e1',
                  borderRadius: '8px',
                  background: 'white',
                  fontWeight: 600,
                  fontSize: '14px',
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.background = '#f8fafc'}
                onMouseLeave={(e) => e.currentTarget.style.background = 'white'}
              >
                Save Draft
              </button>
              <button
                onClick={() => setIsFinalized(true)}
                style={{
                  padding: '10px 24px',
                  background: '#0891B2',
                  color: 'white',
                  borderRadius: '8px',
                  border: 'none',
                  fontWeight: 600,
                  fontSize: '14px',
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.background = '#0E7490'}
                onMouseLeave={(e) => e.currentTarget.style.background = '#0891B2'}
              >
                ✓ Finalize Synoptic
              </button>
            </div>
          </>
        ) : (
          <>
            <div style={{ 
              color: '#047857', 
              fontSize: '15px',
              fontWeight: 600,
              display: 'flex',
              alignItems: 'center',
              gap: '8px'
            }}>
              <span style={{ fontSize: '20px' }}>✓</span>
              Case {caseData.accession} - Specimen {specimens[activeSpecimen].id} finalized successfully
            </div>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button
                onClick={handleNavigateWorklist}
                style={{
                  padding: '12px 24px',
                  border: '2px solid #0891B2',
                  borderRadius: '8px',
                  background: 'white',
                  color: '#0891B2',
                  fontWeight: 600,
                  fontSize: '14px',
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(8, 145, 178, 0.1)'}
                onMouseLeave={(e) => e.currentTarget.style.background = 'white'}
              >
                ← Return to Worklist
              </button>
              <button
                onClick={() => alert('Load next case')}
                style={{
                  padding: '12px 24px',
                  background: '#0891B2',
                  color: 'white',
                  borderRadius: '8px',
                  border: 'none',
                  fontWeight: 600,
                  fontSize: '14px',
                  cursor: 'pointer',
                  transition: 'all 0.2s'
                }}
                onMouseEnter={(e) => e.currentTarget.style.background = '#0E7490'}
                onMouseLeave={(e) => e.currentTarget.style.background = '#0891B2'}
              >
                Next Case →
              </button>
            </div>
          </>
        )}
      </div>
      )}

      </div>

      {/* ADD SYNOPTIC REPORT MODAL */}
      {showAddSynopticModal && (
        <div 
          style={{ 
            position: 'fixed', 
            inset: 0, 
            backgroundColor: 'rgba(0,0,0,0.85)',
            backdropFilter: 'blur(10px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 10000
          }}
          onClick={() => setShowAddSynopticModal(false)}
        >
          <div 
            style={{ 
              width: '500px',
              backgroundColor: '#111', 
              borderRadius: '20px', 
              padding: '40px', 
              border: '1px solid rgba(8, 145, 178, 0.3)', 
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ 
              color: '#0891B2', 
              fontSize: '24px', 
              fontWeight: 700, 
              marginBottom: '24px',
              textAlign: 'center'
            }}>
              Add Synoptic Report
            </div>

            {/* Select Specimens */}
            <div style={{ marginBottom: '24px' }}>
              <div style={{ 
                color: '#94a3b8', 
                fontSize: '12px', 
                fontWeight: 700, 
                marginBottom: '12px',
                textTransform: 'uppercase'
              }}>
                Select Specimen(s)
              </div>
              {specimens.map((specimen) => (
                <label
                  key={specimen.id}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '12px',
                    borderRadius: '8px',
                    background: selectedSpecimens.includes(specimen.id) ? 'rgba(8, 145, 178, 0.1)' : 'rgba(255,255,255,0.03)',
                    border: `2px solid ${selectedSpecimens.includes(specimen.id) ? '#0891B2' : 'rgba(255,255,255,0.1)'}`,
                    marginBottom: '8px',
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                  }}
                  onMouseEnter={(e) => {
                    if (!selectedSpecimens.includes(specimen.id)) {
                      e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!selectedSpecimens.includes(specimen.id)) {
                      e.currentTarget.style.background = 'rgba(255,255,255,0.03)';
                    }
                  }}
                >
                  <input
                    type="checkbox"
                    checked={selectedSpecimens.includes(specimen.id)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedSpecimens([...selectedSpecimens, specimen.id]);
                      } else {
                        setSelectedSpecimens(selectedSpecimens.filter(id => id !== specimen.id));
                      }
                    }}
                    style={{
                      width: '18px',
                      height: '18px',
                      cursor: 'pointer'
                    }}
                  />
                  <div style={{ flex: 1 }}>
                    <div style={{ color: '#fff', fontSize: '14px', fontWeight: 600, marginBottom: '2px' }}>
                      Specimen {specimen.id}
                    </div>
                    <div style={{ color: '#94a3b8', fontSize: '12px' }}>
                      {specimen.name}
                    </div>
                  </div>
                </label>
              ))}
            </div>

            {/* Select Protocol - Autocomplete Search */}
            <div style={{ marginBottom: '24px', position: 'relative' }}>
              <div style={{ 
                color: '#94a3b8', 
                fontSize: '12px', 
                fontWeight: 700, 
                marginBottom: '12px',
                textTransform: 'uppercase'
              }}>
                Select Protocol
              </div>
              
              {/* Search Input */}
              <div style={{ position: 'relative' }}>
                <input
                  type="text"
                  value={selectedProtocol ? availableProtocols.find(p => p.id === selectedProtocol)?.name || '' : protocolSearch}
                  onChange={(e) => {
                    setProtocolSearch(e.target.value);
                    setSelectedProtocol('');
                    setShowProtocolDropdown(true);
                  }}
                  onFocus={() => setShowProtocolDropdown(true)}
                  placeholder="🔍 Search protocols... (e.g. breast, colon, lung)"
                  style={{
                    width: '100%',
                    padding: '12px 12px 12px 16px',
                    borderRadius: '8px',
                    background: 'rgba(255,255,255,0.05)',
                    border: `2px solid ${selectedProtocol ? '#0891B2' : 'rgba(255,255,255,0.1)'}`,
                    color: '#fff',
                    fontSize: '14px',
                    outline: 'none'
                  }}
                />
                
                {/* Dropdown Results */}
                {showProtocolDropdown && !selectedProtocol && (
                  <div style={{
                    position: 'absolute',
                    top: '100%',
                    left: 0,
                    right: 0,
                    marginTop: '4px',
                    maxHeight: '280px',
                    overflowY: 'auto',
                    background: '#1a1a1a',
                    borderRadius: '8px',
                    border: '1px solid rgba(255,255,255,0.2)',
                    boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
                    zIndex: 100
                  }}>
                    {filteredProtocols.length > 0 ? (
                      filteredProtocols.map((protocol) => (
                        <div
                          key={protocol.id}
                          onClick={() => {
                            setSelectedProtocol(protocol.id);
                            setProtocolSearch('');
                            setShowProtocolDropdown(false);
                          }}
                          style={{
                            padding: '12px 16px',
                            cursor: 'pointer',
                            borderBottom: '1px solid rgba(255,255,255,0.05)',
                            transition: 'background 0.2s'
                          }}
                          onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(8, 145, 178, 0.15)'}
                          onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                        >
                          <div style={{ color: '#fff', fontSize: '14px', fontWeight: 500 }}>
                            {protocol.name}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div style={{
                        padding: '16px',
                        color: '#94a3b8',
                        fontSize: '13px',
                        textAlign: 'center'
                      }}>
                        No protocols found matching "{protocolSearch}"
                      </div>
                    )}
                  </div>
                )}
              </div>
              
              {/* Selected Protocol Display */}
              {selectedProtocol && (
                <div style={{
                  marginTop: '8px',
                  padding: '10px 12px',
                  background: 'rgba(8, 145, 178, 0.15)',
                  border: '1px solid #0891B2',
                  borderRadius: '6px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}>
                  <span style={{ color: '#0891B2', fontSize: '13px', fontWeight: 600 }}>
                    ✓ {availableProtocols.find(p => p.id === selectedProtocol)?.name}
                  </span>
                  <button
                    onClick={() => {
                      setSelectedProtocol('');
                      setProtocolSearch('');
                    }}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: '#0891B2',
                      cursor: 'pointer',
                      fontSize: '16px',
                      padding: '0 4px'
                    }}
                    title="Clear selection"
                  >
                    ✕
                  </button>
                </div>
              )}
            </div>

            {/* AI Learning Checkbox */}
            <label style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              padding: '12px',
              borderRadius: '8px',
              background: 'rgba(16, 185, 129, 0.1)',
              border: '1px solid rgba(16, 185, 129, 0.3)',
              marginBottom: '24px',
              cursor: 'pointer'
            }}>
              <input
                type="checkbox"
                checked={learnPairing}
                onChange={(e) => setLearnPairing(e.target.checked)}
                style={{
                  width: '18px',
                  height: '18px',
                  cursor: 'pointer'
                }}
              />
              <div style={{ flex: 1 }}>
                <div style={{ color: '#10B981', fontSize: '13px', fontWeight: 600, marginBottom: '2px' }}>
                  🤖 Learn this pairing
                </div>
                <div style={{ color: '#6ee7b7', fontSize: '11px' }}>
                  AI will suggest this protocol for similar specimens in future cases
                </div>
              </div>
            </label>

            {/* Action Buttons */}
            <div style={{ display: 'flex', gap: '12px' }}>
              <button 
                onClick={() => setShowAddSynopticModal(false)} 
                style={{
                  flex: 1,
                  padding: '12px 24px',
                  borderRadius: '10px',
                  background: 'transparent',
                  border: '1px solid rgba(255,255,255,0.2)',
                  color: '#94a3b8',
                  fontWeight: 600,
                  fontSize: '15px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'transparent';
                }}
              >
                Cancel
              </button>
              <button 
                onClick={() => {
                  // In real app, create synoptic reports here
                  console.log('Creating synoptic for specimens:', selectedSpecimens);
                  console.log('Protocol:', selectedProtocol);
                  console.log('Learn pairing:', learnPairing);
                  setShowAddSynopticModal(false);
                  setSelectedSpecimens([]);
                  setSelectedProtocol('');
                  setProtocolSearch('');
                }}
                disabled={selectedSpecimens.length === 0 || !selectedProtocol}
                style={{
                  flex: 1,
                  padding: '12px 24px',
                  borderRadius: '10px',
                  background: (selectedSpecimens.length === 0 || !selectedProtocol) ? 'rgba(8, 145, 178, 0.2)' : '#0891B2',
                  border: 'none',
                  color: (selectedSpecimens.length === 0 || !selectedProtocol) ? '#64748b' : '#fff',
                  fontWeight: 600,
                  fontSize: '15px',
                  cursor: (selectedSpecimens.length === 0 || !selectedProtocol) ? 'not-allowed' : 'pointer',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  if (selectedSpecimens.length > 0 && selectedProtocol) {
                    e.currentTarget.style.background = '#0E7490';
                  }
                }}
                onMouseLeave={(e) => {
                  if (selectedSpecimens.length > 0 && selectedProtocol) {
                    e.currentTarget.style.background = '#0891B2';
                  }
                }}
              >
                Add Report
              </button>
            </div>
          </div>
        </div>
      )}

      {/* UNSAVED DATA WARNING MODAL */}
      {showWarning && (
        <div 
          style={{ 
            position: 'fixed', 
            inset: 0, 
            backgroundColor: 'rgba(0,0,0,0.85)',
            backdropFilter: 'blur(10px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 10000
          }}
        >
          <div style={{ 
            width: '400px', 
            backgroundColor: '#111', 
            padding: '40px', 
            borderRadius: '28px', 
            textAlign: 'center', 
            border: '1px solid rgba(255,255,255,0.1)', 
            boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)' 
          }}>
            <div style={{ marginBottom: '20px', display: 'flex', justifyContent: 'center' }}>
              <span style={{ fontSize: '48px' }}>⚠️</span>
            </div>
            <h2 style={{ fontSize: '24px', fontWeight: 800, color: '#fff', margin: '0 0 12px 0' }}>
              Unsaved Synoptic Data
            </h2>
            <p style={{ color: '#94a3b8', marginBottom: '30px', lineHeight: '1.6', fontSize: '15px' }}>
              You have unsaved changes to this synoptic report. Leaving now will discard your current progress.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <button 
                onClick={() => {
                  setShowWarning(false);
                  setPendingNavigation(null);
                }}
                autoFocus
                style={{
                  padding: '16px 24px',
                  borderRadius: '12px',
                  background: '#0891B2',
                  border: 'none',
                  color: '#fff',
                  fontWeight: 700,
                  fontSize: '16px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => e.currentTarget.style.background = '#0E7490'}
                onMouseLeave={(e) => e.currentTarget.style.background = '#0891B2'}
              >
                ← Stay and Continue Editing
              </button>
              <button 
                onClick={confirmNavigation}
                style={{
                  padding: '16px 24px',
                  borderRadius: '12px',
                  background: 'transparent',
                  border: '2px solid #F59E0B',
                  color: '#F59E0B',
                  fontWeight: 600,
                  fontSize: '15px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = '#F59E0B';
                  e.currentTarget.style.color = '#000';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'transparent';
                  e.currentTarget.style.color = '#F59E0B';
                }}
              >
                Leave & Discard Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PROFILE MODAL - Full Version */}
      {isProfileOpen && (
        <div 
          style={{ 
            position: 'fixed', 
            inset: 0, 
            backgroundColor: 'rgba(0,0,0,0.85)',
            backdropFilter: 'blur(10px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 10000
          }}
          onClick={() => setIsProfileOpen(false)}
        >
          <div 
            style={{ 
              width: '400px',
              backgroundColor: '#111', 
              borderRadius: '20px', 
              padding: '40px', 
              border: '1px solid rgba(8, 145, 178, 0.3)', 
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
              textAlign: 'center'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ 
              color: '#0891B2', 
              fontSize: '24px', 
              fontWeight: 700, 
              marginBottom: '24px'
            }}>
              User Preferences
            </div>

            <div style={{ marginBottom: '32px' }}>
              <div style={{ color: '#64748b', fontSize: '12px', fontWeight: 800, textTransform: 'uppercase', marginBottom: '12px', textAlign: 'left' }}>
                Appearance
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
                <button 
                  onClick={() => { /* setCurrentTheme('light'); */ }} 
                  style={{
                    background: currentTheme === 'light' ? 'rgba(8, 145, 178, 0.2)' : 'rgba(255,255,255,0.05)',
                    border: currentTheme === 'light' ? '2px solid #0891B2' : '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '12px',
                    color: '#fff',
                    padding: '16px',
                    cursor: 'pointer',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '8px',
                    transition: 'all 0.2s',
                    opacity: 0.5
                  }}
                  title="Coming soon"
                >
                  <SunIcon />
                  <span style={{ fontSize: '12px', fontWeight: 600 }}>Light</span>
                </button>
                <button 
                  onClick={() => { /* setCurrentTheme('dark'); */ }} 
                  style={{
                    background: currentTheme === 'dark' ? 'rgba(8, 145, 178, 0.2)' : 'rgba(255,255,255,0.05)',
                    border: currentTheme === 'dark' ? '2px solid #0891B2' : '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '12px',
                    color: '#fff',
                    padding: '16px',
                    cursor: 'pointer',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '8px',
                    transition: 'all 0.2s',
                    opacity: 0.5
                  }}
                  title="Coming soon"
                >
                  <MoonIcon />
                  <span style={{ fontSize: '12px', fontWeight: 600 }}>Dark</span>
                </button>
                <button 
                  onClick={() => { /* setCurrentTheme('auto'); */ }} 
                  style={{
                    background: currentTheme === 'auto' ? 'rgba(8, 145, 178, 0.2)' : 'rgba(255,255,255,0.05)',
                    border: currentTheme === 'auto' ? '2px solid #0891B2' : '1px solid rgba(255,255,255,0.1)',
                    borderRadius: '12px',
                    color: '#fff',
                    padding: '16px',
                    cursor: 'pointer',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    gap: '8px',
                    transition: 'all 0.2s',
                    opacity: 0.5
                  }}
                  title="Coming soon"
                >
                  <MonitorIcon />
                  <span style={{ fontSize: '12px', fontWeight: 600 }}>Auto</span>
                </button>
              </div>
            </div>

            <div style={{ marginBottom: '24px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <button 
                onClick={() => { 
                  window.open('https://www.cap.org/', '_blank'); 
                  setIsProfileOpen(false); 
                }} 
                style={{
                  padding: '12px 16px',
                  borderRadius: '10px',
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  color: '#cbd5e1',
                  fontWeight: 600,
                  fontSize: '15px',
                  cursor: 'pointer',
                  width: '100%',
                  transition: 'all 0.2s',
                  textAlign: 'left',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(8, 145, 178, 0.1)';
                  e.currentTarget.style.color = '#0891B2';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                  e.currentTarget.style.color = '#cbd5e1';
                }}
              >
                <HelpIcon /> Support & Protocols
              </button>
              
              <button 
                onClick={() => { 
                  setShowAbout(true); 
                  setIsProfileOpen(false); 
                }} 
                style={{
                  padding: '12px 16px',
                  borderRadius: '10px',
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  color: '#cbd5e1',
                  fontWeight: 600,
                  fontSize: '15px',
                  cursor: 'pointer',
                  width: '100%',
                  transition: 'all 0.2s',
                  textAlign: 'left',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '10px'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = 'rgba(8, 145, 178, 0.1)';
                  e.currentTarget.style.color = '#0891B2';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                  e.currentTarget.style.color = '#cbd5e1';
                }}
              >
                <HelpIcon /> About PathScribe<span style={{ color: '#0891B2', fontSize: '0.6em', verticalAlign: 'super', marginLeft: '0.2em' }}>AI</span>
              </button>
            </div>

            <button 
              onClick={() => setIsProfileOpen(false)} 
              autoFocus
              style={{
                padding: '12px 24px',
                borderRadius: '10px',
                background: 'rgba(8, 145, 178, 0.15)',
                border: '1px solid rgba(8, 145, 178, 0.3)',
                color: '#0891B2',
                fontWeight: 600,
                fontSize: '15px',
                cursor: 'pointer',
                width: '100%',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(8, 145, 178, 0.25)'}
              onMouseLeave={(e) => e.currentTarget.style.background = 'rgba(8, 145, 178, 0.15)'}
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* ABOUT MODAL */}
      {showAbout && (
        <div 
          style={{
            position: 'fixed',
            inset: 0,
            backgroundColor: 'rgba(0,0,0,0.85)',
            backdropFilter: 'blur(12px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 10000
          }}
          onClick={() => setShowAbout(false)}
        >
          <div 
            style={{
              width: '400px',
              backgroundColor: 'rgba(220, 220, 220, 0.75)',
              backdropFilter: 'blur(40px)',
              padding: '40px',
              borderRadius: '20px',
              textAlign: 'center',
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
              border: '1px solid rgba(255, 255, 255, 0.3)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
             <h2 style={{ 
               fontSize: '32px', 
               fontWeight: 700, 
               color: '#1a1a1a', 
               margin: '0 0 16px 0',
               letterSpacing: '-0.5px'
             }}>
               PathScribe<span style={{ color: '#0891B2', fontSize: '0.6em', verticalAlign: 'super', marginLeft: '0.1em' }}>AI</span>
             </h2>
             
             <p style={{ color: '#3a3a3a', marginBottom: '8px', fontSize: '15px', lineHeight: '1.6' }}>
               Version 1.0.0 | Build: 2026-02-14
             </p>
             
             <p style={{ color: '#3a3a3a', marginBottom: '20px', fontSize: '15px', lineHeight: '1.6' }}>
               Developed by the PathScribe AI Team
             </p>
             
             <p style={{ color: '#5a5a5a', marginBottom: '30px', fontSize: '14px' }}>
               © 2026 PathScribe
             </p>
             
             <button 
               onClick={() => setShowAbout(false)} 
               autoFocus
               style={{
                 padding: '12px 32px',
                 borderRadius: '8px',
                 background: 'rgba(160, 160, 160, 0.5)',
                 border: 'none',
                 color: '#1a1a1a',
                 fontWeight: 600,
                 fontSize: '15px',
                 cursor: 'pointer',
                 width: '100%',
                 transition: 'all 0.2s ease'
               }}
               onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(140, 140, 140, 0.6)'}
               onMouseLeave={(e) => e.currentTarget.style.background = 'rgba(160, 160, 160, 0.5)'}
             >
               Close
             </button>
          </div>
        </div>
      )}

      {/* QUICK LINKS MODAL */}
      {isResourcesOpen && (
        <div 
          style={{ 
            position: 'fixed', 
            inset: 0, 
            backgroundColor: 'rgba(0,0,0,0.85)',
            backdropFilter: 'blur(10px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 10000
          }}
          onClick={() => setIsResourcesOpen(false)}
        >
          <div 
            style={{ 
              width: '500px',
              maxHeight: '80vh',
              overflowY: 'auto',
              backgroundColor: '#111', 
              borderRadius: '20px', 
              padding: '40px', 
              border: '1px solid rgba(8, 145, 178, 0.3)', 
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)'
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ 
              color: '#0891B2', 
              fontSize: '24px', 
              fontWeight: 700, 
              marginBottom: '24px',
              textAlign: 'center'
            }}>
              Quick Links
            </div>

            <div style={{ marginBottom: '24px' }}>
              <div style={{ 
                color: '#94a3b8', 
                fontSize: '12px', 
                fontWeight: 700, 
                marginBottom: '12px',
                textTransform: 'uppercase'
              }}>
                Protocols
              </div>
              {quickLinks.protocols.map((link, i) => (
                <a            
                  key={i}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setIsResourcesOpen(false)}
                  style={{
                    display: 'block',
                    color: '#cbd5e1',
                    textDecoration: 'none',
                    padding: '12px 16px',
                    fontSize: '16px',
                    transition: 'all 0.2s',
                    borderRadius: '8px',
                    marginBottom: '8px'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = '#0891B2';
                    e.currentTarget.style.backgroundColor = 'rgba(8, 145, 178, 0.1)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = '#cbd5e1';
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  → {link.title}
                </a>
              ))}
            </div>

            <div style={{ marginBottom: '24px' }}>
              <div style={{ 
                color: '#94a3b8', 
                fontSize: '12px', 
                fontWeight: 700, 
                marginBottom: '12px',
                textTransform: 'uppercase'
              }}>
                References
              </div>
              {quickLinks.references.map((link, i) => (
                <a
                  key={i}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setIsResourcesOpen(false)}
                  style={{
                    display: 'block',
                    color: '#cbd5e1',
                    textDecoration: 'none',
                    padding: '12px 16px',
                    fontSize: '16px',
                    transition: 'all 0.2s',
                    borderRadius: '8px',
                    marginBottom: '8px'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = '#0891B2';
                    e.currentTarget.style.backgroundColor = 'rgba(8, 145, 178, 0.1)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = '#cbd5e1';
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  → {link.title}
                </a>
              ))}
            </div>

            <div style={{ marginBottom: '24px' }}>
              <div style={{ 
                color: '#94a3b8', 
                fontSize: '12px', 
                fontWeight: 700, 
                marginBottom: '12px',
                textTransform: 'uppercase'
              }}>
                Systems
              </div>
              {quickLinks.systems.map((link, i) => (
                <a
                  key={i}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => setIsResourcesOpen(false)}
                  style={{
                    display: 'block',
                    color: '#cbd5e1',
                    textDecoration: 'none',
                    padding: '12px 16px',
                    fontSize: '16px',
                    transition: 'all 0.2s',
                    borderRadius: '8px',
                    marginBottom: '8px'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = '#0891B2';
                    e.currentTarget.style.backgroundColor = 'rgba(8, 145, 178, 0.1)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = '#cbd5e1';
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  → {link.title}
                </a>
              ))}
            </div>

            <button 
              onClick={() => setIsResourcesOpen(false)} 
              autoFocus
              style={{
                padding: '12px 24px',
                borderRadius: '10px',
                background: 'rgba(8, 145, 178, 0.15)',
                border: '1px solid rgba(8, 145, 178, 0.3)',
                color: '#0891B2',
                fontWeight: 600,
                fontSize: '15px',
                cursor: 'pointer',
                width: '100%',
                transition: 'all 0.2s ease'
              }}
              onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(8, 145, 178, 0.25)'}
 onMouseLeave={(e) => e.currentTarget.style.background = 'rgba(8, 145, 178, 0.15)'}
>
  Close
</button>
</div>
</div>
)}   {/* closes quick links modal */}

{showLogoutModal && (
  <div 
    style={{
      position: 'fixed',
      inset: 0,
      backgroundColor: 'rgba(0,0,0,0.85)',
      backdropFilter: 'blur(10px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 10000
    }}
  >
    <div
      style={{
        width: '400px',
        backgroundColor: '#111',
        padding: '40px',
        borderRadius: '28px',
        textAlign: 'center',
        border: '1px solid rgba(255,255,255,0.1)',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)'
      }}
    >
      <div style={{ marginBottom: '20px', display: 'flex', justifyContent: 'center' }}>
        <WarningIcon color="#F59E0B" />
      </div>
      <h2 style={{ fontSize: '24px', fontWeight: 800, color: '#fff', margin: '0 0 12px 0' }}>
        Unsaved Data
      </h2>

      <p style={{ color: '#94a3b8', marginBottom: '30px', lineHeight: '1.6', fontSize: '15px' }}>
        You have an active session with unsaved changes. Logging out now will discard your current progress.
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        <button
          onClick={() => setShowLogoutModal(false)}
          autoFocus
          style={{
            padding: '16px 24px',
            borderRadius: '12px',
            background: '#0891B2',
            border: 'none',
            color: '#fff',
            fontWeight: 700,
            fontSize: '16px',
            cursor: 'pointer',
            width: '100%',
            transition: 'all 0.2s ease'
          }}
          onMouseEnter={(e) => e.currentTarget.style.background = '#0E7490'}
          onMouseLeave={(e) => e.currentTarget.style.background = '#0891B2'}
        >
          ← Return to Page
        </button>

        <button
          onClick={handleLogout}
          style={{
            padding: '16px 24px',
            borderRadius: '12px',
            background: 'transparent',
            border: '2px solid #F59E0B',
            color: '#F59E0B',
            fontWeight: 600,
            fontSize: '15px',
            cursor: 'pointer',
            width: '100%',
            transition: 'all 0.2s ease'
          }}
          onMouseEnter={(e) => { e.currentTarget.style.background = '#F59E0B'; e.currentTarget.style.color = '#000'; }}
          onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#F59E0B'; }}
        >
          Log Out & Discard Changes
        </button>
      </div>
    </div>
  </div>
)}

</div>
);
};

export default SynopticReportPage;