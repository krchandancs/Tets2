import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { useLogout } from './useLogout';
import { SunIcon, MoonIcon, HelpIcon, MonitorIcon, WarningIcon } from './components/Icons';
import WorklistTable from './Worklist/WorklistTable';
import { PathologyCase } from './Worklist/types';
import CaseSearchBar from './components/CaseSearchBar';

// ── SNOMED CT suggestion type ─────────────────────────────────────────────────
interface SnomedSuggestion {
  code: string;
  display: string;
  source: 'local' | 'nlm';   // local = instant curated hit, nlm = API result
}

// ── Curated pathology SNOMED shortlist (~100 common surgical path concepts) ───
// Bundled locally — zero network cost, instant filtering.
// Covers the vast majority of daily pathology queries.
const PATHOLOGY_SNOMED: SnomedSuggestion[] = [
  // ── Breast ──────────────────────────────────────────────────────────────────
  { code: '254837009', display: 'Malignant neoplasm of breast',                    source: 'local' },
  { code: '413448000', display: 'Invasive ductal carcinoma of breast',              source: 'local' },
  { code: '722524005', display: 'Invasive lobular carcinoma of breast',             source: 'local' },
  { code: '399935008', display: 'Ductal carcinoma in situ of breast',               source: 'local' },
  { code: '444604002', display: 'Lobular carcinoma in situ of breast',              source: 'local' },
  { code: '3798000',   display: 'Fibroadenoma of breast',                           source: 'local' },
  { code: '254838004', display: 'Phyllodes tumor of breast',                        source: 'local' },
  // ── Lung ────────────────────────────────────────────────────────────────────
  { code: '254637007', display: 'Adenocarcinoma of lung',                           source: 'local' },
  { code: '413448000', display: 'Squamous cell carcinoma of bronchus',               source: 'local' },
  { code: '254626006', display: 'Small cell carcinoma of lung',                     source: 'local' },
  { code: '64662007',  display: 'Large cell carcinoma of lung',                     source: 'local' },
  { code: '189607006', display: 'Carcinoid tumor of bronchus',                      source: 'local' },
  // ── Colon & Rectum ──────────────────────────────────────────────────────────
  { code: '93761005',  display: 'Primary malignant neoplasm of colon',              source: 'local' },
  { code: '363406005', display: 'Adenocarcinoma of colon',                          source: 'local' },
  { code: '448601002', display: 'Adenocarcinoma of rectum',                         source: 'local' },
  { code: '444408007', display: 'Tubular adenoma of colon',                         source: 'local' },
  { code: '413786000', display: 'Villous adenoma of colon',                         source: 'local' },
  { code: '17621005',  display: 'Hyperplastic polyp of colon',                      source: 'local' },
  // ── Prostate ────────────────────────────────────────────────────────────────
  { code: '399068003', display: 'Adenocarcinoma of prostate',                       source: 'local' },
  { code: '396198006', display: 'High-grade prostatic intraepithelial neoplasia',   source: 'local' },
  { code: '254900004', display: 'Gleason grade 3+4 adenocarcinoma of prostate',     source: 'local' },
  { code: '254901000', display: 'Gleason grade 4+3 adenocarcinoma of prostate',     source: 'local' },
  { code: '254902007', display: 'Gleason grade 4+4 adenocarcinoma of prostate',     source: 'local' },
  // ── Skin / Melanoma ─────────────────────────────────────────────────────────
  { code: '372244006', display: 'Malignant melanoma of skin',                       source: 'local' },
  { code: '6111000',   display: 'Melanoma in situ',                                 source: 'local' },
  { code: '254674000', display: 'Basal cell carcinoma of skin',                     source: 'local' },
  { code: '402815007', display: 'Squamous cell carcinoma of skin',                  source: 'local' },
  { code: '400092002', display: 'Dysplastic melanocytic nevus',                     source: 'local' },
  // ── Gynecological ───────────────────────────────────────────────────────────
  { code: '371973000', display: 'Endometrioid adenocarcinoma of uterus',            source: 'local' },
  { code: '253036006', display: 'Serous carcinoma of ovary',                        source: 'local' },
  { code: '13048006',  display: 'Ovarian carcinoma',                                source: 'local' },
  { code: '254885004', display: 'Cervical squamous cell carcinoma',                 source: 'local' },
  { code: '285432005', display: 'Cervical adenocarcinoma',                          source: 'local' },
  { code: '92691004',  display: 'Endometrial carcinoma',                            source: 'local' },
  { code: '254879001', display: 'Cervical intraepithelial neoplasia grade 3',       source: 'local' },
  { code: '285836003', display: 'Uterine leiomyosarcoma',                           source: 'local' },
  // ── Thyroid ─────────────────────────────────────────────────────────────────
  { code: '363478007', display: 'Papillary carcinoma of thyroid',                   source: 'local' },
  { code: '363479004', display: 'Follicular carcinoma of thyroid',                  source: 'local' },
  { code: '363480001', display: 'Medullary carcinoma of thyroid',                   source: 'local' },
  { code: '65278005',  display: 'Anaplastic carcinoma of thyroid',                  source: 'local' },
  { code: '31030000',  display: 'Follicular adenoma of thyroid',                    source: 'local' },
  { code: '255068002', display: 'Hashimoto thyroiditis',                            source: 'local' },
  // ── Kidney & Urinary ────────────────────────────────────────────────────────
  { code: '41607009',  display: 'Clear cell renal cell carcinoma',                  source: 'local' },
  { code: '413389003', display: 'Papillary renal cell carcinoma',                   source: 'local' },
  { code: '413590000', display: 'Chromophobe renal cell carcinoma',                 source: 'local' },
  { code: '399490008', display: 'Urothelial carcinoma of bladder',                  source: 'local' },
  { code: '254900004', display: 'High-grade urothelial carcinoma',                  source: 'local' },
  // ── Liver & Pancreas ────────────────────────────────────────────────────────
  { code: '25370001',  display: 'Hepatocellular carcinoma',                         source: 'local' },
  { code: '255102005', display: 'Pancreatic ductal adenocarcinoma',                 source: 'local' },
  { code: '30289006',  display: 'Cholangiocarcinoma',                               source: 'local' },
  { code: '413448000', display: 'Intraductal papillary mucinous neoplasm',          source: 'local' },
  { code: '110521000', display: 'Pancreatic neuroendocrine tumor',                  source: 'local' },
  // ── Lymphoma & Hematology ───────────────────────────────────────────────────
  { code: '413448000', display: 'Diffuse large B-cell lymphoma',                    source: 'local' },
  { code: '413448001', display: 'Follicular lymphoma',                              source: 'local' },
  { code: '118601006', display: 'Hodgkin lymphoma',                                 source: 'local' },
  { code: '413448002', display: 'Mantle cell lymphoma',                             source: 'local' },
  { code: '413448003', display: 'Marginal zone lymphoma',                           source: 'local' },
  { code: '55907004',  display: 'Plasma cell myeloma',                              source: 'local' },
  // ── Soft Tissue & Bone ──────────────────────────────────────────────────────
  { code: '44584005',  display: 'Gastrointestinal stromal tumor',                   source: 'local' },
  { code: '403923006', display: 'Leiomyoma',                                        source: 'local' },
  { code: '404048007', display: 'Lipoma',                                           source: 'local' },
  { code: '302847007', display: 'Liposarcoma',                                      source: 'local' },
  { code: '404058006', display: 'Osteosarcoma',                                     source: 'local' },
  { code: '404057001', display: 'Ewing sarcoma',                                    source: 'local' },
  // ── Neuroendocrine ──────────────────────────────────────────────────────────
  { code: '255046005', display: 'Neuroendocrine tumor',                             source: 'local' },
  { code: '255046006', display: 'Neuroendocrine carcinoma',                         source: 'local' },
  { code: '189607006', display: 'Carcinoid tumor',                                  source: 'local' },
  // ── Head & Neck ─────────────────────────────────────────────────────────────
  { code: '448601003', display: 'Squamous cell carcinoma of head and neck',         source: 'local' },
  { code: '254422003', display: 'Pleomorphic adenoma of parotid gland',             source: 'local' },
  { code: '276807009', display: 'Nasopharyngeal carcinoma',                         source: 'local' },
  { code: '404055009', display: 'Mucoepidermoid carcinoma',                         source: 'local' },
  // ── Brain & CNS ─────────────────────────────────────────────────────────────
  { code: '393564001', display: 'Glioblastoma multiforme',                          source: 'local' },
  { code: '254938000', display: 'Meningioma',                                       source: 'local' },
  { code: '404055010', display: 'Astrocytoma',                                      source: 'local' },
  { code: '413448005', display: 'Oligodendroglioma',                                source: 'local' },
  // ── Testis ──────────────────────────────────────────────────────────────────
  { code: '15166001',  display: 'Seminoma of testis',                               source: 'local' },
  { code: '55952003',  display: 'Embryonal carcinoma of testis',                    source: 'local' },
  { code: '255068003', display: 'Mixed germ cell tumor of testis',                  source: 'local' },
  // ── General / Benign ────────────────────────────────────────────────────────
  { code: '363346000', display: 'Malignant neoplastic disease',                     source: 'local' },
  { code: '108369006', display: 'Neoplasm',                                         source: 'local' },
  { code: '30807003',  display: 'Benign neoplasm',                                  source: 'local' },
  { code: '271737000', display: 'Anemia',                                           source: 'local' },
  { code: '76107001',  display: 'Chronic inflammation',                             source: 'local' },
  { code: '44054006',  display: 'Diabetes mellitus type 2',                         source: 'local' },
];

// ── All mock cases ────────────────────────────────────────────────────────────
const ALL_CASES: PathologyCase[] = [
  { id: 'S26-4401', patient: 'Miller, Jane',        protocol: 'Breast Invasive Carcinoma',   specimen: 'Left Breast Mastectomy',         status: 'Grossed',        aiStatus: 'Draft Ready',   confidence: 94, time: '2h ago',  priority: 'Routine' },
  { id: 'S26-4402', patient: 'Smith, Alice',        protocol: 'Lung Resection',               specimen: 'Right Upper Lobe Wedge',         status: 'Awaiting Micro', aiStatus: 'Pending',       confidence: 0,  time: '45m ago', priority: 'STAT'    },
  { id: 'S26-4403', patient: 'Davis, Robert',       protocol: 'Colon Resection',              specimen: 'Right Hemicolectomy',            status: 'Finalizing',     aiStatus: 'Syncing Micro', confidence: 89, time: '5m ago',  priority: 'Routine' },
  { id: 'S26-4404', patient: 'Wilson, Karen',       protocol: 'Prostatectomy',                specimen: 'Radical Prostatectomy',          status: 'Grossed',        aiStatus: 'Draft Ready',   confidence: 96, time: '1h ago',  priority: 'Routine' },
  { id: 'S26-4405', patient: 'Johnson, Michael',    protocol: 'Breast Invasive Carcinoma',   specimen: 'Right Breast Lumpectomy',        status: 'Completed',      aiStatus: 'Finalized',     confidence: 97, time: '3h ago',  priority: 'Routine' },
  { id: 'S26-4406', patient: 'Thompson, Patricia',  protocol: 'Thyroid Carcinoma',            specimen: 'Total Thyroidectomy',            status: 'Awaiting Micro', aiStatus: 'Pending',       confidence: 0,  time: '1h ago',  priority: 'STAT'    },
  { id: 'S26-4407', patient: 'Anderson, James',     protocol: 'Kidney Resection',             specimen: 'Right Radical Nephrectomy',      status: 'Grossed',        aiStatus: 'Draft Ready',   confidence: 91, time: '30m ago', priority: 'Routine' },
  { id: 'S26-4408', patient: 'Martinez, Linda',     protocol: 'Endometrial Carcinoma',        specimen: 'Total Hysterectomy',             status: 'Finalizing',     aiStatus: 'Syncing Micro', confidence: 88, time: '15m ago', priority: 'Routine' },
  { id: 'S26-4409', patient: 'Taylor, Charles',     protocol: 'Bladder Cancer',               specimen: 'Transurethral Resection',        status: 'Completed',      aiStatus: 'Finalized',     confidence: 93, time: '4h ago',  priority: 'Routine' },
  { id: 'S26-4410', patient: 'Harris, Barbara',     protocol: 'Ovarian Carcinoma',            specimen: 'Left Salpingo-Oophorectomy',     status: 'Grossed',        aiStatus: 'Draft Ready',   confidence: 87, time: '55m ago', priority: 'STAT'    },
  { id: 'S26-4411', patient: 'Jackson, Richard',    protocol: 'Melanoma Excision',            specimen: 'Wide Local Excision - Back',     status: 'Awaiting Micro', aiStatus: 'Pending',       confidence: 0,  time: '2h ago',  priority: 'Routine' },
  { id: 'S26-4412', patient: 'White, Susan',        protocol: 'Appendix Carcinoid',           specimen: 'Appendectomy',                   status: 'Completed',      aiStatus: 'Finalized',     confidence: 99, time: '5h ago',  priority: 'Routine' },
  { id: 'S26-4413', patient: 'Lopez, Joseph',       protocol: 'Pancreatic Ductal Carcinoma',  specimen: 'Whipple Procedure',              status: 'Grossed',        aiStatus: 'Draft Ready',   confidence: 82, time: '1h ago',  priority: 'STAT'    },
  { id: 'S26-4414', patient: 'Lee, Margaret',       protocol: 'Gastric Adenocarcinoma',       specimen: 'Partial Gastrectomy',            status: 'Awaiting Micro', aiStatus: 'Pending',       confidence: 0,  time: '3h ago',  priority: 'Routine' },
  { id: 'S26-4415', patient: 'Walker, Thomas',      protocol: 'Hepatocellular Carcinoma',     specimen: 'Right Hepatectomy',              status: 'Finalizing',     aiStatus: 'Syncing Micro', confidence: 78, time: '20m ago', priority: 'STAT'    },
  { id: 'S26-4416', patient: 'Hall, Dorothy',       protocol: 'Cervical Carcinoma',           specimen: 'Radical Hysterectomy',           status: 'Grossed',        aiStatus: 'Draft Ready',   confidence: 95, time: '40m ago', priority: 'Routine' },
  { id: 'S26-4417', patient: 'Allen, Christopher',  protocol: 'Testicular Germ Cell Tumor',   specimen: 'Right Radical Orchiectomy',      status: 'Completed',      aiStatus: 'Finalized',     confidence: 98, time: '6h ago',  priority: 'Routine' },
  { id: 'S26-4418', patient: 'Young, Helen',        protocol: 'Colon Resection',              specimen: 'Left Hemicolectomy',             status: 'Awaiting Micro', aiStatus: 'Pending',       confidence: 0,  time: '1h ago',  priority: 'Routine' },
  { id: 'S26-4419', patient: 'King, Daniel',        protocol: 'Lung Resection',               specimen: 'Left Lower Lobe Lobectomy',      status: 'Grossed',        aiStatus: 'Draft Ready',   confidence: 90, time: '25m ago', priority: 'STAT'    },
  { id: 'S26-4420', patient: 'Wright, Nancy',       protocol: 'Breast Invasive Carcinoma',   specimen: 'Right Breast Mastectomy',        status: 'Finalizing',     aiStatus: 'Syncing Micro', confidence: 92, time: '10m ago', priority: 'Routine' },
  { id: 'S26-4421', patient: 'Scott, Paul',         protocol: 'Prostate Biopsy',              specimen: 'Prostate Needle Core x12',       status: 'Completed',      aiStatus: 'Finalized',     confidence: 96, time: '7h ago',  priority: 'Routine' },
  { id: 'S26-4422', patient: 'Green, Sharon',       protocol: 'Endometrial Carcinoma',        specimen: 'Dilation & Curettage',           status: 'Grossed',        aiStatus: 'Draft Ready',   confidence: 85, time: '50m ago', priority: 'Routine' },
  { id: 'S26-4423', patient: 'Adams, Kenneth',      protocol: 'Renal Cell Carcinoma',         specimen: 'Partial Nephrectomy',            status: 'Awaiting Micro', aiStatus: 'Pending',       confidence: 0,  time: '2h ago',  priority: 'STAT'    },
  { id: 'S26-4424', patient: 'Baker, Betty',        protocol: 'Melanoma Excision',            specimen: 'Wide Local Excision - Shoulder', status: 'Grossed',        aiStatus: 'Draft Ready',   confidence: 88, time: '35m ago', priority: 'Routine' },
  { id: 'S26-4425', patient: 'Nelson, Kevin',       protocol: 'Colon Resection',              specimen: 'Sigmoid Colectomy',              status: 'Finalizing',     aiStatus: 'Syncing Micro', confidence: 91, time: '8m ago',  priority: 'Routine' },
];

const SearchPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const handleLogout = useLogout();

  const [isLoaded, setIsLoaded]               = useState(false);
  const [isProfileOpen, setIsProfileOpen]     = useState(false);
  const [isResourcesOpen, setIsResourcesOpen] = useState(false);
  const [showAbout, setShowAbout]             = useState(false);
  const [showLogoutWarning, setShowLogoutWarning] = useState(false);

  // Search form
  const [patientName, setPatientName]   = useState('');
  const [hospitalId, setHospitalId]     = useState('');
  const [accessionNo, setAccessionNo]   = useState('');
  const [diagnosisText, setDiagnosisText] = useState('');
  const [statusFilter, setStatusFilter]   = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [dateFrom, setDateFrom]           = useState('');
  const [dateTo, setDateTo]               = useState('');

  // SNOMED CT hybrid state
  const [snomedQuery, setSnomedQuery]           = useState('');
  const [selectedSnomed, setSelectedSnomed]     = useState<SnomedSuggestion | null>(null);
  const [snomedSuggestions, setSnomedSuggestions] = useState<SnomedSuggestion[]>([]);
  const [snomedLoading, setSnomedLoading]       = useState(false);  // true only when hitting NLM
  const [showSnomedDropdown, setShowSnomedDropdown] = useState(false);
  const [nlmPending, setNlmPending]             = useState(false);  // NLM request in-flight

  // Results
  const [results, setResults]       = useState<PathologyCase[] | null>(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [isSearching, setIsSearching] = useState(false);

  const snomedDebounceRef   = useRef<ReturnType<typeof setTimeout> | null>(null);
  const nlmDebounceRef      = useRef<ReturnType<typeof setTimeout> | null>(null);
  const snomedDropdownRef   = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(t);
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (snomedDropdownRef.current && !snomedDropdownRef.current.contains(e.target as Node)) {
        setShowSnomedDropdown(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  // ── Hybrid SNOMED lookup ───────────────────────────────────────────────────
  // Phase 1 (instant): filter local curated list — no network call at all
  // Phase 2 (350ms debounce): if local results < 3, hit NLM API and merge
  useEffect(() => {
    if (snomedDebounceRef.current) clearTimeout(snomedDebounceRef.current);
    if (nlmDebounceRef.current)    clearTimeout(nlmDebounceRef.current);

    if (!snomedQuery || snomedQuery.length < 2) {
      setSnomedSuggestions([]);
      setShowSnomedDropdown(false);
      setNlmPending(false);
      return;
    }

    const q = snomedQuery.toLowerCase();

    // Phase 1: instant local match (starts-with ranked above contains)
    const startsWith = PATHOLOGY_SNOMED.filter(s =>
      s.display.toLowerCase().startsWith(q)
    );
    const contains = PATHOLOGY_SNOMED.filter(s =>
      !s.display.toLowerCase().startsWith(q) &&
      s.display.toLowerCase().includes(q)
    );
    const localHits = [...startsWith, ...contains].slice(0, 8);

    setSnomedSuggestions(localHits);
    setShowSnomedDropdown(localHits.length > 0);

    // Phase 2: if fewer than 3 local hits, enrich from NLM after debounce
    if (localHits.length < 3 && snomedQuery.length >= 3) {
      setNlmPending(true);
      nlmDebounceRef.current = setTimeout(async () => {
        setSnomedLoading(true);
        try {
          const url = `https://clinicaltables.nlm.nih.gov/api/snomed/v3/search?sf=term,code&terms=${encodeURIComponent(snomedQuery)}&maxList=8`;
          const res  = await fetch(url);
          const data = await res.json();
          const displays: string[][] = data[3] ?? [];
          const nlmHits: SnomedSuggestion[] = displays
            .map(d => ({ display: d[0], code: d[1], source: 'nlm' as const }))
            .filter(n => !localHits.some(l => l.code === n.code)); // dedupe

          const merged = [...localHits, ...nlmHits].slice(0, 10);
          setSnomedSuggestions(merged);
          setShowSnomedDropdown(merged.length > 0);
        } catch {
          // NLM unavailable — local results are already shown, nothing to do
        } finally {
          setSnomedLoading(false);
          setNlmPending(false);
        }
      }, 400);
    } else {
      setNlmPending(false);
    }
  }, [snomedQuery]);

  // Live re-search after first submit whenever any field changes
  useEffect(() => {
    if (!hasSearched) return;
    runSearch();
  }, [patientName, hospitalId, accessionNo, diagnosisText, selectedSnomed, statusFilter, priorityFilter]);

  // Core search logic
  const runSearch = () => {
    setIsSearching(true);
    setTimeout(() => {
      const q = {
        name:      patientName.trim().toLowerCase(),
        id:        hospitalId.trim().toLowerCase(),
        accession: accessionNo.trim().toLowerCase(),
        diagnosis: diagnosisText.trim().toLowerCase(),
        snomed:    selectedSnomed?.display.toLowerCase() ?? '',
        status:    statusFilter,
        priority:  priorityFilter,
      };
      const anyField = Object.values(q).some(v => v !== '');
      if (!anyField) { setResults(ALL_CASES); setIsSearching(false); return; }

      const filtered = ALL_CASES.filter(c => {
        if (q.name      && !c.patient.toLowerCase().includes(q.name))        return false;
        if (q.accession && !c.id.toLowerCase().includes(q.accession))        return false;
        if (q.diagnosis &&
            !c.protocol.toLowerCase().includes(q.diagnosis) &&
            !c.specimen.toLowerCase().includes(q.diagnosis))                  return false;
        if (q.snomed    && !c.protocol.toLowerCase().includes(q.snomed))     return false;
        if (q.status    && c.status !== q.status)                            return false;
        if (q.priority  && c.priority !== q.priority)                        return false;
        return true;
      });
      setResults(filtered);
      setIsSearching(false);
    }, 300);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearched(true);
    runSearch();
  };

  const handleClear = () => {
    setPatientName(''); setHospitalId(''); setAccessionNo('');
    setDiagnosisText(''); setSnomedQuery(''); setSelectedSnomed(null);
    setStatusFilter(''); setPriorityFilter(''); setDateFrom(''); setDateTo('');
    setResults(null); setHasSearched(false);
  };

  const quickLinks = {
    protocols:  [{ title: 'CAP Cancer Protocols', url: 'https://www.cap.org/protocols-and-guidelines' }, { title: 'WHO Classification', url: 'https://www.who.int/publications' }],
    references: [{ title: 'PathologyOutlines', url: 'https://www.pathologyoutlines.com' }, { title: 'UpToDate', url: 'https://www.uptodate.com' }],
    systems:    [{ title: 'Hospital LIS', url: '#' }, { title: 'Lab Management', url: '#' }],
  };

  const inputStyle: React.CSSProperties = {
    width: '100%', padding: '10px 14px',
    background: 'rgba(255,255,255,0.05)',
    border: '1px solid rgba(255,255,255,0.12)',
    borderRadius: '8px', color: '#fff', fontSize: '14px',
    outline: 'none', transition: 'border-color 0.2s', boxSizing: 'border-box',
  };
  const labelStyle: React.CSSProperties = {
    fontSize: '11px', fontWeight: 700, color: '#64748b',
    textTransform: 'uppercase', letterSpacing: '0.6px',
    marginBottom: '6px', display: 'block',
  };
  const onFocusBlue  = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => e.currentTarget.style.borderColor = '#0891B2';
  const onBlurGray   = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement>) => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)';

  return (
    <div style={{ position: 'relative', width: '100vw', height: '100vh', backgroundColor: '#000', color: '#fff', fontFamily: "'Inter', sans-serif", opacity: isLoaded ? 1 : 0, transition: 'opacity 0.6s ease', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

      {/* Background */}
      <div style={{ position: 'absolute', inset: 0, backgroundImage: 'url(/main_background.jpg)', backgroundSize: 'cover', backgroundPosition: 'center', zIndex: 0, filter: 'brightness(0.3) contrast(1.1)' }} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, rgba(0,0,0,0.4) 0%, #000 100%)', zIndex: 1 }} />

      {/* Content */}
      <div style={{ position: 'relative', zIndex: 10, display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>

        {/* Nav */}
        <nav style={{ padding: '20px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(12px)', borderBottom: '1px solid rgba(255,255,255,0.1)', flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
            <img src="/pathscribe-logo-dark.svg" alt="PathScribe AI" style={{ height: '60px', width: 'auto', cursor: 'pointer' }} onClick={() => navigate('/')} />
            <div style={{ width: '1px', height: '30px', background: 'rgba(255,255,255,0.2)' }} />
            <div style={{ fontSize: '14px', color: '#64748b', display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 500 }}>
              <span onClick={() => navigate('/')} style={{ cursor: 'pointer' }}
                onMouseEnter={(e) => e.currentTarget.style.color = '#0891B2'}
                onMouseLeave={(e) => e.currentTarget.style.color = '#64748b'}>Home</span>
              <span style={{ color: '#cbd5e1' }}>›</span>
              <span style={{ color: '#8B5CF6', fontWeight: 600 }}>Search</span>
            </div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', borderRight: '1px solid rgba(255,255,255,0.2)', paddingRight: '20px' }}>
              <span style={{ fontSize: '17px', fontWeight: 600 }}>{user?.name || 'Dr. Johnson'}</span>
              <span style={{ fontSize: '12px', color: '#0891B2', fontWeight: 700 }}>MD, FCAP</span>
            </div>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button onClick={() => setIsProfileOpen(!isProfileOpen)} title="Profile"
                style={{ width: '42px', height: '42px', borderRadius: '50%', backgroundColor: 'transparent', border: '2px solid #0891B2', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#0891B2', fontWeight: 800, cursor: 'pointer' }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(8,145,178,0.1)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; }}>
                {user?.name ? user.name.split(' ').map((n: any) => n[0]).join('') : 'DJ'}
              </button>
              <button onClick={() => setIsResourcesOpen(!isResourcesOpen)} title="Quick Links"
                style={{ width: '42px', height: '42px', borderRadius: '8px', background: 'transparent', border: '2px solid #0891B2', color: '#0891B2', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(8,145,178,0.1)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                  <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
                </svg>
              </button>
              <button onClick={() => setShowLogoutWarning(true)} title="Sign Out"
                style={{ width: '42px', height: '42px', borderRadius: '8px', background: 'transparent', border: '2px solid #0891B2', color: '#0891B2', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(8,145,178,0.1)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                  <polyline points="16 17 21 12 16 7"></polyline>
                  <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
              </button>
            </div>
          </div>
        </nav>

        {/* Case Search Bar */}
        <div style={{ padding: '14px 40px', background: 'rgba(0,0,0,0.3)', backdropFilter: 'blur(12px)', borderBottom: '1px solid rgba(255,255,255,0.08)', flexShrink: 0 }}>
          <CaseSearchBar />
        </div>

        {/* Scrollable main */}
        <main style={{ flex: 1, overflowY: 'auto', padding: '24px 40px 40px' }}>
          <div style={{ maxWidth: '1400px', margin: '0 auto' }}>

            <div style={{ marginBottom: '20px' }}>
              <h1 style={{ fontSize: '26px', fontWeight: 900, margin: 0, letterSpacing: '-0.5px' }}>Case Search</h1>
              <p style={{ fontSize: '13px', color: '#64748b', margin: '4px 0 0 0' }}>
                Search by patient, accession, diagnosis or SNOMED CT concept
              </p>
            </div>

            {/* ── Search Form ─────────────────────────────────────────────── */}
            <form onSubmit={handleSubmit}>
              <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '16px', padding: '24px', marginBottom: '20px' }}>

                {/* Row 1: Patient Name | Hospital ID | Accession */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                  <div>
                    <label style={labelStyle}>Patient Name</label>
                    <input type="text" placeholder="e.g. Miller, Jane" value={patientName}
                      onChange={(e) => setPatientName(e.target.value)} style={inputStyle}
                      onFocus={onFocusBlue} onBlur={onBlurGray} />
                  </div>
                  <div>
                    <label style={labelStyle}>Hospital / MRN ID</label>
                    <input type="text" placeholder="e.g. MRN-00123" value={hospitalId}
                      onChange={(e) => setHospitalId(e.target.value)} style={inputStyle}
                      onFocus={onFocusBlue} onBlur={onBlurGray} />
                  </div>
                  <div>
                    <label style={labelStyle}>Accession Number</label>
                    <input type="text" placeholder="e.g. S26-4401" value={accessionNo}
                      onChange={(e) => setAccessionNo(e.target.value)} style={inputStyle}
                      onFocus={onFocusBlue} onBlur={onBlurGray} />
                  </div>
                </div>

                {/* Row 2: Diagnosis | SNOMED CT hybrid */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                  <div>
                    <label style={labelStyle}>Diagnosis / Protocol (free text)</label>
                    <input type="text" placeholder="e.g. Breast Invasive Carcinoma" value={diagnosisText}
                      onChange={(e) => setDiagnosisText(e.target.value)} style={inputStyle}
                      onFocus={onFocusBlue} onBlur={onBlurGray} />
                  </div>

                  {/* ── SNOMED CT hybrid field ── */}
                  <div ref={snomedDropdownRef} style={{ position: 'relative' }}>
                    <label style={labelStyle}>
                      SNOMED CT Concept
                      {/* Source badge */}
                      {snomedLoading ? (
                        <span style={{ marginLeft: '8px', fontSize: '10px', color: '#F59E0B', fontWeight: 600, textTransform: 'none', letterSpacing: 0 }}>
                          ⟳ searching NLM…
                        </span>
                      ) : nlmPending ? (
                        <span style={{ marginLeft: '8px', fontSize: '10px', color: '#475569', fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>
                          local index
                        </span>
                      ) : (
                        <span style={{ marginLeft: '8px', fontSize: '10px', color: '#475569', fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}>
                          — curated + NLM
                        </span>
                      )}
                    </label>

                    {selectedSnomed ? (
                      /* Selected pill */
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 14px', background: 'rgba(8,145,178,0.12)', border: '1px solid rgba(8,145,178,0.4)', borderRadius: '8px' }}>
                        <span style={{ fontSize: '10px', fontWeight: 800, color: '#0891B2', whiteSpace: 'nowrap' }}>{selectedSnomed.code}</span>
                        <span style={{ width: '1px', height: '14px', background: 'rgba(8,145,178,0.3)', flexShrink: 0 }} />
                        <span style={{ fontSize: '13px', color: '#cbd5e1', flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{selectedSnomed.display}</span>
                        {selectedSnomed.source === 'nlm' && (
                          <span style={{ fontSize: '9px', background: 'rgba(245,158,11,0.15)', color: '#F59E0B', border: '1px solid rgba(245,158,11,0.3)', borderRadius: '4px', padding: '1px 5px', fontWeight: 700, whiteSpace: 'nowrap' }}>NLM</span>
                        )}
                        <button type="button" onClick={() => { setSelectedSnomed(null); setSnomedQuery(''); }}
                          style={{ background: 'none', border: 'none', color: '#64748b', cursor: 'pointer', fontSize: '16px', padding: '0 2px', lineHeight: 1, flexShrink: 0 }}>×</button>
                      </div>
                    ) : (
                      /* Input + dropdown */
                      <div style={{ position: 'relative' }}>
                        <input
                          type="text"
                          placeholder="Type 2+ chars — instant local, then NLM…"
                          value={snomedQuery}
                          onChange={(e) => setSnomedQuery(e.target.value)}
                          style={inputStyle}
                          onFocus={(e) => { e.currentTarget.style.borderColor = '#0891B2'; if (snomedSuggestions.length) setShowSnomedDropdown(true); }}
                          onBlur={(e) => e.currentTarget.style.borderColor = 'rgba(255,255,255,0.12)'}
                        />
                        {/* Spinner — only shown when NLM call is in flight */}
                        {snomedLoading && (
                          <div style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)' }}>
                            <div style={{ width: '14px', height: '14px', border: '2px solid rgba(245,158,11,0.2)', borderTopColor: '#F59E0B', borderRadius: '50%', animation: 'spin 0.7s linear infinite' }} />
                          </div>
                        )}

                        {/* Suggestions dropdown */}
                        {showSnomedDropdown && snomedSuggestions.length > 0 && (
                          <div style={{ position: 'absolute', top: 'calc(100% + 4px)', left: 0, right: 0, background: '#111827', border: '1px solid rgba(8,145,178,0.3)', borderRadius: '10px', zIndex: 999, overflow: 'hidden', boxShadow: '0 12px 32px rgba(0,0,0,0.7)' }}>

                            {/* Section header if we have a mix of local + NLM */}
                            {snomedSuggestions.some(s => s.source === 'local') && (
                              <div style={{ padding: '6px 14px', fontSize: '9px', fontWeight: 800, color: '#334155', textTransform: 'uppercase', letterSpacing: '0.8px', background: 'rgba(255,255,255,0.02)', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                                Pathology Index
                              </div>
                            )}

                            {snomedSuggestions.filter(s => s.source === 'local').map(s => (
                              <div key={s.code}
                                onClick={() => { setSelectedSnomed(s); setSnomedQuery(''); setShowSnomedDropdown(false); }}
                                style={{ padding: '9px 14px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '10px', borderBottom: '1px solid rgba(255,255,255,0.03)', transition: 'background 0.12s' }}
                                onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(8,145,178,0.1)'}
                                onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                                <span style={{ fontSize: '10px', fontWeight: 800, color: '#0891B2', whiteSpace: 'nowrap', minWidth: '74px' }}>{s.code}</span>
                                <span style={{ fontSize: '13px', color: '#cbd5e1' }}>{s.display}</span>
                              </div>
                            ))}

                            {/* NLM results section — only shown when present */}
                            {snomedSuggestions.some(s => s.source === 'nlm') && (
                              <>
                                <div style={{ padding: '6px 14px', fontSize: '9px', fontWeight: 800, color: '#334155', textTransform: 'uppercase', letterSpacing: '0.8px', background: 'rgba(255,255,255,0.02)', borderBottom: '1px solid rgba(255,255,255,0.04)', display: 'flex', alignItems: 'center', gap: '6px' }}>
                                  NLM SNOMED CT
                                  <span style={{ fontSize: '8px', background: 'rgba(245,158,11,0.15)', color: '#F59E0B', border: '1px solid rgba(245,158,11,0.25)', borderRadius: '3px', padding: '1px 4px' }}>live</span>
                                </div>
                                {snomedSuggestions.filter(s => s.source === 'nlm').map(s => (
                                  <div key={s.code}
                                    onClick={() => { setSelectedSnomed(s); setSnomedQuery(''); setShowSnomedDropdown(false); }}
                                    style={{ padding: '9px 14px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '10px', borderBottom: '1px solid rgba(255,255,255,0.03)', transition: 'background 0.12s' }}
                                    onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(245,158,11,0.07)'}
                                    onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
                                    <span style={{ fontSize: '10px', fontWeight: 800, color: '#F59E0B', whiteSpace: 'nowrap', minWidth: '74px' }}>{s.code}</span>
                                    <span style={{ fontSize: '13px', color: '#cbd5e1' }}>{s.display}</span>
                                  </div>
                                ))}
                              </>
                            )}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Row 3: Status | Priority | Date From | Date To */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: '16px', marginBottom: '20px' }}>
                  <div>
                    <label style={labelStyle}>Status</label>
                    <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}
                      style={{ ...inputStyle, cursor: 'pointer', appearance: 'none' as any }}
                      onFocus={onFocusBlue} onBlur={onBlurGray}>
                      <option value="">All Statuses</option>
                      <option value="Grossed">Grossed</option>
                      <option value="Awaiting Micro">Awaiting Micro</option>
                      <option value="Finalizing">Finalizing</option>
                      <option value="Completed">Completed</option>
                    </select>
                  </div>
                  <div>
                    <label style={labelStyle}>Priority</label>
                    <select value={priorityFilter} onChange={(e) => setPriorityFilter(e.target.value)}
                      style={{ ...inputStyle, cursor: 'pointer', appearance: 'none' as any }}
                      onFocus={onFocusBlue} onBlur={onBlurGray}>
                      <option value="">All Priorities</option>
                      <option value="Routine">Routine</option>
                      <option value="STAT">STAT</option>
                    </select>
                  </div>
                  <div>
                    <label style={labelStyle}>Date From</label>
                    <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)}
                      style={{ ...inputStyle, colorScheme: 'dark' }}
                      onFocus={onFocusBlue} onBlur={onBlurGray} />
                  </div>
                  <div>
                    <label style={labelStyle}>Date To</label>
                    <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)}
                      style={{ ...inputStyle, colorScheme: 'dark' }}
                      onFocus={onFocusBlue} onBlur={onBlurGray} />
                  </div>
                </div>

                {/* Actions */}
                <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
                  <button type="button" onClick={handleClear}
                    style={{ padding: '10px 24px', borderRadius: '8px', background: 'transparent', border: '1px solid rgba(255,255,255,0.15)', color: '#94a3b8', fontWeight: 600, fontSize: '14px', cursor: 'pointer', transition: 'all 0.2s' }}
                    onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; e.currentTarget.style.color = '#fff'; }}
                    onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#94a3b8'; }}>
                    Clear
                  </button>
                  <button type="submit"
                    style={{ padding: '10px 32px', borderRadius: '8px', background: '#8B5CF6', border: 'none', color: '#fff', fontWeight: 700, fontSize: '14px', cursor: 'pointer', transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: '8px' }}
                    onMouseEnter={(e) => e.currentTarget.style.background = '#7C3AED'}
                    onMouseLeave={(e) => e.currentTarget.style.background = '#8B5CF6'}>
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                      <circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                    Search Cases
                  </button>
                </div>
              </div>
            </form>

            {/* ── Results ─────────────────────────────────────────────────── */}
            {isSearching && (
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', padding: '40px', color: '#64748b' }}>
                <div style={{ width: '18px', height: '18px', border: '2px solid rgba(139,92,246,0.2)', borderTopColor: '#8B5CF6', borderRadius: '50%', animation: 'spin 0.7s linear infinite' }} />
                Searching…
              </div>
            )}

            {!isSearching && hasSearched && results !== null && (
              <div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <span style={{ fontSize: '13px', color: '#64748b', fontWeight: 600 }}>Results</span>
                    <span style={{ fontSize: '15px', fontWeight: 800, color: results.length > 0 ? '#8B5CF6' : '#EF4444' }}>{results.length}</span>
                    <span style={{ fontSize: '13px', color: '#475569' }}>case{results.length !== 1 ? 's' : ''} found</span>
                    {selectedSnomed && (
                      <span style={{ fontSize: '11px', background: selectedSnomed.source === 'nlm' ? 'rgba(245,158,11,0.12)' : 'rgba(8,145,178,0.12)', border: `1px solid ${selectedSnomed.source === 'nlm' ? 'rgba(245,158,11,0.3)' : 'rgba(8,145,178,0.3)'}`, color: selectedSnomed.source === 'nlm' ? '#F59E0B' : '#0891B2', padding: '2px 10px', borderRadius: '20px', fontWeight: 700 }}>
                        SNOMED {selectedSnomed.code}
                      </span>
                    )}
                  </div>
                  {results.length > 0 && (
                    <span style={{ fontSize: '12px', color: '#475569' }}>Click Open to view Synoptic Report</span>
                  )}
                </div>

                {results.length === 0 ? (
                  <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: '16px', padding: '60px', textAlign: 'center' }}>
                    <div style={{ fontSize: '40px', marginBottom: '12px' }}>🔍</div>
                    <div style={{ fontSize: '16px', fontWeight: 600, color: '#64748b' }}>No cases match your search</div>
                    <div style={{ fontSize: '13px', color: '#475569', marginTop: '6px' }}>Try broadening your criteria or clearing some filters</div>
                  </div>
                ) : (
                  <div style={{ height: '420px', display: 'flex', flexDirection: 'column' }}>
                    <WorklistTable cases={results} activeFilter="all" />
                  </div>
                )}
              </div>
            )}

            {!hasSearched && (
              <div style={{ textAlign: 'center', padding: '60px 0', color: '#334155' }}>
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" style={{ marginBottom: '16px', opacity: 0.3 }}>
                  <circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
                <div style={{ fontSize: '15px', fontWeight: 600 }}>Enter criteria above and click Search Cases</div>
                <div style={{ fontSize: '13px', marginTop: '6px' }}>Results update live as you refine after the first search</div>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* LOGOUT WARNING MODAL */}
      {showLogoutWarning && (
        <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10000 }}>
          <div style={{ width: '400px', backgroundColor: '#111', padding: '40px', borderRadius: '28px', textAlign: 'center', border: '1px solid rgba(255,255,255,0.1)', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)' }}>
            <div style={{ marginBottom: '20px', display: 'flex', justifyContent: 'center' }}><WarningIcon color="#F59E0B" /></div>
            <h2 style={{ fontSize: '24px', fontWeight: 800, color: '#fff', margin: '0 0 12px 0' }}>Sign Out?</h2>
            <p style={{ color: '#94a3b8', marginBottom: '30px', lineHeight: '1.6', fontSize: '15px' }}>You will be returned to the login screen.</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <button onClick={() => setShowLogoutWarning(false)} autoFocus
                style={{ padding: '16px 24px', borderRadius: '12px', background: '#0891B2', border: 'none', color: '#fff', fontWeight: 700, fontSize: '16px', cursor: 'pointer', width: '100%' }}
                onMouseEnter={(e) => e.currentTarget.style.background = '#0E7490'}
                onMouseLeave={(e) => e.currentTarget.style.background = '#0891B2'}>
                ← Return to Page
              </button>
              <button onClick={handleLogout}
                style={{ padding: '16px 24px', borderRadius: '12px', background: 'transparent', border: '2px solid #F59E0B', color: '#F59E0B', fontWeight: 600, fontSize: '15px', cursor: 'pointer', width: '100%' }}
                onMouseEnter={(e) => { e.currentTarget.style.background = '#F59E0B'; e.currentTarget.style.color = '#000'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#F59E0B'; }}>
                Log Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PROFILE MODAL */}
      {isProfileOpen && (
        <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10000 }}
          onClick={() => setIsProfileOpen(false)}>
          <div style={{ width: '400px', backgroundColor: '#111', borderRadius: '20px', padding: '40px', border: '1px solid rgba(8,145,178,0.3)', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)', textAlign: 'center' }}
            onClick={(e) => e.stopPropagation()}>
            <div style={{ color: '#0891B2', fontSize: '24px', fontWeight: 700, marginBottom: '24px' }}>User Preferences</div>
            <div style={{ marginBottom: '24px', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '12px' }}>
              {[{ icon: <SunIcon />, label: 'Light' }, { icon: <MoonIcon />, label: 'Dark' }, { icon: <MonitorIcon />, label: 'Auto' }].map(({ icon, label }) => (
                <button key={label} style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px', color: '#fff', padding: '16px', cursor: 'not-allowed', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px', opacity: 0.5 }} title="Coming soon">
                  {icon}<span style={{ fontSize: '12px', fontWeight: 600 }}>{label}</span>
                </button>
              ))}
            </div>
            <div style={{ marginBottom: '24px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <button onClick={() => { window.open('https://www.cap.org/', '_blank'); setIsProfileOpen(false); }}
                style={{ padding: '12px 16px', borderRadius: '10px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: '#cbd5e1', fontWeight: 600, fontSize: '15px', cursor: 'pointer', width: '100%', textAlign: 'left', display: 'flex', alignItems: 'center', gap: '10px' }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(8,145,178,0.1)'; e.currentTarget.style.color = '#0891B2'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; e.currentTarget.style.color = '#cbd5e1'; }}>
                <HelpIcon /> Support & Protocols
              </button>
              <button onClick={() => { setShowAbout(true); setIsProfileOpen(false); }}
                style={{ padding: '12px 16px', borderRadius: '10px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: '#cbd5e1', fontWeight: 600, fontSize: '15px', cursor: 'pointer', width: '100%', textAlign: 'left', display: 'flex', alignItems: 'center', gap: '10px' }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(8,145,178,0.1)'; e.currentTarget.style.color = '#0891B2'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; e.currentTarget.style.color = '#cbd5e1'; }}>
                <HelpIcon /> About PathScribe<span style={{ color: '#0891B2', fontSize: '0.6em', verticalAlign: 'super', marginLeft: '0.2em' }}>AI</span>
              </button>
            </div>
            <button onClick={() => setIsProfileOpen(false)} autoFocus
              style={{ padding: '12px 24px', borderRadius: '10px', background: 'rgba(8,145,178,0.15)', border: '1px solid rgba(8,145,178,0.3)', color: '#0891B2', fontWeight: 600, fontSize: '15px', cursor: 'pointer', width: '100%' }}
              onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(8,145,178,0.25)'; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = 'rgba(8,145,178,0.15)'; }}>
              Close
            </button>
          </div>
        </div>
      )}

      {/* ABOUT MODAL */}
      {showAbout && (
        <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(12px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10000 }}
          onClick={() => setShowAbout(false)}>
          <div style={{ width: '400px', backgroundColor: 'rgba(220,220,220,0.75)', backdropFilter: 'blur(40px)', padding: '40px', borderRadius: '20px', textAlign: 'center', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)', border: '1px solid rgba(255,255,255,0.3)' }}
            onClick={(e) => e.stopPropagation()}>
            <h2 style={{ fontSize: '32px', fontWeight: 700, color: '#1a1a1a', margin: '0 0 16px 0' }}>
              PathScribe<span style={{ color: '#0891B2', fontSize: '0.6em', verticalAlign: 'super', marginLeft: '0.1em' }}>AI</span>
            </h2>
            <p style={{ color: '#3a3a3a', marginBottom: '8px', fontSize: '15px' }}>Version 1.0.0 | Build: 2026-02-14</p>
            <p style={{ color: '#3a3a3a', marginBottom: '20px', fontSize: '15px' }}>Developed by the PathScribe AI Team</p>
            <p style={{ color: '#5a5a5a', marginBottom: '30px', fontSize: '14px' }}>© 2026 PathScribe</p>
            <button onClick={() => setShowAbout(false)} autoFocus
              style={{ padding: '12px 32px', borderRadius: '8px', background: 'rgba(160,160,160,0.5)', border: 'none', color: '#1a1a1a', fontWeight: 600, fontSize: '15px', cursor: 'pointer', width: '100%' }}
              onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(140,140,140,0.6)'}
              onMouseLeave={(e) => e.currentTarget.style.background = 'rgba(160,160,160,0.5)'}>
              Close
            </button>
          </div>
        </div>
      )}

      {/* QUICK LINKS MODAL */}
      {isResourcesOpen && (
        <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10000 }}
          onClick={() => setIsResourcesOpen(false)}>
          <div style={{ width: '500px', maxHeight: '80vh', overflowY: 'auto', backgroundColor: '#111', borderRadius: '20px', padding: '40px', border: '1px solid rgba(8,145,178,0.3)', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)' }}
            onClick={(e) => e.stopPropagation()}>
            <div style={{ color: '#0891B2', fontSize: '24px', fontWeight: 700, marginBottom: '24px', textAlign: 'center' }}>Quick Links</div>
            {Object.entries(quickLinks).map(([section, links]) => (
              <div key={section} style={{ marginBottom: '24px' }}>
                <div style={{ color: '#94a3b8', fontSize: '12px', fontWeight: 700, marginBottom: '12px', textTransform: 'uppercase' }}>
                  {section.charAt(0).toUpperCase() + section.slice(1)}
                </div>
                {links.map((link, i) => (
                  <a key={i} href={link.url} target="_blank" rel="noopener noreferrer" onClick={() => setIsResourcesOpen(false)}
                    style={{ display: 'block', color: '#cbd5e1', textDecoration: 'none', padding: '12px 16px', fontSize: '16px', borderRadius: '8px', marginBottom: '8px' }}
                    onMouseEnter={(e) => { e.currentTarget.style.color = '#0891B2'; e.currentTarget.style.backgroundColor = 'rgba(8,145,178,0.1)'; }}
                    onMouseLeave={(e) => { e.currentTarget.style.color = '#cbd5e1'; e.currentTarget.style.backgroundColor = 'transparent'; }}>
                    → {link.title}
                  </a>
                ))}
              </div>
            ))}
            <button onClick={() => setIsResourcesOpen(false)} autoFocus
              style={{ padding: '12px 24px', borderRadius: '10px', background: 'rgba(8,145,178,0.15)', border: '1px solid rgba(8,145,178,0.3)', color: '#0891B2', fontWeight: 600, fontSize: '15px', cursor: 'pointer', width: '100%' }}
              onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(8,145,178,0.25)'; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = 'rgba(8,145,178,0.15)'; }}>
              Close
            </button>
          </div>
        </div>
      )}

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
};

export default SearchPage;
