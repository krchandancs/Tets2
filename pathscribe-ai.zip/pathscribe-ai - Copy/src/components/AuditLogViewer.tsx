import React, { useEffect, useState } from "react";
import { getAuditLog, clearAuditLog, logEvent } from "../audit/auditLogger";
import { AuditEvent } from "../types/AuditEvent";

export const AuditLogViewer: React.FC = () => {
  const [events, setEvents] = useState<AuditEvent[]>([]);

  const load = () => {
    setEvents(getAuditLog().sort((a, b) => b.timestamp.localeCompare(a.timestamp)));
  };

  useEffect(() => {
    load();
  }, []);

  const handleClear = () => {
    logEvent({
      user: "System",
      category: "system",
      action: "clear_audit_log",
      templateId: "system"
    });
    clearAuditLog();
    load();
  };

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <h1 style={{ marginBottom: 16 }}>Audit Log</h1>

      <button
        onClick={handleClear}
        style={{
          padding: "6px 12px",
          borderRadius: 4,
          border: "1px solid #c00",
          background: "#fff",
          color: "#c00",
          cursor: "pointer",
          marginBottom: 20
        }}
      >
        Clear Audit Log
      </button>

      <div
        style={{
          border: "1px solid #ddd",
          borderRadius: 6,
          overflow: "hidden"
        }}
      >
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead style={{ background: "#f5f5f5" }}>
            <tr>
              <th style={th}>Timestamp</th>
              <th style={th}>User</th>
              <th style={th}>Action</th>
              <th style={th}>Details</th>
            </tr>
          </thead>
          <tbody>
            {events.map(ev => (
              <tr key={ev.id} style={{ borderBottom: "1px solid #eee" }}>
                <td style={td}>{new Date(ev.timestamp).toLocaleString()}</td>
                <td style={td}>{ev.user}</td>
                <td style={td}>{ev.action}</td>
                <td style={{ ...td, fontSize: 12 }}>
                  {ev.questionId && (
                    <div><strong>Question:</strong> {ev.questionId}</div>
                  )}
                  {ev.stateFrom && ev.stateTo && (
                    <div>
                      <strong>State:</strong> {ev.stateFrom} → {ev.stateTo}
                    </div>
                  )}
                  {ev.oldValue !== undefined && (
                    <div><strong>Old:</strong> {JSON.stringify(ev.oldValue)}</div>
                  )}
                  {ev.newValue !== undefined && (
                    <div><strong>New:</strong> {JSON.stringify(ev.newValue)}</div>
                  )}
                  {ev.note && (
                    <div><strong>Note:</strong> {ev.note}</div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const th: React.CSSProperties = {
  textAlign: "left",
  padding: "8px 12px",
  borderBottom: "1px solid #ddd",
  fontWeight: 600
};

const td: React.CSSProperties = {
  padding: "8px 12px",
  verticalAlign: "top"
};