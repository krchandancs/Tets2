import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import { mockDcisTemplate } from "../templates/mockDcisTemplate";
import { InlineCommentThread } from "./InlineCommentThread";

import {
  TemplateLifecycleState
} from "../types/AuditEvent";

import {
  Question,
  ChoiceQuestion,
  TemplateSection
} from "../types/templateTypes";

import { logEvent } from "../audit/auditLogger";

const isChoiceQuestion = (q: Question): q is ChoiceQuestion =>
  q.type === "choice";

type AnswerMap = Record<string, string | string[]>;

const DEFAULT_USER = "Dr. Reviewer";

export const TemplateRenderer: React.FC = () => {
  const navigate = useNavigate();
  const { templateId } = useParams();

  // Load the correct template (later you may load dynamically)
  const template = mockDcisTemplate;

  const ANSWERS_KEY = `ps_answers_${template.id}`;
  const STATE_KEY = `ps_state_${template.id}`;

  const [answers, setAnswers] = useState<AnswerMap>({});
  const [state, setState] = useState<TemplateLifecycleState>("draft");

  // Load persisted answers + state
  useEffect(() => {
    try {
      const rawAnswers = localStorage.getItem(ANSWERS_KEY);
      if (rawAnswers) setAnswers(JSON.parse(rawAnswers));
    } catch {}

    try {
      const rawState = localStorage.getItem(STATE_KEY);
      if (rawState) setState(rawState as TemplateLifecycleState);
    } catch {}
  }, []);

  const persistAnswers = (next: AnswerMap) => {
    setAnswers(next);
    localStorage.setItem(ANSWERS_KEY, JSON.stringify(next));
  };

  const persistState = (next: TemplateLifecycleState) => {
    setState(next);
    localStorage.setItem(STATE_KEY, next);
  };

  // -----------------------------
  // Answer Handlers
  // -----------------------------

  const handleSingleChange = (questionId: string, optionId: string) => {
    const prevValue = answers[questionId];
    const next = { ...answers, [questionId]: optionId };
    persistAnswers(next);

    logEvent({
      user: DEFAULT_USER,
      category: "user",
      action: "set_single_answer",
      templateId: template.id,
      questionId,
      oldValue: prevValue,
      newValue: optionId
    });
  };

  const handleMultiChange = (questionId: string, optionId: string) => {
    const current = (answers[questionId] as string[]) || [];
    const exists = current.includes(optionId);
    const nextArray = exists
      ? current.filter(id => id !== optionId)
      : [...current, optionId];

    const prevValue = answers[questionId];
    const next = { ...answers, [questionId]: nextArray };
    persistAnswers(next);

    logEvent({
      user: DEFAULT_USER,
      category: "user",
      action: exists ? "remove_multi_answer" : "add_multi_answer",
      templateId: template.id,
      questionId,
      oldValue: prevValue,
      newValue: nextArray
    });
  };

  const handleTextChange = (questionId: string, value: string) => {
    const prevValue = answers[questionId];
    const next = { ...answers, [questionId]: value };
    persistAnswers(next);

    logEvent({
      user: DEFAULT_USER,
      category: "user",
      action: "set_text_answer",
      templateId: template.id,
      questionId,
      oldValue: prevValue,
      newValue: value
    });
  };

  // -----------------------------
  // Lifecycle Transitions
  // -----------------------------

  const transitionState = (next: TemplateLifecycleState, note?: string) => {
    const prev = state;
    if (prev === next) return;

    persistState(next);

    logEvent({
      user: DEFAULT_USER,
      category: "user",
      action: "state_transition",
      templateId: template.id,
      stateFrom: prev,
      stateTo: next,
      note
    });
  };

  const handleMarkInReview = () => transitionState("in_review");
  const handleMarkNeedsChanges = () => transitionState("needs_changes");
  const handleMarkApproved = () => transitionState("approved");
  const handleMarkPublished = () => transitionState("published");

  const handleReset = () => {
    persistAnswers({});
    persistState("draft");

    logEvent({
      user: "System",
      category: "system",
      action: "reset_template",
      templateId: template.id
    });
  };

  // -----------------------------
  // Render
  // -----------------------------

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: "0 auto" }}>
      <button
        onClick={() => navigate("/template-review")}
        style={{
          marginBottom: 20,
          padding: "6px 12px",
          cursor: "pointer",
          background: "#eee",
          border: "1px solid #ccc",
          borderRadius: 4
        }}
      >
        Back
      </button>

      {/* Lifecycle State Panel */}
      <div
        style={{
          marginBottom: 16,
          padding: 12,
          borderRadius: 6,
          border: "1px solid #ddd",
          background: "#fafafa"
        }}
      >
        <div style={{ marginBottom: 8 }}>
          <strong>Lifecycle State:</strong>{" "}
          {state.replace("_", " ")}
        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <button
            onClick={handleMarkInReview}
            style={{
              padding: "4px 8px",
              fontSize: 12,
              borderRadius: 4,
              border: "1px solid #ccc",
              background: state === "in_review" ? "#e6f0ff" : "#fff"
            }}
          >
            Mark In Review
          </button>

          <button
            onClick={handleMarkNeedsChanges}
            style={{
              padding: "4px 8px",
              fontSize: 12,
              borderRadius: 4,
              border: "1px solid #ccc",
              background: state === "needs_changes" ? "#fff4e6" : "#fff"
            }}
          >
            Needs Changes
          </button>

          <button
            onClick={handleMarkApproved}
            style={{
              padding: "4px 8px",
              fontSize: 12,
              borderRadius: 4,
              border: "1px solid #ccc",
              background: state === "approved" ? "#e6f7e6" : "#fff"
            }}
          >
            Approve
          </button>

          <button
            onClick={handleMarkPublished}
            style={{
              padding: "4px 8px",
              fontSize: 12,
              borderRadius: 4,
              border: "1px solid #ccc",
              background: state === "published" ? "#e6f7ff" : "#fff"
            }}
          >
            Publish
          </button>

          <button
            onClick={handleReset}
            style={{
              padding: "4px 8px",
              fontSize: 12,
              borderRadius: 4,
              border: "1px solid #f0b3b3",
              background: "#fff",
              color: "#b30000"
            }}
          >
            Reset
          </button>
        </div>
      </div>

      {/* Template Sections */}
      {template.sections.map((section: TemplateSection) => (
        <div
          key={section.id}
          style={{
            marginTop: 32,
            paddingBottom: 16,
            borderBottom: "1px solid #ddd"
          }}
        >
          <h2 style={{ marginBottom: 16 }}>{section.title}</h2>

          {section.questions.map((q: Question) => (
            <div key={q.id} style={{ marginBottom: 28 }}>
              <div style={{ fontWeight: 600, marginBottom: 6 }}>{q.text}</div>

              <InlineCommentThread
                questionId={q.id}
                currentUser={DEFAULT_USER}
              />

              {/* Single-select */}
              {isChoiceQuestion(q) && !q.multiple && (
                <div style={{ marginTop: 8 }}>
                  {q.options.map(opt => (
                    <label
                      key={opt.id}
                      style={{ display: "block", marginBottom: 4 }}
                    >
                      <input
                        type="radio"
                        name={q.id}
                        value={opt.id}
                        checked={answers[q.id] === opt.id}
                        onChange={() => handleSingleChange(q.id, opt.id)}
                      />
                      {" "}{opt.label}
                    </label>
                  ))}
                </div>
              )}

              {/* Multi-select */}
              {isChoiceQuestion(q) && q.multiple && (
                <div style={{ marginTop: 8 }}>
                  {q.options.map(opt => {
                    const current = (answers[q.id] as string[]) || [];
                    return (
                      <label
                        key={opt.id}
                        style={{ display: "block", marginBottom: 4 }}
                      >
                        <input
                          type="checkbox"
                          value={opt.id}
                          checked={current.includes(opt.id)}
                          onChange={() => handleMultiChange(q.id, opt.id)}
                        />
                        {" "}{opt.label}
                      </label>
                    );
                  })}
                </div>
              )}

              {/* Text input */}
              {q.type === "text" && (
                <input
                  type="text"
                  value={(answers[q.id] as string) || ""}
                  onChange={e => handleTextChange(q.id, e.target.value)}
                  style={{
                    marginTop: 8,
                    padding: 6,
                    width: "100%",
                    maxWidth: 300,
                    border: "1px solid #ccc",
                    borderRadius: 4
                  }}
                />
              )}
            </div>
          ))}
        </div>
      ))}

      {/* Debug: Current Answers */}
      <h3 style={{ marginTop: 40 }}>Current Answers</h3>
      <pre
        style={{
          background: "#f5f5f5",
          padding: 16,
          borderRadius: 6,
          border: "1px solid #ddd",
          overflowX: "auto"
        }}
      >
        {JSON.stringify(answers, null, 2)}
      </pre>
    </div>
  );
};

export default TemplateRenderer;