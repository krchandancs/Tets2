import React, { useState } from 'react';
import PathScribeEditor, { Macro } from './PathScribeEditor';

interface MacroPanelProps {
  approvedFonts: string[];
}

const MacroPanel: React.FC<MacroPanelProps> = ({ approvedFonts }) => {
  const [macros, setMacros] = useState<Macro[]>([
    {
      id: '1',
      trigger: ';gs',
      name: 'Gross Standard',
      content: '<p><strong>GROSS DESCRIPTION:</strong></p><p>The specimen is received fresh/in formalin, labeled with the patient\'s name and designated as ___. It consists of ___.</p>',
    },
    {
      id: '2',
      trigger: ';ms',
      name: 'Micro Standard',
      content: '<p><strong>MICROSCOPIC DESCRIPTION:</strong></p><p>Sections show ___. There is/are ___. The margins are ___.</p>',
    },
    {
      id: '3',
      trigger: ';dx',
      name: 'Diagnosis Block',
      content: '<p><strong>DIAGNOSIS:</strong></p><p>1. ___ (Site):<br/>- ___<br/>- ___</p>',
    },
  ]);

  const [selectedMacroId, setSelectedMacroId] = useState<string | null>(null);
  const [trigger, setTrigger] = useState('');
  const [macroName, setMacroName] = useState('');
  const [editorContent, setEditorContent] = useState('');
  const [isCreatingNew, setIsCreatingNew] = useState(false);

  const selectedMacro = macros.find(m => m.id === selectedMacroId) ?? null;

  const handleSelectMacro = (id: string) => {
    const macro = macros.find(m => m.id === id);
    if (!macro) return;
    setSelectedMacroId(id);
    setTrigger(macro.trigger);
    setMacroName(macro.name);
    setEditorContent(macro.content);
    setIsCreatingNew(false);
  };

  const handleCreateNew = () => {
    setIsCreatingNew(true);
    setSelectedMacroId(null);
    setTrigger('');
    setMacroName('');
    setEditorContent('');
  };

  const handleSave = () => {
    if (!trigger.trim() || !macroName.trim()) {
      alert('Please enter both a trigger shortcut and a macro name.');
      return;
    }
    if (!trigger.startsWith(';')) {
      alert('Trigger must start with ";" (e.g. ;gs)');
      return;
    }

    if (selectedMacroId) {
      setMacros(prev =>
        prev.map(m =>
          m.id === selectedMacroId
            ? { ...m, trigger: trigger.trim(), name: macroName.trim(), content: editorContent }
            : m
        )
      );
    } else {
      const newMacro: Macro = {
        id: Date.now().toString(),
        trigger: trigger.trim(),
        name: macroName.trim(),
        content: editorContent,
      };
      setMacros(prev => [...prev, newMacro]);
      setSelectedMacroId(newMacro.id);
      setIsCreatingNew(false);
    }
  };

  const handleDelete = () => {
    if (!selectedMacroId) return;
    if (!confirm(`Delete macro "${selectedMacro?.name}"?`)) return;
    setMacros(prev => prev.filter(m => m.id !== selectedMacroId));
    setSelectedMacroId(null);
    setTrigger('');
    setMacroName('');
    setEditorContent('');
    setIsCreatingNew(false);
  };

  const isDirty = selectedMacro
    ? trigger !== selectedMacro.trigger || macroName !== selectedMacro.name || editorContent !== selectedMacro.content
    : isCreatingNew;

  return (
    <div style={{ display: 'flex', gap: '24px', height: 'calc(100vh - 280px)', minHeight: '560px' }}>
      {/* ── Sidebar ─────────────────────────────────────────────────────── */}
      <div style={{
        width: '260px',
        flexShrink: 0,
        background: 'rgba(255,255,255,0.05)',
        borderRadius: '12px',
        border: '1px solid rgba(255,255,255,0.1)',
        padding: '18px',
        display: 'flex',
        flexDirection: 'column',
        gap: '10px',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
          <h3 style={{ fontSize: '15px', fontWeight: 700, color: '#fff', margin: 0 }}>My Macros</h3>
          <button
            onClick={handleCreateNew}
            style={{ padding: '5px 12px', background: '#0891B2', border: 'none', borderRadius: '6px', color: '#fff', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}
            onMouseEnter={e => e.currentTarget.style.background = '#0E7490'}
            onMouseLeave={e => e.currentTarget.style.background = '#0891B2'}
          >
            + New
          </button>
        </div>

        <div style={{ fontSize: '11px', color: '#475569', padding: '8px 10px', background: 'rgba(8,145,178,0.08)', borderRadius: '6px', lineHeight: '1.5' }}>
          💡 Type a trigger shortcut while editing and press Space to auto-expand.
        </div>

        <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '6px' }}>
          {macros.map(macro => (
            <button
              key={macro.id}
              onClick={() => handleSelectMacro(macro.id)}
              style={{
                padding: '11px 12px',
                background: selectedMacroId === macro.id ? 'rgba(8,145,178,0.15)' : 'rgba(255,255,255,0.03)',
                border: `1px solid ${selectedMacroId === macro.id ? '#0891B2' : 'rgba(255,255,255,0.08)'}`,
                borderRadius: '8px',
                color: selectedMacroId === macro.id ? '#38bdf8' : '#cbd5e1',
                textAlign: 'left',
                cursor: 'pointer',
                transition: 'all 0.15s',
                display: 'flex',
                flexDirection: 'column',
                gap: '3px',
              }}
            >
              <div style={{ fontSize: '13px', fontWeight: 600 }}>{macro.name}</div>
              <div style={{ fontSize: '11px', color: '#64748b', fontFamily: 'monospace' }}>{macro.trigger}</div>
            </button>
          ))}

          {macros.length === 0 && (
            <div style={{ textAlign: 'center', color: '#475569', fontSize: '13px', padding: '24px 0' }}>
              No macros yet.<br />Click + New to create one.
            </div>
          )}
        </div>
      </div>

      {/* ── Right Panel ──────────────────────────────────────────────────── */}
      <div style={{
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        gap: '14px',
        minWidth: 0,
      }}>
        {selectedMacroId || isCreatingNew ? (
          <>
            {/* Header row */}
            <div style={{ display: 'flex', gap: '14px', alignItems: 'flex-end' }}>
              <div style={{ flex: 1 }}>
                <label style={{ display: 'block', color: '#94a3b8', marginBottom: '5px', fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  Macro Name
                </label>
                <input
                  value={macroName}
                  onChange={e => setMacroName(e.target.value)}
                  placeholder="e.g., Gross Standard"
                  style={{
                    width: '100%',
                    padding: '9px 12px',
                    borderRadius: '8px',
                    border: '1px solid rgba(255,255,255,0.15)',
                    background: 'rgba(0,0,0,0.3)',
                    color: '#fff',
                    fontSize: '14px',
                    outline: 'none',
                    boxSizing: 'border-box',
                  }}
                />
              </div>
              <div style={{ width: '180px' }}>
                <label style={{ display: 'block', color: '#94a3b8', marginBottom: '5px', fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                  Trigger Shortcut
                </label>
                <input
                  value={trigger}
                  onChange={e => setTrigger(e.target.value)}
                  placeholder=";gs"
                  style={{
                    width: '100%',
                    padding: '9px 12px',
                    borderRadius: '8px',
                    border: '1px solid rgba(255,255,255,0.15)',
                    background: 'rgba(0,0,0,0.3)',
                    color: '#38bdf8',
                    fontSize: '14px',
                    fontFamily: 'monospace',
                    fontWeight: 700,
                    outline: 'none',
                    boxSizing: 'border-box',
                  }}
                />
              </div>
            </div>

            {/* Editor */}
            <div style={{ flex: 1, overflow: 'hidden', borderRadius: '12px' }}>
              <PathScribeEditor
                key={selectedMacroId ?? 'new'}
                content={editorContent}
                onChange={setEditorContent}
                approvedFonts={approvedFonts}
                macros={macros}
                minHeight="350px"
                placeholder="Write your macro template here..."
                showRulerDefault={false}
              />
            </div>

            {/* Action buttons */}
            <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', flexShrink: 0 }}>
              {selectedMacroId && (
                <button
                  onClick={handleDelete}
                  style={{
                    padding: '9px 20px',
                    background: 'transparent',
                    border: '1px solid rgba(239,68,68,0.5)',
                    borderRadius: '8px',
                    color: '#EF4444',
                    fontSize: '13px',
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                  onMouseEnter={e => { e.currentTarget.style.background = 'rgba(239,68,68,0.1)'; e.currentTarget.style.borderColor = '#EF4444'; }}
                  onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.borderColor = 'rgba(239,68,68,0.5)'; }}
                >
                  Delete
                </button>
              )}
              <button
                onClick={handleSave}
                disabled={!isDirty}
                style={{
                  padding: '9px 24px',
                  background: isDirty ? '#0891B2' : '#334155',
                  border: 'none',
                  borderRadius: '8px',
                  color: isDirty ? '#fff' : '#64748b',
                  fontSize: '13px',
                  fontWeight: 600,
                  cursor: isDirty ? 'pointer' : 'not-allowed',
                  transition: 'background 0.2s',
                }}
                onMouseEnter={e => { if (isDirty) e.currentTarget.style.background = '#0E7490'; }}
                onMouseLeave={e => { if (isDirty) e.currentTarget.style.background = '#0891B2'; }}
              >
                {selectedMacroId ? 'Save Changes' : 'Create Macro'}
              </button>
            </div>
          </>
        ) : (
          /* Empty state */
          <div style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#64748b',
            gap: '16px',
            background: 'rgba(255,255,255,0.03)',
            borderRadius: '12px',
            border: '1px solid rgba(255,255,255,0.08)',
          }}>
            <div style={{ fontSize: '56px' }}>⚡</div>
            <div style={{ fontSize: '18px', fontWeight: 700, color: '#94a3b8' }}>No Macro Selected</div>
            <div style={{ fontSize: '13px', textAlign: 'center', maxWidth: '360px', lineHeight: '1.7', color: '#475569' }}>
              Select a macro from the list to edit it, or click <strong style={{ color: '#0891B2' }}>+ New</strong> to create your first macro template.
            </div>
            <button
              onClick={handleCreateNew}
              style={{ padding: '10px 24px', background: '#0891B2', border: 'none', borderRadius: '8px', color: '#fff', fontSize: '14px', fontWeight: 600, cursor: 'pointer', marginTop: '8px' }}
            >
              + Create New Macro
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default MacroPanel;
