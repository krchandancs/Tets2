import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from './AuthContext';

const ProtectedRoute = () => {
  const { isAuthenticated, loading } = useAuth();

  // If the AuthProvider is still checking the session, show nothing (or a spinner)
  if (loading) {
    return <div style={{ background: '#0f172a', height: '100vh' }} />;
  }

  // If not authenticated, redirect to login
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // If authenticated, render the child routes (Home, Worklist, etc.)
  return <Outlet />;
};

export default ProtectedRoute;