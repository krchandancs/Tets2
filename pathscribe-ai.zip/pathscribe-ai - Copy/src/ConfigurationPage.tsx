import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';
import MacroPanel from './components/MacroPanel';
import { loadProtocolRegistry, saveProtocolOverride } from "./protocols/protocolRegistry";
import { ProtocolDefinition } from "./types/ProtocolDefinition";
import { useAuditLog } from "./useAuditLog";

// ─── ACTION REGISTRY ─────────────────────────────────────────────────────────

interface PSShortcut {
  ctrl?: boolean;
  shift?: boolean;
  alt?: boolean;
  meta?: boolean;
  key: string;
  display?: string;
}

interface ActionDefinition {
  id: string;
  label: string;
  category: string;
  shortcut?: string | PSShortcut;
}

const actionRegistry: Record<string, ActionDefinition> = {
  bold: { id: 'bold', label: 'Bold', category: 'Text Formatting', shortcut: { ctrl: true, key: 'B', display: 'Ctrl+B' } },
  italic: { id: 'italic', label: 'Italic', category: 'Text Formatting', shortcut: { ctrl: true, key: 'I', display: 'Ctrl+I' } },
  underline: { id: 'underline', label: 'Underline', category: 'Text Formatting', shortcut: { ctrl: true, key: 'U', display: 'Ctrl+U' } },
  strikethrough: { id: 'strikethrough', label: 'Strikethrough', category: 'Text Formatting', shortcut: 'None' },
  subscript: { id: 'subscript', label: 'Subscript', category: 'Text Formatting', shortcut: 'None' },
  superscript: { id: 'superscript', label: 'Superscript', category: 'Text Formatting', shortcut: 'None' },
  bulletList: { id: 'bulletList', label: 'Bullet List', category: 'Lists', shortcut: 'None' },
  numberedList: { id: 'numberedList', label: 'Numbered List', category: 'Lists', shortcut: 'None' },
  increaseIndent: { id: 'increaseIndent', label: 'Increase Indent', category: 'Paragraph', shortcut: 'None' },
  decreaseIndent: { id: 'decreaseIndent', label: 'Decrease Indent', category: 'Paragraph', shortcut: 'None' },
  alignLeft: { id: 'alignLeft', label: 'Align Left', category: 'Paragraph', shortcut: 'None' },
  alignCenter: { id: 'alignCenter', label: 'Align Center', category: 'Paragraph', shortcut: 'None' },
  alignRight: { id: 'alignRight', label: 'Align Right', category: 'Paragraph', shortcut: 'None' },
  alignJustify: { id: 'alignJustify', label: 'Justify', category: 'Paragraph', shortcut: 'None' },
  insertMacro: { id: 'insertMacro', label: 'Insert Macro', category: 'Insert', shortcut: 'None' },
  insertTable: { id: 'insertTable', label: 'Insert Table', category: 'Insert', shortcut: 'None' },
  insertImage: { id: 'insertImage', label: 'Insert Image', category: 'Insert', shortcut: 'None' },
  insertSignature: { id: 'insertSignature', label: 'Insert Signature', category: 'Insert', shortcut: 'None' },
  find: { id: 'find', label: 'Find', category: 'Editing', shortcut: { ctrl: true, key: 'F', display: 'Ctrl+F' } },
  findReplace: { id: 'findReplace', label: 'Find & Replace', category: 'Editing', shortcut: 'None' },
  selectAll: { id: 'selectAll', label: 'Select All', category: 'Editing', shortcut: { ctrl: true, key: 'A', display: 'Ctrl+A' } },
  undo: { id: 'undo', label: 'Undo', category: 'Editing', shortcut: { ctrl: true, key: 'Z', display: 'Ctrl+Z' } },
  redo: { id: 'redo', label: 'Redo', category: 'Editing', shortcut: { ctrl: true, shift: true, key: 'Z', display: 'Ctrl+Shift+Z' } },
  showRuler: { id: 'showRuler', label: 'Show Ruler', category: 'View', shortcut: 'None' },
  toggleFormatting: { id: 'toggleFormatting', label: 'Show Formatting Marks', category: 'View', shortcut: 'None' },
};

// ─── DATA ────────────────────────────────────────────────────────────────────

const allFonts = [
  { name: 'Arial', category: 'Sans-serif', platform: 'All platforms' },
  { name: 'Times New Roman', category: 'Serif', platform: 'All platforms' },
  { name: 'Courier New', category: 'Monospace', platform: 'All platforms' },
  { name: 'Roboto', category: 'Sans-serif', platform: 'Web / Android' },
  { name: 'Calibri', category: 'Sans-serif', platform: 'Windows / Office' },
  { name: 'Helvetica', category: 'Sans-serif', platform: 'macOS / Print' },
  { name: 'Georgia', category: 'Serif', platform: 'All platforms' },
  { name: 'Verdana', category: 'Sans-serif', platform: 'All platforms' },
];

const sampleUsers = [
  { name: 'Dr. Sarah Johnson', email: 'demo@pathscribe.ai', role: 'Admin', status: 'Active' },
  { name: 'Dr. Michael Chen', email: 'm.chen@hospital.org', role: 'Pathologist', status: 'Active' },
  { name: 'Dr. Priya Nair', email: 'p.nair@hospital.org', role: 'Resident', status: 'Active' },
  { name: 'Dr. James Okafor', email: 'j.okafor@hospital.org', role: 'Pathologist', status: 'Active' },
  { name: 'Dr. Lisa Tran', email: 'l.tran@hospital.org', role: 'ReadOnly', status: 'Pending' },
];

const quickLinks = {
  protocols: [
    { title: 'CAP Cancer Protocols', url: 'https://www.cap.org/protocols-and-guidelines' },
    { title: 'WHO Classification', url: 'https://www.who.int/publications' },
  ],
  references: [
    { title: 'PathologyOutlines', url: 'https://www.pathologyoutlines.com' },
    { title: 'UpToDate', url: 'https://www.uptodate.com' },
  ],
  systems: [
    { title: 'Hospital LIS', url: '#' },
    { title: 'Lab Management', url: '#' },
  ],
};

const roleBadge: Record<string, { bg: string; color: string }> = {
  Admin: { bg: 'rgba(8,145,178,0.12)', color: '#0891B2' },
  Pathologist: { bg: '#f1f5f9', color: '#475569' },
  Resident: { bg: 'rgba(16,185,129,0.1)', color: '#059669' },
  ReadOnly: { bg: '#f1f5f9', color: '#94a3b8' },
};

const statusBadge: Record<string, { bg: string; color: string }> = {
  Active: { bg: '#d1fae5', color: '#065f46' },
  Pending: { bg: '#fef3c7', color: '#92400e' },
  Disabled: { bg: '#fee2e2', color: '#991b1b' },
};

// ─── KEYBOARD SHORTCUT MODAL ─────────────────────────────────────────────────

interface ShortcutModalProps {
  action: ActionDefinition | null;
  onClose: () => void;
  onSave: (actionId: string, shortcut: PSShortcut) => void;
}

const KeyboardShortcutModal: React.FC<ShortcutModalProps> = ({ action, onClose, onSave }) => {
  const [ctrl, setCtrl] = useState(false);
  const [shift, setShift] = useState(false);
  const [alt, setAlt] = useState(false);
  const [meta, setMeta] = useState(false);
  const [key, setKey] = useState('');
  const [isRecording, setIsRecording] = useState(false);

  useEffect(() => {
    if (action?.shortcut && typeof action.shortcut !== 'string') {
      const sc = action.shortcut as PSShortcut;
      setCtrl(sc.ctrl || false);
      setShift(sc.shift || false);
      setAlt(sc.alt || false);
      setMeta(sc.meta || false);
      setKey(sc.key || '');
    }
  }, [action]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isRecording) return;
      e.preventDefault();
      
      if (['Control', 'Shift', 'Alt', 'Meta'].includes(e.key)) return;
      
      setCtrl(e.ctrlKey);
      setShift(e.shiftKey);
      setAlt(e.altKey);
      setMeta(e.metaKey);
      setKey(e.key.toUpperCase());
      setIsRecording(false);
    };

    if (isRecording) {
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [isRecording]);

  const handleSave = () => {
    if (!action || !key) return;
    
    const display = [
      ctrl && 'Ctrl',
      shift && 'Shift',
      alt && 'Alt',
      meta && 'Meta',
      key
    ].filter(Boolean).join('+');

    onSave(action.id, { ctrl, shift, alt, meta, key, display });
    onClose();
  };

  if (!action) return null;

  return (
    <div 
      onClick={onClose}
      style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10000 }}
    >
      <div 
        onClick={e => e.stopPropagation()}
        style={{ width: '500px', backgroundColor: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)' }}
      >
        <h2 style={{ fontSize: '22px', fontWeight: 700, color: '#1e293b', marginBottom: '8px' }}>Edit Keyboard Shortcut</h2>
        <p style={{ fontSize: '14px', color: '#64748b', marginBottom: '24px' }}>{action.label}</p>

        <div style={{ marginBottom: '24px' }}>
          <div style={{ fontSize: '13px', fontWeight: 600, color: '#64748b', marginBottom: '12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Modifiers</div>
          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            {[
              { label: 'Ctrl', value: ctrl, set: setCtrl },
              { label: 'Shift', value: shift, set: setShift },
              { label: 'Alt', value: alt, set: setAlt },
              { label: 'Meta', value: meta, set: setMeta },
            ].map(mod => (
              <label key={mod.label} style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 16px', border: `2px solid ${mod.value ? '#0891B2' : '#e2e8f0'}`, borderRadius: '8px', cursor: 'pointer', background: mod.value ? 'rgba(8,145,178,0.05)' : 'white' }}>
                <input type="checkbox" checked={mod.value} onChange={e => mod.set(e.target.checked)} style={{ width: '18px', height: '18px', cursor: 'pointer', accentColor: '#0891B2' }} />
                <span style={{ fontSize: '14px', fontWeight: 600, color: mod.value ? '#0891B2' : '#64748b' }}>{mod.label}</span>
              </label>
            ))}
          </div>
        </div>

        <div style={{ marginBottom: '24px' }}>
          <div style={{ fontSize: '13px', fontWeight: 600, color: '#64748b', marginBottom: '12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Key</div>
          <button
            onClick={() => setIsRecording(true)}
            style={{ width: '100%', padding: '16px', border: `2px solid ${isRecording ? '#0891B2' : '#e2e8f0'}`, borderRadius: '8px', background: isRecording ? 'rgba(8,145,178,0.05)' : '#f8fafc', fontSize: '16px', fontWeight: 600, fontFamily: 'monospace', color: key ? '#1e293b' : '#94a3b8', cursor: 'pointer', textAlign: 'center' }}
          >
            {isRecording ? 'Press any key...' : key || 'Click to record key'}
          </button>
        </div>

        <div style={{ padding: '16px', background: '#f8fafc', borderRadius: '8px', marginBottom: '24px' }}>
          <div style={{ fontSize: '12px', fontWeight: 600, color: '#64748b', marginBottom: '8px' }}>Preview</div>
          <div style={{ fontSize: '18px', fontWeight: 700, fontFamily: 'monospace', color: '#0891B2' }}>
            {[ctrl && 'Ctrl', shift && 'Shift', alt && 'Alt', meta && 'Meta', key].filter(Boolean).join('+') || 'None'}
          </div>
        </div>

        <div style={{ display: 'flex', gap: '12px', justifyContent: 'flex-end' }}>
          <button onClick={onClose} style={{ padding: '10px 20px', border: '1px solid #cbd5e1', borderRadius: '8px', background: 'white', color: '#64748b', fontSize: '14px', fontWeight: 600, cursor: 'pointer' }}>Cancel</button>
          <button onClick={handleSave} disabled={!key} style={{ padding: '10px 20px', background: key ? '#0891B2' : '#cbd5e1', color: 'white', borderRadius: '8px', border: 'none', fontSize: '14px', fontWeight: 600, cursor: key ? 'pointer' : 'not-allowed' }}>Save Shortcut</button>
        </div>
      </div>
    </div>
  );
};

// ─── COMPONENT ───────────────────────────────────────────────────────────────

const ConfigurationPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user: currentUser, logout: performLogout } = useAuth();
  console.log("Auth user in ConfigurationPage:", currentUser);
  const { log } = useAuditLog();

  const validTabs = ['ai', 'models', 'protocols', 'templates', 'users', 'system', 'macros'] as const;
  type TabId = typeof validTabs[number];
  const getTabFromUrl = (): TabId => {
    const t = new URLSearchParams(location.search).get('tab') as TabId | null;
    return t && (validTabs as readonly string[]).includes(t) ? t : 'ai';
  };
  const [activeTab, setActiveTab] = useState<TabId>(getTabFromUrl);

  useEffect(() => {
    setActiveTab(getTabFromUrl());
  }, [location.search]);
  const [isLoaded, setIsLoaded] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [approvedFonts, setApprovedFonts] = useState<string[]>(['Arial', 'Times New Roman', 'Courier New', 'Roboto']);
  const [isResourcesOpen, setIsResourcesOpen] = useState(false);
  const [hasUnsavedData, setHasUnsavedData] = useState(false);
  const [showWarning, setShowWarning] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [retentionYears, setRetentionYears] = useState('6');
  const [autoSelectProtocol, setAutoSelectProtocol] = useState(true);
  const [autoGenerateSynoptic, setAutoGenerateSynoptic] = useState(true);
  const [requireReviewGross, setRequireReviewGross] = useState(true);
  const [autoUpdateMode, setAutoUpdateMode] = useState<'auto' | 'suggest' | 'manual'>('suggest');
  const [allowProtocolChanges, setAllowProtocolChanges] = useState(true);
  const [requireConfirmation, setRequireConfirmation] = useState(true);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const [editingAction, setEditingAction] = useState<ActionDefinition | null>(null);
  const [customShortcuts, setCustomShortcuts] = useState<Record<string, PSShortcut>>({});
  const [cloneTarget, setCloneTarget] = useState<ProtocolDefinition | null>(null);
  const { user: authUser, logout: authLogout } = useAuth();
  console.log("Auth user in ConfigurationPage:", authUser);

  useEffect(() => {
    const t = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(t);
  }, []);

  // Auto-expand categories when searching
  useEffect(() => {
    if (searchTerm) {
      const actions = Object.values(actionRegistry);
      const filtered = actions.filter(a => a.label.toLowerCase().includes(searchTerm.toLowerCase()));
      const categories: Record<string, ActionDefinition[]> = {};
      filtered.forEach(a => {
        if (!categories[a.category]) categories[a.category] = [];
        categories[a.category].push(a);
      });
      
      const newExpanded: Record<string, boolean> = {};
      Object.keys(categories).forEach(cat => {
        newExpanded[cat] = true;
      });
      setExpandedCategories(newExpanded);
    }
  }, [searchTerm]);

  const handleNavigateHome = () => {
    if (hasUnsavedData) setShowWarning(true);
    else navigate('/');
  };

  const toggleFont = (name: string) => {
    const willEnable = !approvedFonts.includes(name);
    setApprovedFonts(prev =>
      prev.includes(name) ? prev.filter(f => f !== name) : [...prev, name]
    );

    log('update_system_settings', { setting: `Font "${name}"`, to: willEnable });
  };

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [category]: !prev[category]
    }));
  };

  // ── Audit logging via useAuditLog hook ────────────────────────────────────
  // Use log("action", payload) directly — see useAuditLog.ts for all actions.

  // ── Shared styles ──────────────────────────────────────────────────────────

  const card: React.CSSProperties = {
    background: 'white',
    borderRadius: '12px',
    padding: '24px',
    border: '1px solid #e2e8f0',
    marginBottom: '20px',
  };

  const sectionTitle: React.CSSProperties = {
    fontSize: '18px',
    fontWeight: 600,
    color: '#1e293b',
    marginBottom: '6px',
  };

  const sectionSubtitle: React.CSSProperties = {
    fontSize: '13px',
    color: '#64748b',
    marginBottom: '20px',
  };

  const settingRow: React.CSSProperties = {
    padding: '14px 16px',
    background: '#f8fafc',
    borderRadius: '8px',
    marginBottom: '10px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  };

  const settingLabel: React.CSSProperties = {
    fontSize: '14px',
    fontWeight: 600,
    color: '#1e293b',
    marginBottom: '3px',
  };

  const settingDesc: React.CSSProperties = {
    fontSize: '12px',
    color: '#64748b',
  };

  const primaryBtn: React.CSSProperties = {
    padding: '10px 20px',
    background: '#0891B2',
    color: 'white',
    borderRadius: '8px',
    border: 'none',
    fontWeight: 600,
    fontSize: '14px',
    cursor: 'pointer',
  };

  const secondaryBtn: React.CSSProperties = {
    padding: '6px 16px',
    border: '1px solid #cbd5e1',
    borderRadius: '6px',
    background: 'white',
    color: '#64748b',
    fontSize: '13px',
    fontWeight: 600,
    cursor: 'pointer',
  };

  const toggle = (enabled: boolean): React.CSSProperties => ({
    width: '44px',
    height: '24px',
    background: enabled ? '#0891B2' : '#cbd5e1',
    borderRadius: '12px',
    position: 'relative',
    transition: 'background 0.2s',
    flexShrink: 0,
    cursor: 'pointer',
  });

  const toggleKnob = (enabled: boolean): React.CSSProperties => ({
    width: '18px',
    height: '18px',
    background: 'white',
    borderRadius: '50%',
    position: 'absolute',
    top: '3px',
    left: enabled ? '23px' : '3px',
    transition: 'left 0.2s',
    boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
  });

  // ── Tab: AI Behavior ───────────────────────────────────────────────────────

  const renderAIBehaviorTab = () => (
    <div>
      <div style={card}>
        <h3 style={sectionTitle}>Phase 1: Gross-Driven AI</h3>
        <p style={sectionSubtitle}>Controls how AI behaves when the gross description is completed</p>

        {[
          { label: 'Auto-Select Protocol', desc: 'AI automatically selects the appropriate CAP protocol', val: autoSelectProtocol, set: setAutoSelectProtocol },
          { label: 'Auto-Generate Synoptic', desc: 'AI automatically generates initial synoptic draft', val: autoGenerateSynoptic, set: setAutoGenerateSynoptic },
          { label: 'Require Pathologist Review', desc: 'Pathologist must review before finalization', val: requireReviewGross, set: setRequireReviewGross },
        ].map(item => (
          <div key={item.label} style={settingRow}>
            <div style={{ flex: 1 }}>
              <div style={settingLabel}>{item.label}</div>
              <div style={settingDesc}>{item.desc}</div>
            </div>
            <input
              type="checkbox"
              checked={item.val}
              onChange={e => {
                item.set(e.target.checked);
                log('update_ai_behavior', { setting: item.label, from: !e.target.checked, to: e.target.checked });
              }}
              style={{ width: '20px', height: '20px', cursor: 'pointer', accentColor: '#0891B2' }}
            />
          </div>
        ))}
      </div>

      <div style={{ ...card, marginBottom: 0 }}>
        <h3 style={sectionTitle}>Phase 2: Microscopic-Driven AI</h3>
        <p style={sectionSubtitle}>Controls how AI behaves when microscopic description is available</p>

        <div style={{ ...settingRow, flexDirection: 'column', alignItems: 'flex-start' }}>
          <div style={{ ...settingLabel, marginBottom: '12px' }}>Auto-Update Synoptic</div>
          <div style={{ display: 'flex', gap: '12px', width: '100%' }}>
            {([
              { value: 'auto', label: 'Auto', desc: 'Updates automatically' },
              { value: 'suggest', label: 'Suggest', desc: 'Suggests changes' },
              { value: 'manual', label: 'Manual', desc: 'No auto-updates' },
            ] as const).map(opt => (
              <label
                key={opt.value}
                style={{
                  flex: 1,
                  padding: '12px',
                  border: `2px solid ${autoUpdateMode === opt.value ? '#0891B2' : '#e2e8f0'}`,
                  borderRadius: '8px',
                  background: autoUpdateMode === opt.value ? 'rgba(8,145,178,0.05)' : 'white',
                  cursor: 'pointer',
                }}
              >
                <input
                  type="radio"
                  name="autoUpdateMode"
                  value={opt.value}
                  checked={autoUpdateMode === opt.value}
                  onChange={() => {
                    setAutoUpdateMode(opt.value);
                    log('update_ai_behavior', { setting: 'Auto-Update Synoptic', from: autoUpdateMode, to: opt.value });
                  }}
                  style={{ marginRight: '8px' }}
                />
                <span style={{ fontSize: '13px', fontWeight: 600 }}>{opt.label}</span>
                <div style={{ fontSize: '11px', color: '#64748b', marginTop: '4px', marginLeft: '24px' }}>{opt.desc}</div>
              </label>
            ))}
          </div>
        </div>

        {[
          { label: 'Allow Protocol Changes', desc: 'AI can add/remove protocols based on findings', val: allowProtocolChanges, set: setAllowProtocolChanges },
          { label: 'Require Confirmation Before Update', desc: 'Pathologist must confirm all changes', val: requireConfirmation, set: setRequireConfirmation },
        ].map(item => (
          <div key={item.label} style={settingRow}>
            <div style={{ flex: 1 }}>
              <div style={settingLabel}>{item.label}</div>
              <div style={settingDesc}>{item.desc}</div>
            </div>
            <input
              type="checkbox"
              checked={item.val}
              onChange={e => {
                item.set(e.target.checked);
                log('update_ai_behavior', { setting: item.label, from: !e.target.checked, to: e.target.checked });
              }}
              style={{ width: '20px', height: '20px', cursor: 'pointer', accentColor: '#0891B2' }}
            />
          </div>
        ))}
      </div>
    </div>
  );

  // ── Tab: Models ────────────────────────────────────────────────────────────

  const renderModelsTab = () => (
    <div style={card}>
      <h3 style={sectionTitle}>Model Performance</h3>
      <p style={sectionSubtitle}>Compare AI models across protocols</p>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '13px' }}>
        <thead>
          <tr style={{ background: '#f8fafc', borderBottom: '2px solid #e2e8f0' }}>
            {['Protocol', 'GPT-4', 'Claude 3.5', 'Gemini Pro', 'Current'].map(h => (
              <th key={h} style={{ padding: '12px', textAlign: h === 'Protocol' || h === 'Current' ? 'left' : 'center', fontWeight: 600 }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {[
            { protocol: 'Breast Invasive', gpt4: 94, claude: 96, gemini: 91, current: 'Claude 3.5' },
            { protocol: 'Colon Resection', gpt4: 92, claude: 93, gemini: 89, current: 'Claude 3.5' },
            { protocol: 'Prostate', gpt4: 91, claude: 94, gemini: 88, current: 'Claude 3.5' },
          ].map((r, i) => (
            <tr key={i} style={{ borderBottom: '1px solid #f1f5f9' }}>
              <td style={{ padding: '12px', fontWeight: 600 }}>{r.protocol}</td>
              <td style={{ padding: '12px', textAlign: 'center', color: '#64748b' }}>{r.gpt4}%</td>
              <td style={{ padding: '12px', textAlign: 'center', color: '#0891B2', fontWeight: 600 }}>{r.claude}%</td>
              <td style={{ padding: '12px', textAlign: 'center', color: '#64748b' }}>{r.gemini}%</td>
              <td style={{ padding: '12px', color: '#10B981', fontWeight: 600 }}>✓ {r.current}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  // ── Tab: Protocols ─────────────────────────────────────────────────────────

  const renderProtocolsTab = () => {
  const protocols = Object.values(loadProtocolRegistry());

  return (
    <div style={card}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "20px",
        }}
      >
        <div>
          <h3 style={sectionTitle}>Protocol Library</h3>
          <p style={{ ...sectionSubtitle, marginBottom: 0 }}>
            Manage CAP / RCPath synoptic templates
          </p>
        </div>

        <button style={primaryBtn}>+ Add Protocol</button>
      </div>

      <div style={{ display: "grid", gap: "12px" }}>
        {protocols.map((p) => (
          <div key={p.id} style={{ ...settingRow, marginBottom: 0 }}>
            <div>
              <div style={settingLabel}>{p.name}</div>
              <div style={settingDesc}>
                {p.category} • v{p.version} • {p.lifecycle}
              </div>
            </div>

            <button
              style={secondaryBtn}
              onClick={() => {
                if (p.isBaseTemplate) {
                  // Base CAP template → require confirmation before cloning
                  log('open_clone_modal', { id: p.id, name: p.name });
                  setCloneTarget(p);
                } else {
                  // Local template → open normally
                  navigate(`/configuration/protocols/${p.id}`);
                }
              }}
            >
              Edit
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

  // ── Tab: Templates ─────────────────────────────────────────────────────────

  const renderTemplatesTab = () => (
    <div style={card}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <div>
          <h3 style={sectionTitle}>Grossing Templates</h3>
          <p style={{ ...sectionSubtitle, marginBottom: 0 }}>Manage institutional templates</p>
        </div>
        <button style={primaryBtn}>+ New Template</button>
      </div>
      <div style={{ display: 'grid', gap: '12px' }}>
        {[
          { name: 'Breast Lumpectomy - Standard', organ: 'Breast', uses: 342 },
          { name: 'Colon Resection - Standard', organ: 'Colon', uses: 289 },
        ].map((t, i) => (
          <div key={i} style={{ ...settingRow, marginBottom: 0 }}>
            <div>
              <div style={settingLabel}>{t.name}</div>
              <div style={settingDesc}>{t.organ} • Used {t.uses} times</div>
            </div>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button style={secondaryBtn}>Edit</button>
              <button style={{ ...secondaryBtn, border: '1px solid #fca5a5', color: '#ef4444' }}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // ── Tab: Users ─────────────────────────────────────────────────────────────

  const renderUsersTab = () => (
    <div style={card}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
        <div>
          <h3 style={sectionTitle}>User Management</h3>
          <p style={{ ...sectionSubtitle, marginBottom: 0 }}>Manage pathologist accounts</p>
        </div>
        <button style={primaryBtn}>+ Add User</button>
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px', gap: '12px', flexWrap: 'wrap' }}>
        <input
          placeholder="Search users..."
          style={{ padding: '10px 14px', width: '260px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '14px' }}
        />
        <div style={{ display: 'flex', gap: '12px' }}>
          <select style={{ padding: '10px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '13px' }}>
            <option>All Roles</option>
            <option>Admin</option>
            <option>Pathologist</option>
          </select>
          <select style={{ padding: '10px 12px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '13px' }}>
            <option>All Statuses</option>
            <option>Active</option>
            <option>Pending</option>
          </select>
        </div>
      </div>

      <div style={{ display: 'grid', gap: '10px' }}>
        {sampleUsers.map((u, i) => {
          const rb = roleBadge[u.role] ?? { bg: '#f1f5f9', color: '#64748b' };
          const sb = statusBadge[u.status] ?? { bg: '#f1f5f9', color: '#64748b' };
          const initials = u.name.split(' ').map(n => n[0]).join('').slice(0, 2);
          return (
            <div key={i} style={{ padding: '14px 16px', background: '#f8fafc', borderRadius: '10px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', border: '1px solid #e2e8f0' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <div style={{ width: '38px', height: '38px', borderRadius: '50%', background: rb.color, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 700, fontSize: '13px', flexShrink: 0 }}>
                  {initials}
                </div>
                <div>
                  <div style={{ fontSize: '14px', fontWeight: 600, color: '#1e293b' }}>{u.name}</div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>{u.email}</div>
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <span style={{ padding: '4px 10px', borderRadius: '20px', fontSize: '12px', fontWeight: 600, background: rb.bg, color: rb.color }}>{u.role}</span>
                <span style={{ padding: '4px 10px', borderRadius: '20px', fontSize: '12px', fontWeight: 600, background: sb.bg, color: sb.color }}>{u.status}</span>
                <button onClick={() => setSelectedUser(u)} style={secondaryBtn}>Edit</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  // ── Tab: System (COMPACT + AUTO-EXPAND) ────────────────────────────────────

  const renderSystemTab = () => {
    const actions = Object.values(actionRegistry);
    const filtered = searchTerm
      ? actions.filter(a => a.label.toLowerCase().includes(searchTerm.toLowerCase()))
      : actions;

    const categories: Record<string, ActionDefinition[]> = {};
    filtered.forEach(a => {
      if (!categories[a.category]) categories[a.category] = [];
      categories[a.category].push(a);
    });

    const renderShortcut = (actionId: string, shortcut: string | PSShortcut | undefined) => {
      const custom = customShortcuts[actionId];
      if (custom) return custom.display;
      if (!shortcut) return 'None';
      if (typeof shortcut === 'string') return shortcut;
      return shortcut.display ?? 'None';
    };

    return (
      <div>
        {/* AI Decision Retention */}
        <div style={card}>
          <h3 style={sectionTitle}>AI Decision Retention</h3>
          <p style={sectionSubtitle}>Configure how long AI-generated decisions are retained</p>
          <select value={retentionYears} onChange={e => {
            setRetentionYears(e.target.value);
            log('update_system_settings', { setting: 'AI Decision Retention', to: `${e.target.value} years` });
          }}
            style={{ padding: '10px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '14px', cursor: 'pointer', minWidth: '220px' }}>
            <option value="1">1 year</option>
            <option value="3">3 years</option>
            <option value="6">6 years (Recommended)</option>
            <option value="10">10 years</option>
          </select>
        </div>

        {/* LIS Integration */}
        <div style={card}>
          <h3 style={sectionTitle}>LIS Integration</h3>
          <p style={sectionSubtitle}>Laboratory Information System connection status</p>
          <div style={{ display: 'flex', gap: '16px', flexWrap: 'wrap' }}>
            {[
              { label: 'Primary LIS', status: 'Connected', color: '#10B981', bg: '#d1fae5', border: '#86efac' },
              { label: 'EHR Bridge', status: 'Connected', color: '#10B981', bg: '#d1fae5', border: '#86efac' },
              { label: 'Cloud Storage', status: 'Degraded', color: '#F59E0B', bg: '#fef3c7', border: '#fcd34d' },
            ].map(s => (
              <div key={s.label} style={{ padding: '16px 20px', borderRadius: '10px', background: s.bg, border: `1px solid ${s.border}`, minWidth: '180px' }}>
                <div style={{ fontSize: '12px', color: '#64748b', fontWeight: 600, marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{s.label}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: s.color, flexShrink: 0 }} />
                  <span style={{ fontSize: '14px', fontWeight: 700, color: s.color }}>{s.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Approved Fonts */}
        <div style={card}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
            <div>
              <h3 style={sectionTitle}>Approved Report Fonts</h3>
              <p style={{ ...sectionSubtitle, marginBottom: 0 }}>Select fonts authorized for reports</p>
            </div>
            <span style={{ fontSize: '13px', fontWeight: 600, color: '#0891B2', background: 'rgba(8,145,178,0.1)', padding: '4px 12px', borderRadius: '20px' }}>
              {approvedFonts.length} font{approvedFonts.length !== 1 && 's'} enabled
            </span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '12px' }}>
            {allFonts.map(font => {
              const on = approvedFonts.includes(font.name);
              return (
                <div key={font.name} onClick={() => toggleFont(font.name)}
                  style={{ padding: '14px 16px', borderRadius: '10px', cursor: 'pointer', background: on ? 'rgba(8,145,178,0.06)' : '#f8fafc',
                    border: `2px solid ${on ? '#0891B2' : '#e2e8f0'}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', transition: 'all 0.15s' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: '14px', fontWeight: 600, color: on ? '#0891B2' : '#1e293b', marginBottom: '3px' }}>{font.name}</div>
                    <div style={{ fontSize: '11px', color: '#94a3b8', display: 'flex', gap: '6px', alignItems: 'center' }}>
                      <span>{font.category}</span><span style={{ color: '#cbd5e1' }}>•</span><span>{font.platform}</span>
                    </div>
                  </div>
                  <div style={toggle(on)}><div style={toggleKnob(on)} /></div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Keyboard Shortcuts - COMPACT */}
        <div style={card}>
          <h3 style={sectionTitle}>Keyboard Shortcuts</h3>
          <p style={sectionSubtitle}>Customize editor hotkeys for all actions</p>
          
          <input 
            type="text" 
            placeholder="Search actions..." 
            value={searchTerm} 
            onChange={e => setSearchTerm(e.target.value)}
            style={{ width: '100%', padding: '10px 14px', marginBottom: '16px', borderRadius: '8px', border: '1px solid #cbd5e1', fontSize: '14px', boxSizing: 'border-box' }} 
          />

          <div style={{ maxHeight: '500px', overflowY: 'auto', border: '1px solid #e2e8f0', borderRadius: '8px' }}>
            {Object.entries(categories).map(([categoryName, acts]) => {
              const isExpanded = expandedCategories[categoryName] ?? false;
              return (
                <div key={categoryName} style={{ borderBottom: '1px solid #f1f5f9' }}>
                  <div 
                    onClick={() => toggleCategory(categoryName)}
                    style={{ padding: '12px 16px', background: '#f8fafc', cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontWeight: 600, fontSize: '13px', color: '#475569', textTransform: 'uppercase', letterSpacing: '0.05em', userSelect: 'none' }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ fontSize: '10px', transition: 'transform 0.2s', transform: isExpanded ? 'rotate(90deg)' : 'rotate(0deg)' }}>▶</span>
                      <span>{categoryName}</span>
                      <span style={{ fontSize: '11px', fontWeight: 500, color: '#94a3b8', background: '#fff', padding: '2px 8px', borderRadius: '12px' }}>{acts.length}</span>
                    </div>
                  </div>

                  {isExpanded && (
                    <div>
                      {acts.map((action, idx) => (
                        <div key={action.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 16px', background: idx % 2 === 0 ? '#fff' : '#fafbfc', borderTop: '1px solid #f1f5f9' }}>
                          <span style={{ fontSize: '14px', color: '#1e293b', fontWeight: 500 }}>{action.label}</span>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                            <span style={{ fontSize: '13px', color: '#64748b', fontFamily: 'monospace', minWidth: '100px', textAlign: 'right', background: '#f8fafc', padding: '4px 8px', borderRadius: '4px', border: '1px solid #e2e8f0' }}>
                              {renderShortcut(action.id, action.shortcut)}
                            </span>
                            <button 
                              onClick={() => setEditingAction(action)} 
                              style={{ padding: '4px 10px', border: '1px solid #cbd5e1', borderRadius: '6px', background: 'white', color: '#64748b', fontSize: '12px', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}
                            >
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
                              Edit
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {Object.keys(categories).length === 0 && (
            <div style={{ textAlign: 'center', padding: '40px', color: '#94a3b8', fontSize: '14px' }}>
              No actions found for "{searchTerm}"
            </div>
          )}
        </div>
      </div>
    );
  };

  const tabs = [
    { id: 'ai', label: 'AI Behavior', icon: '🤖' },
    { id: 'models', label: 'Models', icon: '📊' },
    { id: 'protocols', label: 'Protocols', icon: '📋' },
    { id: 'templates', label: 'Templates', icon: '📝' },
    { id: 'users', label: 'Users', icon: '👥' },
    { id: 'system', label: 'System', icon: '⚙️' },
    { id: 'macros', label: 'Macros', icon: '⚡' },
  ] as const;

  return (
    <div style={{ position: 'relative', width: '100vw', height: '100vh', backgroundColor: '#000', color: '#fff', fontFamily: "'Inter', sans-serif", opacity: isLoaded ? 1 : 0, transition: 'opacity 0.6s ease', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, backgroundImage: 'url(/main_background.jpg)', backgroundSize: 'cover', backgroundPosition: 'center', zIndex: 0, filter: 'brightness(0.3) contrast(1.1)' }} />
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom, rgba(0,0,0,0.4) 0%, #000 100%)', zIndex: 1 }} />

      <div style={{ position: 'relative', zIndex: 10, display: 'flex', flexDirection: 'column', height: '100%', overflowY: 'auto' }}>
        <nav style={{ padding: '20px 40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(12px)', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
            <img src="/pathscribe-logo-dark.svg" alt="PathScribe AI" style={{ height: '60px', width: 'auto', cursor: 'pointer' }} onClick={handleNavigateHome} />
            <div style={{ width: '1px', height: '30px', background: 'rgba(255,255,255,0.2)' }} />
            <div style={{ fontSize: '14px', color: '#64748b', display: 'flex', alignItems: 'center', gap: '8px', fontWeight: 500 }}>
              <span onClick={handleNavigateHome} style={{ cursor: 'pointer' }}>Home</span>
              <span style={{ color: '#cbd5e1' }}>›</span>
              <span style={{ color: '#0891B2', fontWeight: 600 }}>Configuration</span>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', borderRight: '1px solid rgba(255,255,255,0.2)', paddingRight: '20px' }}>
              <span style={{ fontSize: '17px', fontWeight: 600 }}>{currentUser?.name || 'Dr. Johnson'}</span>
              <span style={{ fontSize: '12px', color: '#0891B2', fontWeight: 700 }}>MD, FCAP</span>
            </div>
            <button onClick={() => setIsResourcesOpen(true)} style={{ width: '42px', height: '42px', borderRadius: '8px', background: 'transparent', border: '2px solid #0891B2', color: '#0891B2', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
            </button>
           <button onClick={performLogout} style={{ width: '42px', height: '42px', borderRadius: '8px', background: 'transparent', border: '2px solid #0891B2', color: '#0891B2', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            </button>
          </div>
        </nav>

        <div style={{ padding: '40px 40px 24px' }}>
          <h1 style={{ fontSize: '36px', fontWeight: 800, marginBottom: '8px', color: '#fff' }}>⚙️ Configuration</h1>
          <p style={{ fontSize: '16px', color: '#94a3b8' }}>Manage AI behavior, models, protocols, and system settings</p>
        </div>

        <div style={{ padding: '0 40px', borderBottom: '2px solid rgba(255,255,255,0.1)', display: 'flex', gap: '4px' }}>
          {tabs.map(tab => (
            <button key={tab.id} onClick={() => navigate(`/configuration?tab=${tab.id}`)}
              style={{ padding: '12px 20px', background: 'none', border: 'none', borderBottom: `3px solid ${activeTab === tab.id ? '#0891B2' : 'transparent'}`, color: activeTab === tab.id ? '#0891B2' : '#94a3b8', fontWeight: 600, fontSize: '14px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '8px', transition: 'all 0.15s' }}>
              <span>{tab.icon}</span><span>{tab.label}</span>
            </button>
          ))}
        </div>

        <div style={{ padding: '32px 40px 60px', flex: 1 }}>
          {activeTab === 'ai' && renderAIBehaviorTab()}
          {activeTab === 'models' && renderModelsTab()}
          {activeTab === 'protocols' && renderProtocolsTab()}
          {activeTab === 'templates' && renderTemplatesTab()}
          {activeTab === 'users' && renderUsersTab()}
          {activeTab === 'system' && renderSystemTab()}
          {activeTab === 'macros' && <MacroPanel approvedFonts={approvedFonts} />}
        </div>

        {/* Keyboard Shortcut Editor Modal */}
        {editingAction && (
          <KeyboardShortcutModal
            action={editingAction}
            onClose={() => setEditingAction(null)}
            onSave={(actionId, shortcut) => {
              setCustomShortcuts(prev => ({ ...prev, [actionId]: shortcut }));
              log('update_system_settings', { setting: `Keyboard shortcut for "${actionId}"`, to: shortcut.display ?? 'None' });
              setEditingAction(null);
            }}
          />
        )}

        {selectedUser && (
          <div style={{ position: 'fixed', top: 0, right: 0, width: '420px', height: '100vh', background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(12px)', borderLeft: '1px solid rgba(255,255,255,0.1)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}>
            <div style={{ width: '100%', background: 'white', borderRadius: '16px', padding: '28px', color: '#1e293b' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '20px' }}>
                <div>
                  <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '4px' }}>{selectedUser.name}</h2>
                  <p style={{ fontSize: '13px', color: '#64748b' }}>{selectedUser.email}</p>
                </div>
                <button onClick={() => setSelectedUser(null)} style={{ background: 'none', border: 'none', fontSize: '20px', cursor: 'pointer', color: '#94a3b8' }}>✕</button>
              </div>
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button onClick={() => setSelectedUser(null)} style={{ ...secondaryBtn, padding: '10px 18px' }}>Cancel</button>
                <button style={{ ...primaryBtn, padding: '10px 18px' }}>Save Changes</button>
              </div>
            </div>
          </div>
        )}

        {showWarning && (
          <div style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10000 }}>
            <div style={{ width: '400px', backgroundColor: '#111', padding: '40px', borderRadius: '28px', textAlign: 'center', border: '1px solid rgba(255,255,255,0.1)', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.5)' }}>
              <div style={{ fontSize: '48px', marginBottom: '20px' }}>⚠️</div>
              <h2 style={{ fontSize: '24px', fontWeight: 800, color: '#fff', marginBottom: '12px' }}>Unsaved Changes</h2>
              <p style={{ color: '#94a3b8', marginBottom: '30px', lineHeight: '1.6', fontSize: '15px' }}>You have unsaved configuration changes</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                <button onClick={() => setShowWarning(false)} autoFocus style={{ padding: '16px', borderRadius: '12px', background: '#0891B2', border: 'none', color: '#fff', fontWeight: 700, fontSize: '16px', cursor: 'pointer' }}>← Stay</button>
                <button onClick={() => { setHasUnsavedData(false); navigate('/'); }} style={{ padding: '16px', borderRadius: '12px', background: 'transparent', border: '2px solid #F59E0B', color: '#F59E0B', fontWeight: 600, fontSize: '15px', cursor: 'pointer' }}>Leave & Discard</button>
              </div>
            </div>
          </div>
        )}

        {/* Clone Confirmation Modal */}
        {cloneTarget && (
          <div
            onClick={() => setCloneTarget(null)}
            style={{
              position: "fixed",
              inset: 0,
              background: "rgba(0,0,0,0.6)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              zIndex: 9999,
            }}
          >
            <div
              onClick={(e) => e.stopPropagation()}
              style={{
                width: "420px",
                background: "white",
                borderRadius: "12px",
                padding: "24px",
                boxShadow: "0 20px 40px rgba(0,0,0,0.3)",
              }}
            >
              <h2 style={{ fontSize: "20px", fontWeight: 700, marginBottom: "8px" }}>
                Create Local Copy?
              </h2>
              <p style={{ fontSize: "14px", color: "#475569", marginBottom: "20px" }}>
                <strong>{cloneTarget.name}</strong> is a CAP standard template.
                To customize it, PathScribeAI will create a local editable copy.
              </p>
              <div style={{ display: "flex", justifyContent: "flex-end", gap: "12px" }}>
                <button
                  style={{
                    padding: "8px 16px",
                    borderRadius: "6px",
                    border: "1px solid #cbd5e1",
                    background: "white",
                    cursor: "pointer",
                  }}
                  onClick={() => {
                    log('cancel_clone', { id: cloneTarget.id, name: cloneTarget.name });
                    setCloneTarget(null);
                    navigate(`/configuration?tab=protocols`);
                  }}
                >
                  Cancel
                </button>
                <button
                  style={{
                    padding: "8px 16px",
                    borderRadius: "6px",
                    background: "#0891B2",
                    color: "white",
                    border: "none",
                    cursor: "pointer",
                  }}
                  onClick={() => {
                    const newId = `${cloneTarget.id}_local_${Date.now()}`;
                    const cloned: ProtocolDefinition = {
                      ...cloneTarget,
                      id: newId,
                      name: `${cloneTarget.name} (Local Copy)`,
                      isBaseTemplate: false,
                      lifecycle: "draft",
                    };
                    saveProtocolOverride(cloned);
                    log('clone_protocol', { sourceId: cloneTarget.id, sourceName: cloneTarget.name, newId });
                    setCloneTarget(null);
                    navigate(`/configuration/protocols/${newId}?from=protocols`);
                  }}
                >
                  Create Copy
                </button>
              </div>
            </div>
          </div>
        )}

        {isResourcesOpen && (
          <div onClick={() => setIsResourcesOpen(false)} style={{ position: 'fixed', inset: 0, backgroundColor: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 10000 }}>
            <div onClick={e => e.stopPropagation()} style={{ width: '500px', maxHeight: '80vh', overflowY: 'auto', backgroundColor: '#111', borderRadius: '20px', padding: '40px', border: '1px solid rgba(8,145,178,0.3)' }}>
              <div style={{ color: '#0891B2', fontSize: '22px', fontWeight: 700, marginBottom: '24px', textAlign: 'center' }}>Quick Links</div>
              {Object.entries(quickLinks).map(([section, links]) => (
                <div key={section} style={{ marginBottom: '24px' }}>
                  <div style={{ color: '#94a3b8', fontSize: '11px', fontWeight: 700, marginBottom: '10px', textTransform: 'uppercase' }}>{section}</div>
                  {links.map((link, i) => (
                    <a key={i} href={link.url} target="_blank" rel="noopener noreferrer" onClick={() => setIsResourcesOpen(false)}
                      style={{ display: 'block', color: '#cbd5e1', textDecoration: 'none', padding: '10px 14px', fontSize: '15px', borderRadius: '8px', marginBottom: '6px' }}>
                      → {link.title}
                    </a>
                  ))}
                </div>
              ))}
              <button onClick={() => setIsResourcesOpen(false)} style={{ ...primaryBtn, width: '100%' }}>Close</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ConfigurationPage;
