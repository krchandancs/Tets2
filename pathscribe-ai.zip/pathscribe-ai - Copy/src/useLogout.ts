import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';

// Use this hook in any page component instead of calling logout() directly.
// Example:
//   const handleLogout = useLogout();
//   <button onClick={handleLogout}>Log Out</button>

export function useLogout() {
  const { logout } = useAuth();
  const navigate = useNavigate();

  return () => {
    logout();
    navigate('/login');
  };
}
