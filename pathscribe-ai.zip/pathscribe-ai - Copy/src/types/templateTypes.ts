export type TemplateLifecycleState =
  | "draft"
  | "in_review"
  | "needs_changes"
  | "approved"
  | "published";

export interface TemplateOption {
  id: string;
  label: string;
}

interface QuestionBase {
  id: string;
  text: string;
  type: "choice" | "text";
}

export interface ChoiceQuestion extends QuestionBase {
  type: "choice";
  multiple?: boolean;
  options: TemplateOption[];
}

export interface TextQuestion extends QuestionBase {
  type: "text";
}

export type Question = ChoiceQuestion | TextQuestion;

export interface TemplateSection {
  id: string;
  title: string;
  questions: Question[];
}

export interface TemplateDefinition {
  id: string;
  displayName: string;
  source: string;
  sourceVersion: string;
  sections: TemplateSection[];
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  templateId: string;
  stateFrom?: TemplateLifecycleState;
  stateTo?: TemplateLifecycleState;
  questionId?: string;
  oldValue?: any;
  newValue?: any;
  commentId?: string;
  note?: string;
}