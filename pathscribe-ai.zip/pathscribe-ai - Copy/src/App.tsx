import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./Home";
import Login from "./Login";
import WorklistPage from "./Worklist/WorklistPage";
import AuditLogPage from "./AuditLogPage";
import ConfigurationPage from "./ConfigurationPage";
import SearchPage from "./SearchPage";

// Protocol Editor (admin-only)
import ProtocolEditor from "./protocols/ProtocolEditor";

// Template review (pathologist-facing)
import TemplateRenderer from "./components/TemplateRenderer";
import { AdminTemplateList } from "./components/AdminTemplateList";

import SynopticReportPage from "./SynopticReportPage";

import { AuthProvider } from "./AuthContext";

const App: React.FC = () => {
  return (
    <Router>
      <AuthProvider>
        <Routes>

          {/* Public / Login */}
          <Route path="/login" element={<Login />} />

          {/* Home Dashboard */}
          <Route path="/" element={<Home />} />

          {/* Worklist */}
          <Route path="/worklist" element={<WorklistPage />} />

          {/* Case Search */}
          <Route path="/search" element={<SearchPage />} />

          {/* Synoptic Report Page */}
          <Route path="/case/:caseId/synoptic" element={<SynopticReportPage />} />

          {/* Audit Logs */}
          <Route path="/audit" element={<AuditLogPage />} />

          {/* Configuration Hub */}
          <Route path="/configuration" element={<ConfigurationPage />} />

          {/* Protocol Editor (admin-only) */}
          <Route path="/configuration/protocols/:protocolId" element={<ProtocolEditor />} />

          {/* Template Review (admin) */}
          <Route path="/template-review" element={<AdminTemplateList />} />

          {/* Template Renderer (pathologist-facing) */}
          <Route path="/template-review/:templateId" element={<TemplateRenderer />} />

        </Routes>
      </AuthProvider>
    </Router>
  );
};

export default App;
